const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

const baseDir = path.join(process.cwd(), 'src', 'backend', 'modules');

const filePaths = {
  users: path.join(baseDir, 'auth', 'users.json'),
  investments: path.join(baseDir, 'investments', 'investments.json'),
  wishlist: path.join(baseDir, 'wishlist', 'wishlist.json'),
  transactions: path.join(baseDir, 'investments', 'transactions.json'),
};

(async () => {
  const SQL = await initSqlJs();

  // Delete the existing database file if it exists
  const dbFilePath = 'database.db';
  if (fs.existsSync(dbFilePath)) {
    fs.unlinkSync(dbFilePath);
  }

  // Create a database
  const db = new SQL.Database();

  // Create tables with default NULL values
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT,
      password TEXT,
      wallet_balance REAL DEFAULT NULL
    );
    CREATE TABLE IF NOT EXISTS investments (
      id TEXT PRIMARY KEY,
      name TEXT,
      amount REAL DEFAULT NULL
    );
    CREATE TABLE IF NOT EXISTS wishlist (
      id TEXT PRIMARY KEY,
      investment_id TEXT,
      name TEXT,
      current_value REAL DEFAULT NULL,
      amount REAL DEFAULT NULL,
      user_id TEXT
    );
    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      type TEXT,
      amount REAL DEFAULT NULL,
      date TEXT,
      current_value REAL DEFAULT NULL,
      investment_id TEXT,
      user_id TEXT
    );
    CREATE TABLE IF NOT EXISTS tokens (
  token TEXT PRIMARY KEY,
  user_id TEXT,
  expires_at TEXT
);

  `);

  // Function to load JSON data from a file
  const loadJSONData = (filePath) => {
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  };

  // Insert data into tables
  for (const [tableName, filePath] of Object.entries(filePaths)) {
    const data = loadJSONData(filePath);

    if (tableName === 'users') {
      data.forEach((item) => {
        try {
          db.run(`
            INSERT INTO users (id, username, password, wallet_balance)
            VALUES (?, ?, ?, ?);
          `, [item.id, item.username, item.password, item.wallet?.balance ?? null]);
        } catch (error) {
          console.error(`Error inserting user record: ${JSON.stringify(item)} - ${error.message}`);
        }
      });
    } else if (tableName === 'investments') {
      data.forEach((item) => {
        try {
          db.run(`
            INSERT INTO investments (id, name, amount)
            VALUES (?, ?, ?);
          `, [item.id, item.name, item.amount ?? null]);
        } catch (error) {
          console.error(`Error inserting investment record: ${JSON.stringify(item)} - ${error.message}`);
        }
      });
    } else if (tableName === 'wishlist') {
      data.forEach((item) => {
        try {
          db.run(`
            INSERT INTO wishlist (id, investment_id, name, current_value, amount, user_id)
            VALUES (?, ?, ?, ?, ?, ?);
          `, [item.id, item.investmentId, item.name, item.currentValue ?? null, item.amount ?? null, item.userId]);
        } catch (error) {
          console.error(`Error inserting wishlist record: ${JSON.stringify(item)} - ${error.message}`);
        }
      });
    } else if (tableName === 'transactions') {
      data.forEach((userTransactions) => {
        const userId = userTransactions.userId;
        userTransactions.transactions.forEach((transaction) => {
          try {
            db.run(`
              INSERT INTO transactions (id, type, amount, date, current_value, investment_id, user_id)
              VALUES (?, ?, ?, ?, ?, ?, ?);
            `, [transaction.id, transaction.type, transaction.amount ?? null, transaction.date, transaction.currentValue ?? null, transaction.investmentId ?? null, userId]);
          } catch (error) {
            console.error(`Error inserting transaction record: ${JSON.stringify(transaction)} - ${error.message}`);
          }
        });
      });
    }
  }

  // Save the database to a file
  const data = db.export();
  fs.writeFileSync(dbFilePath, Buffer.from(data));

  // Close the database
  db.close();

  // Load the database from a file
  const fileBuffer = fs.readFileSync(dbFilePath);
  const dbLoaded = new SQL.Database(fileBuffer);

  // Query data
  const result = dbLoaded.exec('SELECT id, username FROM users');
  result[0].values.forEach(row => {
    console.log(`ID: ${row[0]}, Username: ${row[1]}`);
  });

  // Close the loaded database
  dbLoaded.close();
})();
