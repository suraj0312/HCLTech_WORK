import client from '@utils/apolloClient';
import {gql} from '@apollo/client';

const FETCH_WALLET_BALANCE = gql`
    query FetchWalletBalance {
        wallet {
            balance
        }
    }
`;

const UPDATE_WALLET_BALANCE = gql`
    mutation UpdateWalletBalance($balance: Float!, $type: String!) {
        updateWallet(balance: $balance, type: $type) {
            balance
        }
    }
`;

export const fetchWalletBalance = async () => {
    const {data} = await client.query({
        query: FETCH_WALLET_BALANCE,
        fetchPolicy: 'no-cache',
    });
    return data.wallet.balance;
};

export const updateWalletBalance = async (balance: number, type: string) => {
    const {data} = await client.mutate({
        mutation: UPDATE_WALLET_BALANCE,
        variables: {balance, type},
    });
    return data.updateWallet.balance;
};
