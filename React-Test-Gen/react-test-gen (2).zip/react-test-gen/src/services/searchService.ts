import client from '@utils/apolloClient';
import {gql} from '@apollo/client';
import {SearchResult} from '@_types/Investment';

const SEARCH_INVESTMENTS = gql`
    query SearchInvestments($query: String!) {
        searchInvestments(query: $query) {
            id
            name
        }
    }
`;

export const searchInvestmentsService = async (query: string, signal: AbortSignal): Promise<SearchResult[]> => {
    const {data} = await client.query({
        query: SEARCH_INVESTMENTS,
        variables: {query},
        context: {
            fetchOptions: {
                signal,
            },
        },
    });
    return data.searchInvestments;
};