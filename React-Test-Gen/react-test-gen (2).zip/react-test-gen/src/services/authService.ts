import client from '@utils/apolloClient';
import {gql} from '@apollo/client';
import jwt from 'jsonwebtoken';

const LOGIN_USER = gql`
    mutation LoginUser($username: String!, $password: String!) {
        loginUser(username: $username, password: $password) {
            token
            user {
                id
                username
            }
        }
    }
`;

const REGISTER_USER = gql`
    mutation RegisterUser($username: String!, $password: String!) {
        registerUser(username: $username, password: $password) {
            token
            user {
                id
                username
            }
        }
    }
`;

const REFRESH_TOKEN = gql`
    mutation RefreshToken {
        refreshToken {
            token
        }
    }
`;

export const loginUser = async (username: string, password: string) => {
    const {data} = await client.mutate({
        mutation: LOGIN_USER,
        variables: {username, password},
    });
    return data.loginUser;
};

export const registerUser = async (username: string, password: string) => {
    const {data} = await client.mutate({
        mutation: REGISTER_USER,
        variables: {username, password},
    });
    return data.registerUser;
};

export const refreshToken = async () => {
    const {data} = await client.mutate({
        mutation: REFRESH_TOKEN,
    });
    return data.refreshToken;
};

export const logoutUser = () => {
    localStorage.removeItem('authToken');
    return true;
};
export const checkAuthState = (): boolean => {
    const token = localStorage.getItem('authToken');
    if (!token) {
        return false;
    }

    try {
        const decoded = jwt.decode(token) as { exp: number };
        if (!decoded || Date.now() >= decoded.exp * 1000) {
            localStorage.removeItem('authToken');
            return false;
        }
        return true;
    } catch (error) {
        console.error('Failed to decode token:', error);
        localStorage.removeItem('authToken');
        return false;
    }
};
