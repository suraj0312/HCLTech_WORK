'use client';
import React, { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import styles from '@styles/Global.module.css';

interface ButtonProps {
    onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    children: React.ReactNode;
    className?: string;
    href?: string;
    prefetch?: boolean;
    disabled?: boolean;
    type?: 'button' | 'submit' | 'reset';
}

const Button: React.FC<ButtonProps> = ({ onClick, children, className, href, prefetch = true, disabled = false, type }) => {
    const router = useRouter();

    // useEffect(() => {
    //     if (href && prefetch) {
    //         console.log('Prefetching:', href);
    //         try {
    //             router.prefetch(href);
    //             console.log(`Prefetch successful for ${href}`);
    //         } catch (error: unknown) {
    //             console.error(`Prefetch failed for ${href}:`, error);
    //         }

    //     }
    // }, [href, prefetch, router]);

    const handleClick = async (event: React.MouseEvent<HTMLButtonElement>) => {
        if (onClick) {
            onClick(event);
        }
        if (href) {
            router.push(href);
        }
    };

    return (
        <button
        {...(type && { type })}
        onClick={disabled ? undefined : handleClick} className={className || styles.button} disabled={disabled}>
            {children}
        </button>
    );
};

export default Button;
