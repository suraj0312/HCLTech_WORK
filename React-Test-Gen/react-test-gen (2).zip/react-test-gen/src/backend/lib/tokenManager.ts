import fs from 'fs';
import path from 'path';

const filePath = path.join(process.cwd(), 'src', 'backend', 'modules', 'auth', 'tokens.json');

function readTokens(): string[] {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([]));
    }
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
}

function writeTokens(tokens: string[]): void {
    fs.writeFileSync(filePath, JSON.stringify(tokens, null, 2));
}

export const addToken = (token: string): void => {
    const tokens = readTokens();
    tokens.push(token);
    writeTokens(tokens);
};

    // export const removeToken = (token: string): void => {
    //     let tokens = readTokens();
    //     tokens = tokens.filter(activeToken => activeToken !== token);
    //     writeTokens(tokens);
    // };

export const isTokenActive = (token: string): boolean => {
    const tokens = readTokens();
    return tokens.includes(token);
};

export const getAllTokens = (): string[] => {
    return readTokens();
};
