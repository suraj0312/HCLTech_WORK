import {mergeTypeDefs} from '@graphql-tools/merge';
import baseSchema from '../modules/baseSchema';
import authSchema from '../modules/auth/authSchema';
import investmentSchema from '../modules/investments/investmentSchema';
import walletSchema from '../modules/wallet/walletSchema';
import wishlistSchema from '../modules/wishlist/wishlistSchema';

const typeDefs = mergeTypeDefs([
    baseSchema,
    authSchema,
    investmentSchema,
    walletSchema,
    wishlistSchema,
]);

export default typeDefs;
