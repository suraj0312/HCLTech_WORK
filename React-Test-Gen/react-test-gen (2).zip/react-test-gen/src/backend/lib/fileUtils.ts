import fs from 'fs';
import path from 'path';
import { pipeline, Readable } from 'stream';
import { promisify } from 'util';
import { createReadStream, createWriteStream } from 'fs';
import initSqlJs from 'sql.js';

const pipelineAsync = promisify(pipeline);

export interface FilePathConfig {
  [key: string]: string;
}
const baseDir = path.join(process.cwd(), 'src', 'backend', 'modules');

const filePaths: FilePathConfig = {
  users: path.join(baseDir, 'auth', 'users.json'),
  investments: path.join(baseDir, 'investments', 'investments.json'),
  wishlist: path.join(baseDir, 'wishlist', 'wishlist.json'),
  transactions: path.join(baseDir, 'investments', 'transactions.json'),
};

export async function readFile<T>(key: string): Promise<T[]> {
  const filePath = filePaths[key];
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([]));
  }

  const chunks: Buffer[] = [];
  const readStream = createReadStream(filePath, { encoding: 'utf-8' });

  try {
    for await (const chunk of readStream) {
      chunks.push(Buffer.from(chunk));
    }

    const data = Buffer.concat(chunks).toString();
    // console.log('Raw data length:', data.length); 
    // console.log('Raw data:', data);  

    if (!data) {
      return [];
        }
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading or parsing file:', error);
    throw new Error('Failed to read or parse file data');
  }
}

export async function writeFile<T>(key: string, data: T[]): Promise<void> {
  const filePath = filePaths[key];
  const writeStream = createWriteStream(filePath, { encoding: 'utf-8' });

  try {
    await pipelineAsync(
      Readable.from(JSON.stringify(data, null, 2)),
      writeStream
    );
  } catch (error) {
    console.error('Error writing file:', error);
    throw new Error('Failed to write file data');
  }
}

// Initialize database
export const initDb = async () => {
  const SQL = await initSqlJs();
  const fileBuffer = fs.readFileSync(dbFilePath);
  return new SQL.Database(new Uint8Array(fileBuffer));
};

// Execute SQL query
export const executeQuery = async (db: any, query: string, params: any[] = []) => {
  const stmt = db.prepare(query);
  if (params.length > 0) {
    stmt.bind(params);
  }
  try {
    if (query.trim().toLowerCase().startsWith('select')) {
      const results: any[] = [];
      while (stmt.step()) {
        results.push(stmt.getAsObject());
      }
      return results;
    } else {
      stmt.run();
    }
  } finally {
    stmt.free();
  }
};

// Save changes to database
export const saveChanges = async (db: any) => {
  const dataExport = db.export();
  fs.writeFileSync(dbFilePath, Buffer.from(dataExport));
};

// Close database connection
export const closeDb = async (db: any) => {
  db.close();
};

export const dbFilePath = path.join(baseDir, 'database.db');