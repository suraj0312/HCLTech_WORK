import { IResolvers } from '@graphql-tools/utils';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { AuthenticationError, UserInputError } from 'apollo-server-micro';
import { validateLoginUser, validateRegisterUser } from './authValidation';
import { readUserByUsername, readUserById, saveToken, removeToken, saveUser, readToken } from './fileUtils';

const SECRET_KEY = process.env.SECRET_KEY ?? 'your_secret_key';



const authResolvers: IResolvers<unknown, { userId: string; token: string }> = {
  Query: {
    getUserDetails: async (_, { userId }) => {
      const user = await readUserById(userId);
      if (!user) throw new AuthenticationError('User not found');
      return user;
    },
    getUserInvestmentHistory: async (_, { userId }) => {
      const user = await readUserById(userId);
      if (!user) throw new AuthenticationError('User not found');
      return [];
    },
  },
  Mutation: {
    registerUser: async (_, { username, password }) => {
      validateRegisterUser({ username, password });
      const existingUser = await readUserByUsername(username);
      if (existingUser) {
        throw new UserInputError('Username is already taken');
      }
      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = await saveUser(username, hashedPassword);
      console.log(newUser)
      const token = jwt.sign({ userId: newUser.id }, SECRET_KEY, { expiresIn: '1h' });
      const expiresAt = new Date(Date.now() + 3600 * 1000).toISOString();  
      await saveToken(token, newUser.id, expiresAt);
      return { token, user:newUser };

    },
    loginUser: async (_, { username, password }) => {
      validateLoginUser({ username, password });
      const user = await readUserByUsername(username);
      if (!user) throw new AuthenticationError('Invalid credentials');
      const valid = await bcrypt.compare(password, user.password);
      if (!valid) throw new AuthenticationError('Invalid credentials');
      const token = jwt.sign({ userId: user.id }, SECRET_KEY, { expiresIn: '1h' });
      const expiresAt = new Date(Date.now() + 3600 * 1000).toISOString();  
      await saveToken(token, user.id, expiresAt);
      return { token, user };
    },
    logoutUser: async (_, __, { token }) => {
      await removeToken(token);
      return true;
    },
    refreshToken: async (_, __, { token }) => {
      const tokenData = await readToken(token);
      if (!tokenData || new Date(tokenData.expires_at) < new Date()) {
        throw new AuthenticationError('Invalid or expired token');
      }
      const decoded = jwt.verify(token, SECRET_KEY) as { userId: string };
      const newToken = jwt.sign({ userId: decoded.userId }, SECRET_KEY, { expiresIn: '1h' });
      await saveToken(newToken, decoded.userId, new Date(Date.now() + 3600 * 1000).toISOString());
      return { token: newToken, user: await readUserById(decoded.userId) };
    },
  },
};

export default authResolvers;