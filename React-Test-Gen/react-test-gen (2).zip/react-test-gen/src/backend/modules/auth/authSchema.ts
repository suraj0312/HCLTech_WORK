import { gql } from 'apollo-server-micro';

const authSchema = gql`
    type Query {
        getUserDetails(userId: ID!): User
        getUserInvestmentHistory(userId: ID!): [Transaction]
    }

    type Transaction {
  id: ID!
  type: String!
  amount: Float!
  date: String!   
  current_value: Float
  investment_id: String
  user_id: String!
    }

    type Mutation {
        registerUser(username: String!, password: String!): AuthPayload
        loginUser(username: String!, password: String!): AuthPayload
        logoutUser(token: String!): Boolean
        refreshToken: AuthPayload
    }

    type User {
        id: ID!
        username: String!
        password: String!
        wallet: Wallet
    }

    type Wallet {
        balance: Float
    }

    type AuthPayload {
        token: String!
        user: User!
    }
`;

export default authSchema;
