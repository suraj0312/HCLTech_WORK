import path from 'path';

const filePath = path.join(process.cwd(), 'src', 'backend', 'modules', 'auth', 'users.json');
export default filePath;