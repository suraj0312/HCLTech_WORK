export interface WishlistItem {
  id: string;
  investment_id: string;
  name: string;
  current_value: number;
  amount: number;
  user_id: string;
}
