import path from 'path';

const filePath = path.join(process.cwd(), 'src', 'backend', 'modules', 'wishlist', 'wishlist.json');
export default filePath;