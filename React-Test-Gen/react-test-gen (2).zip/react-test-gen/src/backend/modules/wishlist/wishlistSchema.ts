import { gql } from 'apollo-server-micro';

const wishlistSchema = gql`
    type WishlistItem {
        id: ID
        name: String
        current_value: Float
        amount: Float
        investment_id: String
    }

    type WishlistPage {
        wishlist: [WishlistItem]
        totalCount: Int
    }
        
    type RemoveWishlistResponse {
  removedItem: WishlistItem
    nextItem: WishlistItem
  totalCount: Int
    }

    type AddToWishlistResponse {
    wishlistItem: WishlistItem
    totalCount: Int
  }

    extend type Query {
        wishlist(page: Int, limit: Int): WishlistPage
    }
        

    extend type Mutation {
        addToWishlist(id: ID!): AddToWishlistResponse
        removeFromWishlist(id: ID!, limit: Int!, pageNumber: Int!): RemoveWishlistResponse
        saveTransaction(id: ID!, type: String!, amount: Float!): Transaction
    }
`;

export default wishlistSchema;
