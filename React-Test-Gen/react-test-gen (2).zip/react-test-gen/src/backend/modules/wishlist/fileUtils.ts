import { initDb, executeQuery, closeDb, saveChanges } from '@backend/lib/fileUtils';
import { WishlistItem } from './types';
import { UserInputError } from 'apollo-server-micro';
import { Investment } from '../investments/types';

export const getWishlist = async (user_id: string, limit: number, offset: number): Promise<{ wishlist: WishlistItem[], totalCount: number }> => {
  let db;
  try {
    db = await initDb();
    const results = await executeQuery(db, 'SELECT * FROM wishlist WHERE user_id = ? LIMIT ? OFFSET ?', [user_id, limit, offset]);
    if (results === undefined) {
      throw new Error("Query returned no results");
    }

    const wishlist: WishlistItem[] = results.map(row => ({
      id: row.id,
      investment_id: row.investment_id,
      name: row.name,
      current_value: row.current_value,
      amount: row.amount,
      user_id: row.user_id,
    }));

    const countResults = await executeQuery(db, 'SELECT COUNT(*) as count FROM wishlist WHERE user_id = ?', [user_id]);
    if (countResults === undefined) {
      throw new Error("Query returned no results");
    }
    const totalCount = countResults[0].count;

    return { wishlist, totalCount };
  } catch (error) {
    console.error('Error:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
};

export const getInvestmentById = async (id: string): Promise<Investment | null> => {
  let db;
  try {
    db = await initDb();
    const results = await executeQuery(db, 'SELECT * FROM investments WHERE id = ?', [id]);
    if (results === undefined) {
      throw new Error("Query returned no results");
    }
    if (results.length === 0) {
      return null;
    }
    const row = results[0];
    return {
      id: row.id,
      name: row.name,
      amount: row.amount,
    } as Investment;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
};

export const checkWishlistItem = async (id: string, user_id: string): Promise<boolean> => {
  let db;
  try {
    db = await initDb();
    const results = await executeQuery(db, 'SELECT * FROM wishlist WHERE investment_id = ? AND user_id = ?', [id, user_id]);
    if (results === undefined) {
      throw new Error("Query returned no results");
    }
    return results.length > 0;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
};

export const addWishlistItem = async (wishlistItem: WishlistItem): Promise<number> => {
  let db;
  try {
    db = await initDb();
    await executeQuery(db, 'INSERT INTO wishlist (id, investment_id, name, current_value, amount, user_id) VALUES (?, ?, ?, ?, ?, ?)', [
      wishlistItem.id,
      wishlistItem.investment_id,
      wishlistItem.name,
      wishlistItem.current_value,
      wishlistItem.amount,
      wishlistItem.user_id,
    ]);
    await saveChanges(db);

    const countResults = await executeQuery(db, 'SELECT COUNT(*) as count FROM wishlist WHERE user_id = ?', [wishlistItem.user_id]);
    if (countResults === undefined) {
      throw new Error("Query returned no results");
    }
    const totalCount = countResults[0].count;

    return totalCount;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
};

export const removeWishlistItem = async (id: string, user_id: string, limit: number, offset: number): Promise<{ removedItem: WishlistItem, nextItem: WishlistItem | null, totalCount: number }> => {
  let db;
  try {
    db = await initDb();
    const results = await executeQuery(db, 'SELECT * FROM wishlist WHERE (investment_id = ? OR id = ?) AND user_id = ?', [id, id, user_id]);
    if (results === undefined) {
      throw new Error("Query returned no results");
    }
    if (results.length === 0) {
      throw new UserInputError('Investment not found in wishlist');
    }
    const row = results[0];
    const removedItem: WishlistItem = {
      id: row.id,
      investment_id: row.investment_id,
      name: row.name,
      current_value: row.current_value,
      amount: row.amount,
      user_id: row.user_id,
    };

    await executeQuery(db, 'DELETE FROM wishlist WHERE (investment_id = ? OR id = ?) AND user_id = ?', [id, id, user_id]);
    await saveChanges(db);

    const nextResults = await executeQuery(db, 'SELECT * FROM wishlist WHERE user_id = ? LIMIT 1 OFFSET ?', [user_id, offset + 1]);
    if (nextResults === undefined) {
      throw new Error("Query returned no results");
    }
    const nextItem = nextResults.length > 0 ? {
      id: nextResults[0].id,
      investment_id: nextResults[0].investment_id,
      name: nextResults[0].name,
      current_value: nextResults[0].current_value,
      amount: nextResults[0].amount,
      user_id: nextResults[0].user_id,
    } : null;

    const countResults = await executeQuery(db, 'SELECT COUNT(*) as count FROM wishlist WHERE user_id = ?', [user_id]);
    if (countResults === undefined) {
      throw new Error("Query returned no results");
    }
    const totalCount = countResults[0].count;

    return { removedItem, nextItem, totalCount };
  } catch (error) {
    console.error('Error:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
};