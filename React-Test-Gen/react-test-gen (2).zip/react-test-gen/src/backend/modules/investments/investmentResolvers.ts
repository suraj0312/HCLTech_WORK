import {validateAddInvestment} from './investmentValidation';
import {UserInputError} from 'apollo-server-micro';
import {addInvestment, deleteInvestment, getInvestment, purchaseHistory , purchaseInvestment, readInvestments,  searchInvestments, sellInvestment, updateInvestment} from './fileUtils';
import {IResolvers} from '@graphql-tools/utils';
// import {readUsers, writeUsers} from "@backend/modules/auth/fileUtils";
// import {readWishlist, writeWishlist} from "@backend/modules/wishlist/fileUtils";
// import { v4 as uuidv4 } from 'uuid';
interface Investment {
    id: string;
    name: string;
    amount: number;
}

class InvestmentResolvers {
    constructor() {
        this.investments = this.investments.bind(this);
        this.getInvestment = this.getInvestment.bind(this);
        this.searchInvestments = this.searchInvestments.bind(this);
        this.addInvestment = this.addInvestment.bind(this);
        this.updateInvestment = this.updateInvestment.bind(this);
        this.deleteInvestment = this.deleteInvestment.bind(this);
        this.purchaseInvestment = this.purchaseInvestment.bind(this);
        this.sellInvestment = this.sellInvestment.bind(this);
        this.purchaseHistory = this.purchaseHistory.bind(this);
    }

    async investments(_: unknown, {page = 1, limit = 10}: { page: number; limit: number }, { userId }: { userId: string }) {
        try {
            const { investments, totalCount } = await readInvestments(page, limit, userId);
            return {
              investments,
              totalCount,
            };
          } catch (error) {
            throw new UserInputError(`Failed to fetch investments: ${(error as Error).message}`);
          }
    
  
    }

    async getInvestment(_: unknown, {id}: { id: string }): Promise<Investment> {
        return getInvestment(id);
    }

    async searchInvestments(_: unknown, {query}: { query: string }): Promise<Investment[]> {
        if (query.length < 3) {
            return [];
        }
        return searchInvestments(query);

            // const lowerCaseQuery = query.trim().toLowerCase();
            // const queryWords = lowerCaseQuery.split(' ');
            // const result =await readInvestments();
            // return  result.filter(investment => {
            //     const lowerCaseName = investment.name.toLowerCase();
            //     return queryWords.every(word => lowerCaseName.includes(word));
            // });
    }

    async addInvestment(_: unknown, {name, amount}: { name: string; amount: number }): Promise<Investment> {
        validateAddInvestment({ name, amount });
        return addInvestment(name, amount);
        }

    async updateInvestment(_: unknown, {id, name, amount}: { id: string; name?: string; amount?: number }): Promise<Investment> {
        return updateInvestment(id, name, amount);
    }

    async deleteInvestment (_: unknown, {id}: { id: string }): Promise<Investment> {
        return deleteInvestment(id);
    }

    async purchaseInvestment (_: unknown, {id}: { id: string }, {userId}: { userId: string }): Promise<Investment> {
        return purchaseInvestment(id, userId);

        //     try {

    //      const investments = await readInvestments();
    //     const transactions =await readTransactions();
    //     const users = await readUsers();
    //     const wishlist = await readWishlist();
    //     const investment = investments.find(investment => investment.id === id);
    //     const user = users.find(user => user.id === userId);

    //     if (!investment) {
    //         throw new UserInputError('Investment not found');
    //     }

    //     if (!user) {
    //         throw new UserInputError('User not found');
    //     }

    //     if (user.wallet.balance < investment.amount) {
    //         throw new UserInputError('Insufficient balance to purchase this investment');
    //     }

    //     let userTransactions = transactions.find(t => t.userId === userId);
    //     if (!userTransactions) {
    //         userTransactions = {userId: userId,  transactions: []};
    //         transactions.push(userTransactions);
    //     }

    //     const randomValue = Math.floor(Math.random() * (500 - 100 + 1)) + 100;
    //     const shouldAdd = Math.random() >= 0.5;
    //     let amount = investment.amount;
    //     amount = shouldAdd ? amount + randomValue : Math.abs(amount - randomValue);

    //     const transaction = {
    //         id: uuidv4(),
    //         type: 'purchase',
    //         amount: investment.amount,
    //         date: new Date().toISOString(),
    //         current_value: amount,
    //         investment_id: id
    //     };
    //     userTransactions.transactions.push(transaction);
    //      user.wallet.balance -= investment.amount;
    //      const wishlistIndex = wishlist.findIndex(item => item.investment_id === id && item.userId === userId);
    //      if (wishlistIndex !== -1) {
    //          wishlist.splice(wishlistIndex, 1);
    //      }
 
    //      await writeTransactions(transactions);
    //     await writeUsers(users);
    //     await writeWishlist(wishlist);

    //     // writeInvestments(investments);
    //     return investment;
    // } catch (error) {
    //     throw new UserInputError(`Failed to purchase investment: ${(error as Error).message}`);
    //   }
  
    }

    async sellInvestment(_: unknown, {id, amount}: { id: string; amount: number }, {userId}: { userId: string }): Promise<Investment> {
        return sellInvestment(id, amount, userId);

        // const investments =await readInvestments();
        // const transactions =await readTransactions();
        // const investment = investments.find(investment => investment.id === id);
        // if (!investment) {
        //     throw new UserInputError('Investment not found');
        // }

        // if (amount > investment.amount) {
        //     throw new UserInputError('Insufficient amount to sell');
        // }


        // let userTransactions = transactions.find(t => t.userId === userId);
        // if (!userTransactions) {
        //     userTransactions = {userId, transactions: []};
        //     transactions.push(userTransactions);
        // }

        // const transaction = {
        //     id: uuidv4(),
        //     type: 'sell',
        //     amount,
        //     date: new Date().toISOString(),
        //     current_value:amount,
        //     investment_id: id
        // };
        // userTransactions.transactions.push(transaction);
        // writeTransactions(transactions);

        // writeInvestments(investments);
        // return investment;
    }

   async purchaseHistory(_: unknown, __: unknown, {userId}: { userId: string }) {
    return purchaseHistory(userId);
    }
}

const investmentResolversInstance = new InvestmentResolvers();
const investmentResolvers: IResolvers = {
    Query: {
        investments: investmentResolversInstance.investments,
        getInvestment: investmentResolversInstance.getInvestment,
        searchInvestments: investmentResolversInstance.searchInvestments,
        purchaseHistory: investmentResolversInstance.purchaseHistory,
    },
    Mutation: {
        addInvestment: investmentResolversInstance.addInvestment,
        updateInvestment: investmentResolversInstance.updateInvestment,
        deleteInvestment: investmentResolversInstance.deleteInvestment,
        purchaseInvestment: investmentResolversInstance.purchaseInvestment,
        sellInvestment: investmentResolversInstance.sellInvestment,
    },
};

export default investmentResolvers;