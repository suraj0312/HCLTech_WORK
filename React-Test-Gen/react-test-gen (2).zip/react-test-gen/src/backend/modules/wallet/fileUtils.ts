import { initDb, executeQuery, closeDb, saveChanges } from '@backend/lib/fileUtils';
import { User, Transaction } from '@backend/modules/auth/types';

export async function readUser(userId: string): Promise<User | null> {
    let db;
    try {
        db = await initDb();
        const results = await executeQuery(db, 'SELECT * FROM users WHERE id = ? limit 1', [userId]);
        if (!results || results.length === 0) {
            throw new Error('Query returned no results');
        }
        const row = results[0];
        const user: User = {
            id: row.id,
            username: row.username,
            password: row.password,
            wallet_balance: row.wallet_balance
        };
        return user;
    } catch (error) {
        console.error('Error reading user:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function updateUser(user: User): Promise<void> {
    let db;
    try {
        db = await initDb();
        await executeQuery(db, 'UPDATE users SET wallet_balance = ? WHERE id = ?', [user.wallet_balance, user.id]);
        await saveChanges(db);
    } catch (error) {
        console.error('Error updating user:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function readUserTransactions(userId: string): Promise<Transaction[]> {
    let db;
    try {
        db = await initDb();
        const results = await executeQuery(db, 'SELECT * FROM transactions WHERE user_id = ?', [userId]);
        if (!results) {
            throw new Error('Query returned no results');
        }
        const transactions: Transaction[] = results.map(row => ({
            id: row.id,
            type: row.type,
            amount: row.amount,
            date: row.date,
            current_value: row.current_value,
            investment_id: row.investment_id,
            user_id: row.user_id
        }));
        return transactions;
    } catch (error) {
        console.error('Error reading user transactions:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function addTransaction(transaction: Transaction): Promise<void> {
    let db;
    try {
        db = await initDb();
        await executeQuery(db, 'INSERT INTO transactions (id, type, amount, date, current_value, investment_id, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)', 
            [transaction.id, transaction.type, transaction.amount, transaction.date, transaction.current_value ?? null, transaction.investment_id ?? null, transaction.user_id]);
        await saveChanges(db);
    } catch (error) {
        console.error('Error adding transaction:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}