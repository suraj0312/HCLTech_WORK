export interface WishlistItem {
    id: string;
    name: string;
    current_value?: number;
    amount: number | null;
    investment_id: string;
}

export interface Payload {
    id: string;
    limit: number;
    pageNumber: number;
    wishListpageNumber: number;
  }
  
  export interface RemovedItem {
    id: string;
    investment_id?: string;
  }
  
  export interface WishlistResponse {
    removedItem: RemovedItem;
    nextItem?: any;
    totalCount: number;
  }