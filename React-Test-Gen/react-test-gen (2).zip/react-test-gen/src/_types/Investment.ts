export interface Investment {
    id: string;
    name: string;
    amount: number;
    investment_id:string;
    current_value: number | null;
    date: string;
    type?: string;
    isInWishlist: boolean
}

export interface Transaction {
    id: string;
    type: string;
    amount: number;
    date: string;
    current_value:number;
}

export interface SearchResult {
    id: string;
    name: string;
}

export interface MFDetails {
    id: string;
    name: string;
    amount: number;
    current_value: number;
}

export interface InvestmentDetails {
    id: string;
    name: string;
    amount: number;
    current_value: number | null;
}