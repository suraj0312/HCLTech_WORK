export type DateFormat = 'MM/DD/YYYY' | 'DD/MM/YYYY';

  const config = {
      wishlist: {
        itemPerPage: 2,
      },
      investments: {
        itemPerPage: 2,
      },
      dashboard:{
        wishlist: {
          itemPerPage: 2,
        },
        investments: {
          itemPerPage: 2,
        },
      },
      currency:'₹',
      dateFormat: 'MM/DD/YYYY' as DateFormat

    };
    
    export default config;
    