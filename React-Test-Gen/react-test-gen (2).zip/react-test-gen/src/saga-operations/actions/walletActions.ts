import {createAction} from '@reduxjs/toolkit';

export const fetchBalanceStart = createAction('wallet/fetchBalanceStart');
export const fetchBalanceSuccess = createAction<number>('wallet/fetchBalanceSuccess');
export const fetchBalanceFailure = createAction<string>('wallet/fetchBalanceFailure');
export const addBalance = createAction<number>('wallet/addBalance');
export const withdrawBalance = createAction<number>('wallet/withdrawBalance');
