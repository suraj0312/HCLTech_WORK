import {createAction} from '@reduxjs/toolkit';
import {SearchResult} from '@_types/Investment';

interface SearchPayload {
    query: string;
}

export const searchInvestmentsStart = createAction<SearchPayload>('search/searchInvestmentsStart');
export const searchInvestmentsSuccess = createAction<SearchResult[]>('search/searchInvestmentsSuccess');
export const searchInvestmentsFailure = createAction<string>('search/searchInvestmentsFailure');
  