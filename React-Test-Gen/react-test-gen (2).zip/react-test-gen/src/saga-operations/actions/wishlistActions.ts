import {createAction} from '@reduxjs/toolkit';
import {WishlistItem} from '@_types/WishlistItem';


export const fetchWishlistStart = createAction<{ page: number; limit: number }>('wishlist/fetchWishlistStart');
export const fetchWishlistSuccess = createAction<{
    wishlist: WishlistItem[];
    totalCount: number;
    newPageNumber?: number;
}>('wishlist/fetchWishlistSuccess');
export const fetchWishlistFailure = createAction<string>('wishlist/fetchWishlistFailure');
export const addToWishlistSuccess = createAction<{ id: string }>('wishlist/addToWishlistSuccess');
export const addToWishlistStart = createAction<{ id: string }>('wishlist/addToWishlistStart');
export const removeFromWishlistStart = createAction<{ id: string; limit: number; pageNumber: number,wishListpageNumber:number; }>('wishlist/removeFromWishlistStart');

export const removeFromWishlistSuccess = createAction<{ id: string; nextItem: WishlistItem | null; totalCount: number;   }>('wishlist/removeFromWishlistSuccess');

export const setWishlistPage = createAction<{page: number;message?:string | null;}>('wishlist/setWishlistPage')