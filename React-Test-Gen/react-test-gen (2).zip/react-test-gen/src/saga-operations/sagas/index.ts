import {all} from 'redux-saga/effects';
import authSaga from './authSaga';
import watchInvestmentSaga from './investmentSaga';
import watchWalletSaga from './walletSaga';
import watchWishlistSaga from './wishlistSaga';
import watchSearchSaga from './searchSaga';

export default function* rootSaga() {
    yield all([
        authSaga(),
        watchInvestmentSaga(),
        watchWalletSaga(),
        watchWishlistSaga(),
        watchSearchSaga(),
    ]);
}