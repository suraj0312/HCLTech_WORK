import {call, cancelled, put, takeLatest} from 'redux-saga/effects';
import {PayloadAction} from '@reduxjs/toolkit';
import {searchInvestmentsFailure, searchInvestmentsStart, searchInvestmentsSuccess} from '../actions/searchActions';
import {searchInvestmentsService} from '@services/searchService';
import {SearchResult} from '@_types/Investment';

interface SearchPayload {
    query: string;
}

function* searchInvestmentsSaga({ payload: { query } }: PayloadAction<SearchPayload>): Generator {
    const abortController = new AbortController();
    const signal = abortController.signal;
    //console.log('ye')
    try {
        const data: SearchResult[] = yield call(searchInvestmentsService, query, signal);
        yield put(searchInvestmentsSuccess(data));
    } catch (error) {
        if (error !== 'AbortError') {
            yield put(searchInvestmentsFailure((error as Error).message));
        }
    } finally {
        if (yield cancelled()) {
            abortController.abort();
        }
    }
}

export default function* watchSearchInvestments() {
    yield takeLatest(searchInvestmentsStart.type, searchInvestmentsSaga);
}
