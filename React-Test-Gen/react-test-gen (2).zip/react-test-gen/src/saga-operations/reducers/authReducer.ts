import {createSlice, PayloadAction} from '@reduxjs/toolkit';

export interface AuthState {
    isLoggedIn: boolean | null;
    loading: boolean | null;
    error: string | null;
    hasNavigated: boolean;
}

const initialState: AuthState = {
    isLoggedIn: null,
    loading: null,
    error: null,
    hasNavigated: false,
};

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        loginStart(state) {
            //console.log('loginStart action dispatched');
            state.loading = true;
            state.error = null;
            state.hasNavigated = false;
        },
        loginSuccess(state) {
            //console.log('loginSuccess action dispatched');
            state.isLoggedIn = true;
            state.loading = false;
            state.hasNavigated = true;
        },
        loginFailure(state, action: PayloadAction<string>) {
            //console.log('loginFailure action dispatched');
            state.loading = false;
            state.error = action.payload;
        },
        registerAuthStart(state) {
            //console.log('registerAuthStart action dispatched');
            state.loading = true;
            state.isLoggedIn = false;
        },
        logoutStart(state) {
            //console.log('logoutStart action dispatched', JSON.stringify(state, null, "\t"));
            state.isLoggedIn = false;
            state.loading = false;
            state.hasNavigated = false;
        },
        logoutSuccess(state) {
            //console.log('logoutSuccess dispatched', JSON.stringify(state, null, "\t"));
            state.isLoggedIn = false;
            state.loading = false;
        },
        fetchAuthStateStart(state) {
            //console.log('fetchAuthStateStart action dispatched');
            state.loading = null;
            state.isLoggedIn = null;
            state.error = null;
        },
        fetchAuthStateSuccess(state, action: PayloadAction<boolean>) {
            //console.log('fetchAuthStateSuccess action dispatched');
            state.isLoggedIn = action.payload;
            state.loading = false;
        },
        fetchAuthStateFailure(state, action: PayloadAction<string>) {
            //console.log('fetchAuthStateFailure action dispatched');
            state.loading = false;
            state.error = action.payload;
        },
    checkAuthStateStart(state) {
      state.loading = true;
      state.error = null;
    },
    checkAuthStateSuccess(state, action: PayloadAction<boolean>) {
      state.isLoggedIn = action.payload;
      state.loading = false;
    },
    checkAuthStateFailure(state, action: PayloadAction<string>) {
      state.loading = false;
      state.error = action.payload;
    },
    setHasNavigated(state, action: PayloadAction<boolean>) {
        state.hasNavigated = action.payload;  
      },
  
    },
});

export const {
    loginStart,
    loginSuccess,
    loginFailure,
    logoutStart,
    fetchAuthStateStart,
    fetchAuthStateSuccess,
    fetchAuthStateFailure,
    logoutSuccess,
    registerAuthStart,
  checkAuthStateStart,
  checkAuthStateSuccess,
  checkAuthStateFailure,
  setHasNavigated
} = authSlice.actions;

export default authSlice.reducer;