import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Investment, InvestmentDetails, Transaction } from '@_types/Investment';

interface InvestmentState {
    investments: Investment[];
    totalCount: number;
    investmentDetails: InvestmentDetails | null;
    purchaseHistory: Transaction[];
    loading: boolean;
    error: string | null;
    purchaseSuccess: boolean;
}

const initialState: InvestmentState = {
    investments: [],
    totalCount: 0,
    investmentDetails: null,
    purchaseHistory: [],
    loading: false,
    error: null,
    purchaseSuccess: false,
};

const investmentSlice = createSlice({
    name: 'investment',
    initialState,
    reducers: {
        fetchInvestmentStart(state) {
            state.loading = true;
            state.error = null;
            state.purchaseSuccess = false;
        },
        fetchInvestmentSuccess(state, { payload }: PayloadAction<{ investments: Investment[]; totalCount: number }>) {
            state.investments = payload.investments;
            state.totalCount = payload.totalCount;
            state.loading = false;
            state.purchaseSuccess = false;
        },
        fetchInvestmentFailure(state, { payload }: PayloadAction<string>) {
            state.loading = false;
            state.error = payload;
            state.purchaseSuccess = false;
        },
        fetchInvestmentDetailsStart(state) {
            state.loading = true;
            state.error = null;
            state.purchaseSuccess = false;
            state.investments =[];
            state.totalCount =0;
        },
        fetchInvestmentDetailsSuccess(state, { payload }: PayloadAction<InvestmentDetails>) {
            state.investmentDetails = payload;
            state.loading = false;
            state.purchaseSuccess = false;
        },
        fetchInvestmentDetailsFailure(state, { payload }: PayloadAction<string>) {
            state.loading = false;
            state.error = payload;
            state.purchaseSuccess = false;
        },
        fetchPurchaseHistoryStart(state) {
            state.loading = true;
            state.error = null;
            state.purchaseSuccess = false;
        },
        fetchPurchaseHistorySuccess(state, { payload }: PayloadAction<Transaction[]>) {
            state.purchaseHistory = payload;
            state.loading = false;
            state.purchaseSuccess = false;
        },
        fetchPurchaseHistoryFailure(state, { payload }: PayloadAction<string>) {
            state.loading = false;
            state.error = payload;
            state.purchaseSuccess = false;
        },
        purchaseInvestmentStart(state) {
            state.loading = true;
            state.error = null;
            state.purchaseSuccess = false;
        },
        purchaseInvestmentSuccess(state, { payload }: PayloadAction<Investment>) {
            state.investments = [...state.investments, payload];
            state.loading = false;
            state.purchaseSuccess = true;
        },
        purchaseInvestmentFailure(state, { payload }: PayloadAction<string>) {
            state.loading = false;
            state.error = payload;
            state.purchaseSuccess = false;
        },
        updateInvestmentWishlistStatus(state, { payload }: PayloadAction<{ id: string; investment_id: string; isInWishlist: boolean }>) {
            // Find the investment using both `investment_id` and `id`
            const investment = state.investments.find(item => {
                const investmentId = item.investment_id ?? item.id;
                return (investmentId === payload.investment_id || item.id === payload.id);
            });
        
            // Update the `isInWishlist` status if the investment is found
            if (investment) {
                investment.isInWishlist = payload.isInWishlist;
            }          
         }
                        
    },
});

export const {
    fetchInvestmentStart,
    fetchInvestmentSuccess,
    fetchInvestmentFailure,
    fetchInvestmentDetailsStart,
    fetchInvestmentDetailsSuccess,
    fetchInvestmentDetailsFailure,
    fetchPurchaseHistoryStart,
    fetchPurchaseHistorySuccess,
    fetchPurchaseHistoryFailure,
    purchaseInvestmentStart,
    purchaseInvestmentSuccess,
    purchaseInvestmentFailure,
    updateInvestmentWishlistStatus
} = investmentSlice.actions;

export default investmentSlice.reducer;