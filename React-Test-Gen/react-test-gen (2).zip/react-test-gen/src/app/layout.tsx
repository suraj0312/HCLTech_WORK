'use client';
import React, {ReactNode} from 'react';
import {Provider} from 'react-redux';
import store from '../saga-operations/store';
import useAuth from '@hooks/useAuth';
import MainLayout from '@components/Layout/MainLayout';
import AuthLayout from '@components/Layout/AuthLayout';

interface LayoutProps {
    children: ReactNode;
}


const Layout: React.FC<LayoutProps> = ({children}) => {
    const {isLoggedIn, loading} = useAuth();
    
    if (isLoggedIn === null || loading === null) {
        return <div>Loading...</div>;
    }
    // if (loading) {
    //     return <div>Loading...</div>;
    // }
    return isLoggedIn ? <MainLayout isLoggedIn={isLoggedIn} loading={loading}>{children}</MainLayout> : <AuthLayout isLoggedIn={isLoggedIn} loading={loading}>{children}</AuthLayout>;
};

const RootLayout: React.FC<LayoutProps> = ({children}) => {
    
    return (
        <Provider store={store}>
            <html lang="en">
            <head>
                <title>My App</title>
                <meta charSet="UTF-8"/>
                <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
            </head>
            <body>
            <Layout>{children}</Layout>
            </body>
            </html>
        </Provider>
    );
};

export default RootLayout;