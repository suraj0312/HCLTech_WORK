'use client';

import React, {ComponentType, useEffect, useRef, useState} from 'react';
import dynamic from 'next/dynamic';
import {usePathname, useRouter} from 'next/navigation';
import {useAppDispatch, useAppSelector} from '@hooks/useAppSelector';
import {fetchAuthStateStart} from '@saga-operations/actions/authActions';
import Loading from '@components/Common/Loading';

const withAuth = <P extends object>(
    WrappedComponent: ComponentType<P>,
    allowUnauthenticated: boolean = false
): React.FC<P> => {
    const DynamicComponent = dynamic(() => Promise.resolve(WrappedComponent), {
        loading: () => <Loading/>,
        ssr: false,
    });

    const ComponentWithAuth: React.FC<P> = (props) => {
        const dispatch = useAppDispatch();
        const {isLoggedIn, loading} = useAppSelector((state) => state.auth);
        const router = useRouter();
        const pathname = usePathname();
        const [isLoading, setIsLoading] = useState<boolean | null>(null);
        const hasDispatched = useRef(false);

        useEffect(() => {
            if (!isLoggedIn && !loading && !hasDispatched.current) {
                dispatch(fetchAuthStateStart());
                hasDispatched.current = true;
                setIsLoading(true);
            }
        }, [dispatch, isLoggedIn, loading]);

        useEffect(() => {
            if (!loading && isLoading !== null) {
                if (isLoggedIn && allowUnauthenticated && (pathname === '/login' || pathname === '/register')) {
                    router.push('/dashboard');
                } else if (!isLoggedIn && !allowUnauthenticated) {
                    router.push('/login');
                } else {
                    setIsLoading(false);
                }
            }
        }, [isLoggedIn, loading, router, allowUnauthenticated, pathname, isLoading]);
        if(!allowUnauthenticated && !isLoggedIn){
            return <Loading/>;
        }
        if (!allowUnauthenticated && (loading || isLoading)) {
            return <Loading/>;
        }
       

        return <DynamicComponent {...props} />;
    };

    return React.memo(ComponentWithAuth);
};

export default withAuth;
