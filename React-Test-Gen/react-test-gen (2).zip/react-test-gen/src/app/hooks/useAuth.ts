'use client';
import {useCallback, useEffect, useRef} from 'react';
import {useRouter} from 'next/navigation';
import {useAppDispatch, useAppSelector} from '@hooks/useAppSelector';
import {fetchAuthStateStart, loginStart, logoutStart, registerStart} from '@saga-operations/actions/authActions';

const useAuth = () => {
    const dispatch = useAppDispatch();
    const {isLoggedIn, loading, error, hasNavigated} = useAppSelector((state) => state.auth);
    const router = useRouter();
    const hasDispatched = useRef(false);

    useEffect(() => {
        if (!hasDispatched.current) {
            dispatch(fetchAuthStateStart());
            hasDispatched.current = true;
        }
    }, [dispatch]);

    const handleLogin = useCallback((values: { username: string; password: string }): void => {
        console.log('login process started')
        dispatch(loginStart(values));
    }, [dispatch]);

    const handleRegister = useCallback((values: { username: string; password: string }): void => {
        dispatch(registerStart(values));
    }, [dispatch]);

    const handleLogout = useCallback(() => {
        dispatch(logoutStart());
        // router.push('/login');
    }, [dispatch, isLoggedIn, router]);

    return {
        isLoggedIn,
        loginUser: handleLogin,
        registerUser: handleRegister,
        logoutUser: handleLogout,
        loading,
        error,
        hasNavigated
    };
};

export default useAuth;