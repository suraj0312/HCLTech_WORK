import { useAppDispatch, useAppSelector } from './useAppSelector';
import {
    fetchInvestmentDetailsStart,
    fetchInvestmentStart,
    fetchPurchaseHistoryStart,
    purchaseInvestmentStart,
} from '@saga-operations/actions/investmentActions';

const useInvestment = () => {
    const dispatch = useAppDispatch();
    const {
        investments,
        totalCount,
        investmentDetails,
        purchaseHistory,
        loading,
        error,
        purchaseSuccess,
        
    } = useAppSelector((state) => state.investment);

    const fetchInvestment = (page: number, limit: number) => {
        console.log(page, limit)
        dispatch(fetchInvestmentStart({ page, limit }));
    };

    const fetchInvestmentDetails = (id: string) => {
        dispatch(fetchInvestmentDetailsStart(id));
    };

    const purchaseInvestment = (id: string) => {
        dispatch(purchaseInvestmentStart(id));
    };

    const fetchPurchaseHistory = () => {
        dispatch(fetchPurchaseHistoryStart());
    };

    return {
        investments,
        totalCount,
        investmentDetails,
        purchaseHistory,
        loading,
        error,
        purchaseSuccess, 
        fetchInvestment,
        fetchInvestmentDetails,
        purchaseInvestment,
        fetchPurchaseHistory,
    };
};

export default useInvestment;
