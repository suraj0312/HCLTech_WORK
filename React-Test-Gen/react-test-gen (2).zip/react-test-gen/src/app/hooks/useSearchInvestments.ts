import {useCallback, useEffect} from 'react';
import {useDispatch} from 'react-redux';
import {searchInvestmentsStart, searchInvestmentsSuccess} from '@saga-operations/actions/searchActions';
import { useAppSelector } from './useAppSelector';

const useSearchInvestments = () => {
    const dispatch = useDispatch();
    const {results, loading, error} = useAppSelector((state) => state.search);

    const handleSearch = useCallback((query: string) => {
        dispatch(searchInvestmentsStart({query}));

    }, [dispatch]);
    useEffect(() => {
        dispatch(searchInvestmentsSuccess([]));
    }, [dispatch]);


    return {results, loading, error, handleSearch};
};

export default useSearchInvestments;