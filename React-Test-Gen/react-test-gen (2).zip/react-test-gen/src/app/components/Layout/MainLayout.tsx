'use client';
import React, { ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import Footer from '@components/Common/Footer';
import styles from '@styles/MainLayout.module.css';
import Loading from '@components/Common/Loading';
import Navbar from '@components/Common/Navbar';
interface MainLayoutProps {
    children: ReactNode;
    isLoggedIn: boolean | null;
    loading: boolean | null;
}

const MainLayout: React.FC<MainLayoutProps> = React.memo(({ children, isLoggedIn, loading }) => {
 

    console.log('mainlayout rendered')

    return <><div key="main-layout" className={styles.container}> 
    <Navbar /> 
      <main className={styles.main}>{children}</main>
      <Footer />
  </div></>;

 });

export default MainLayout;
