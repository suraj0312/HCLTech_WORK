import React, { ReactNode, Suspense, useEffect, useRef, useState } from 'react';
// import Navbar from '@components/Common/Navbar';
import Footer from '@components/Common/Footer';
import styles from '@styles/AuthLayout.module.css';
import dynamic from 'next/dynamic';

const Navbar = dynamic(() => import('@components/Common/Navbar'), { ssr: false });

interface AuthLayoutProps {
    children: ReactNode;
    isLoggedIn: boolean | null;
    loading: boolean | null;
}

const AuthLayout: React.FC<AuthLayoutProps> = React.memo(({ children, isLoggedIn, loading }) => {


    
    console.log('AuthLayout', loading, isLoggedIn);

    return (
        <>
        {<div key="auth-layout" className={styles.container}>
        <Suspense fallback={<div>Loading Navbar...</div>}>
                        <Navbar />
                    </Suspense>
            <main className={styles.main}>{children}</main>
            <Footer />
        </div>}
        </>
    );
});

export default AuthLayout;
