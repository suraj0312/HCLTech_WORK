'use client';

import React from 'react';
import {useRouter} from 'next/navigation';
import AddBalance from '@components/Wallet/AddBalance';
import WithdrawBalance from '@components/Wallet/WithdrawBalance';
import Button from "@_components/Button";

interface WalletDetailsProps {
    balance: number;
}

const WalletDetails: React.FC<WalletDetailsProps> = ({balance}) => {
    const router = useRouter();

    return (
        <>
            <p>Remaining Balance: ₹{balance}</p>
            <AddBalance/>
            <WithdrawBalance/>
            <Button onClick={() => router.push('/wallet')}>Go to Wallet</Button>
        </>
    );
};

export default WalletDetails;
