'use client';

import React, { useCallback } from 'react';
import {useRouter} from 'next/navigation';
import Pagination from '@components/Common/Pagination';
import Button from '@_components/Button';
import AddToWishlistButton from '@components/Wishlist/AddToWishlistButton';
import { Investment } from '@_types/Investment';

interface InvestmentTableProps {
    data: Investment[];
    totalCount: number;
    currentPage: number;
    wishListcurrentPage:number;
    setPage: (page: number) => void;
    itemsPerPage: number;
    currency:string;

}

const InvestmentTable: React.FC<InvestmentTableProps> = ({
                                                             data = [],
                                                             totalCount,
                                                             currentPage,
                                                             setPage,
                                                             itemsPerPage,
                                                             currency,
                                                             wishListcurrentPage
                                                         }) => {
    const router = useRouter();
    const handleViewClick = useCallback((id: string) => {
        router.push(`/investments/${id}`);
      }, [router]);
    return (
        <>
            <table>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Amount</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                {data?.map((investment) => (
                    <tr key={investment.id}>
                        <td>{investment.name}</td>
                        <td>{currency}{investment.amount ?? 0}</td>
                        <td>
                        <Button onClick={() => handleViewClick(investment.id)}>View</Button>
                        <AddToWishlistButton
                                id={investment.id}
                                name={investment.name}
                                // current_value={investment.current_value ?? 0}
                                // amount={investment.amount ?? 0}
                                isInWishlist={investment.isInWishlist}
                                limit={itemsPerPage}
                                pageNumber={currentPage}
                                wishListpageNumber={wishListcurrentPage}
                                showRemove={false}
                            />
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            { totalCount > itemsPerPage && <Pagination
                    currentPage={currentPage}
                    totalCount={totalCount}
                    itemsPerPage={itemsPerPage}
                    onPageChange={setPage}
                />
            }
        </>
    );
};

export default InvestmentTable;