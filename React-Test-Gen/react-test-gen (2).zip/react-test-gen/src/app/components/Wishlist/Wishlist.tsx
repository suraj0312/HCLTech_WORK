'use client';

import React, {useCallback, useEffect} from 'react';
import useWishlist from '@hooks/useWishlist';
import Loading from '@components/Common/Loading';
import Error from '@components/Common/Error';
import Button from '@_components/Button';
import config from '@config/config';
import Pagination from '@components/Common/Pagination';
import { useRouter } from 'next/navigation';
const perPage = config.wishlist.itemPerPage;
const Wishlist: React.FC = () => {
    const { fetchWishlist, wishlist, loading, error, removeFromWishlist, totalCount, page, setPage, pageLoadingMessage } = useWishlist();
    const router = useRouter();

    useEffect(() => {
        fetchWishlist(page, perPage);
    }, []);
    const handleRemoveFromWishlist = (id: string) => {
        removeFromWishlist(id, perPage, page); 
    };

    const handlePageChange = useCallback((newPage: number) => {
        fetchWishlist(newPage, perPage);
        setPage(newPage)
    },[page]);

    if (loading) return <Loading message={pageLoadingMessage ??'Wishlist is loading'}/>;
    if (error) return <Error message={error || "Error loading wishlist. Please try again later."}/>;

    return (
        <div>
            <main>
                <h1>Wishlist</h1>
                <table>
                    <thead>
                    <tr>
                        <th>Name</th>
                        {/* <th>Current Value</th> */}
                        <th>Amount</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    {wishlist.map((item) => (
                        <tr key={item.id}>
                            <td>{item.name}</td>
                            {/* <td>{item.current_value !== null ? `₹${item.current_value}` : 'N/A'}</td> */}
                            <td>{item.amount !== null ? `₹${item.amount}` : 'N/A'}</td>
                            <td>
                            <Button onClick={() => router.push(`/investments/${item.investment_id}`)}>View</Button>
                                <Button onClick={() => handleRemoveFromWishlist(item.id)}>Remove</Button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
               { totalCount > perPage && <Pagination
                    currentPage={page}
                    totalCount={totalCount}
                    itemsPerPage={perPage}
                    onPageChange={handlePageChange}
                />}
            </main>
        </div>
    );
};

export default Wishlist;
