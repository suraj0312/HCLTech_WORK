'use client';
import React, { startTransition, useOptimistic } from 'react';
import {useAppDispatch} from '@hooks/useAppSelector';
import {addToWishlistStart, removeFromWishlistStart} from '@saga-operations/actions/wishlistActions';
import Button from "@_components/Button";

interface AddToWishlistButtonProps {
    id: string;
    name: string;
    current_value?: number;
    amount?: number;
    isInWishlist:boolean;
    limit: number;
    pageNumber: number;
    wishListpageNumber?: number ;
    showRemove: boolean;
}

const AddToWishlistButton: React.FC<AddToWishlistButtonProps> = ({ id, isInWishlist, limit, pageNumber,wishListpageNumber, showRemove }) => {
    const dispatch = useAppDispatch();
    const [optimisticIsInWishlist, setOptimisticIsInWishlist] = useOptimistic(isInWishlist);

    const handleWishlistToggle = () => {
        startTransition(() => {

        setOptimisticIsInWishlist(!optimisticIsInWishlist);
        if (optimisticIsInWishlist) {
          dispatch(removeFromWishlistStart({ id, limit, pageNumber, wishListpageNumber: wishListpageNumber ?? pageNumber }));
        } else {
          dispatch(addToWishlistStart({ id }));
        }
    });
    };
     return (
        <>
       { <Button onClick={handleWishlistToggle}>
            {optimisticIsInWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
        </Button>}
        </>
    );
};

export default AddToWishlistButton;
