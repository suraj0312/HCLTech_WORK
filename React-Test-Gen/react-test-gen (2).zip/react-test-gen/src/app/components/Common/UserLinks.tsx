'use client';

import React, { useRef } from 'react';
import Button from '@_components/Button';
import styles from '@styles/NavigationLinks.module.css';
import Logout from '@components/Auth/Logout';

const UserLinks: React.FC = React.memo(() => {
    // console.log('Rendering UserLinks');
 
    const hasRendered = useRef(false);

    if (hasRendered.current) {
        // console.log('UserLinks component already rendered');
    } else {
        hasRendered.current = true;
        // console.log('Rendering UserLinks');
    }

    return (
        <>
         <li key="dashboard">
        <Button href="/dashboard" prefetch={true} className={styles.button}>
          Dashboard
        </Button>
      </li>
      <li key="wallet">
        <Button href="/wallet" prefetch={true} className={styles.button}>
          Wallet
        </Button>
      </li>
      <li key="history">
        <Button href="/history" prefetch={true} className={styles.button}>
          History
        </Button>
      </li>
      <li key="wishlist">
        <Button href="/wishlist" prefetch={true} className={styles.button}>
          Wishlist
        </Button>
      </li>
      <li key="logout">
        <Logout className={styles.button} />
      </li>

        </>
    );
});

export default UserLinks;