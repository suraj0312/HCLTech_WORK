'use client';
import React from 'react';
import Button from "@_components/Button";

interface PaginationProps {
    currentPage: number;
    totalCount: number;
    itemsPerPage: number;
    onPageChange: (page: number) => void;
}

const Pagination: React.FC<PaginationProps> = ({currentPage, totalCount, itemsPerPage, onPageChange}) => {
    const totalPages = Math.ceil(totalCount / itemsPerPage);
    const pages = [...Array(totalPages).keys()].map(num => num + 1);

    return (
        <div className="pagination">
            {pages.map(page => (
                <Button key={page} onClick={() => onPageChange(page)} disabled={page === currentPage}>
                    {page}
                </Button>
            ))}
        </div>
    );
};

export default Pagination;
