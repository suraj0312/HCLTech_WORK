'use client';

import React, { useState } from 'react';
import AuthForm from '@components/Auth/AuthForm';
import Error from '@components/Common/Error';
import useAuth from '@hooks/useAuth';


const Login: React.FC = () => {
    const {loginUser, loading, error} = useAuth();
    const [formError, setFormError] = useState<string | null>(null);

    const handleSubmit = (values: { username: string; password: string }) => {
        if (!values.username || !values.password) {
          setFormError('Please fill out this field');
          return;
        }
        setFormError(null);
        loginUser(values);
      };
    
    return (
        <div key={'login-div'}>
            <h1>Login</h1>
            {error && <Error message={error}/>}
            {formError && <Error message={formError} />}
            <AuthForm key={'auth-login'} type="login" onSubmit={loading ? null : handleSubmit}/>
        </div>
    );
};

export default Login;