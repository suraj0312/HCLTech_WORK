'use client';

import React, { useEffect } from 'react';
import Loading from '@components/Common/Loading';
import Error from '@components/Common/Error';
import TransactionTable from "@components/History/TransactionTable";
import usePurchaseHistory from './action/usePurchaseHistory';
 
const HistoryPage: React.FC = () => {
    const { totalCount, purchaseHistory, loading, error } = usePurchaseHistory();

useEffect(()=>{
    console.log(loading, error)

})
    if (loading) return <Loading/>;
    if (error) return <Error message={error || "Failed to load investment history. Please try again later."}/>;

    return (
        <div key='transaction'>
            <main>
                <h1>Investment History</h1>
                <TransactionTable data={purchaseHistory}/>
            </main>
        </div>
    );
};

export default HistoryPage;