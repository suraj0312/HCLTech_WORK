'use client';

import React from 'react';
import config, { DateFormat } from '@config/config';
interface Transaction {
    data: {
        id: string;
        type: string;
        amount: number;
        date: string;
        current_value:number;
    }[];
}
const formatDate = (dateString: string, format: DateFormat) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');  
    const year = date.getFullYear();

    if (format === 'MM/DD/YYYY') {
        return `${month}/${day}/${year}`;
    } else {
        return `${day}/${month}/${year}`;
    }
};
const TransactionTable: React.FC<Transaction> = ({data = []}) => {
    return (
        <table>
            <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Type</th>
                <th>Current Amount</th>
                <th>Amount</th>
                <th>Date</th>
            </tr>
            </thead>
            <tbody>
            {data.map((transaction) => (
                <tr key={transaction.id}>
                    <td>{transaction.id}</td>
                    <td>{transaction.type}</td>
                    <td>{transaction.current_value ?`${config.currency} ${transaction.current_value}`:'NA'}</td>
                    <td>{config.currency}{transaction.amount}</td>
                    <td>{formatDate(transaction.date, config.dateFormat)}</td>
                </tr>
            ))}
            </tbody>
        </table>
    );
};

export default TransactionTable;