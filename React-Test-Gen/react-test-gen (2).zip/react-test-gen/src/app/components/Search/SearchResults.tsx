'use client';
import React from 'react';
import styles from '@styles/SearchResults.module.css';
import {useRouter} from 'next/navigation';

interface SearchResult {
    id: string;
    name: string;
}

interface SearchResultsProps {
    results: SearchResult[];
    // onResultClick: (id: string) => void;
}

const SearchResults: React.FC<SearchResultsProps> = ({results}) => {
    const router = useRouter();

    return (
        <div className={styles.results}>
            {results.map((result) => (
                <div key={result.id} className={styles.result} onClick={() => router.push(`/investments/${result.id}`)}>
                    {result.name}
                </div>
            ))}
        </div>
    );
};

export default SearchResults;
