'use client';

import React, {useEffect} from 'react';
import useWallet from '@hooks/useWallet';
import AddBalance from '@components/Wallet/AddBalance';
import WithdrawBalance from '@components/Wallet/WithdrawBalance';
import Loading from '@components/Common/Loading';
import Error from '@components/Common/Error';
import withAuth from "@context/withAuth";

const WalletPage: React.FC = () => {
    const {fetchWalletBalance, walletBalance, loading, error} = useWallet();

    useEffect(() => {
        fetchWalletBalance();
    }, []);

    if (loading) return <Loading/>;
    // if (error) return <Error message="Error loading wallet. Please try again later."/>;

    return (
        <div>
            <main>
                {error && <Error message={error ?? "Error loading wallet. Please try again later."}/>}
                <h1>Wallet</h1>
                <p>Balance: ₹{walletBalance}</p>
                <AddBalance/>
                <WithdrawBalance/>
            </main>
        </div>
    );
};

export default withAuth(WalletPage);
