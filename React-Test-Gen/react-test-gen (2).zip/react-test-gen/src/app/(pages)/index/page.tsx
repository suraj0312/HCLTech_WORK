'use client';
import Index from './index';

const HomePage = () => {
    console.log('Index component mounted')
    return (
        <Index key='default-login-index'/>
    );
};

export default HomePage;
