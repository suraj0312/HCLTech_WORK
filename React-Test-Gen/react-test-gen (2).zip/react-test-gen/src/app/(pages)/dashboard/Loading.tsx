'use client';
import React from 'react';

const DashboardLoading: React.FC = () => {
    return <div>Loading dashboard...</div>;
};

export default DashboardLoading;