'use client';
import React from 'react';

const HistoryLoading: React.FC = () => {
    return <div>Loading history...</div>;
};

export default HistoryLoading;