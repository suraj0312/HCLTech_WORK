'use client';
import React from 'react';
import useSearchInvestments from '@hooks/useSearchInvestments';
import SearchBox from '@components/Search/SearchBox';
import SearchResults from '@components/Search/SearchResults';
import styles from '@styles/HomePage.module.css';
import { useFormStatus } from 'react-dom';

const HomePage: React.FC = () => {
    const {results, loading, error, handleSearch} = useSearchInvestments();
    const { pending } = useFormStatus();

    return (
        <div className={styles.container}>
            <h1 className={styles.title}>Home Page</h1>
            <SearchBox onSearch={handleSearch}/>
            {(loading || pending) && <p>Loading...</p>}
            {error && <p>Error: {error}</p>}
            <SearchResults results={results}/>
        </div>
    );
};

export default HomePage;