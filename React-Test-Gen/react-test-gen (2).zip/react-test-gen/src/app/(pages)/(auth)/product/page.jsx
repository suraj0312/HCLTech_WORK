  'use client';
  // import React, { useEffect, useState } from 'react';
  // import './App.css'; 

  // const items = [
  //   {
  //     id: 1,
  //     name: "Teddy Bear",
  //     description: "A soft and cuddly teddy bear",
  //     price: 15.99,
  //     discount: 0.2,
  //     category: "toys",
  //     tags: ["plush", "soft"]
  //   },
  //   {
  //     id: 2,
  //     name: "Lego Fire Truck",
  //     description: "A buildable fire truck with moving parts",
  //     price: 24.99,
  //     category: "toys",
  //     tags: ["building", "vehicle"]
  //   },
  //   {
  //     id: 3,
  //     name: "Crayons",
  //     description: "A pack of 24 vibrant crayons",
  //     price: 4.99,
  //     discount: 0.1,
  //     category: "art supplies",
  //     tags: ["art", "drawing"]
  //   },
  //   {
  //     id: 4,
  //     name: "Wooden Blocks",
  //     description: "A set of colorful wooden building blocks",
  //     price: 12.99,
  //     category: "toys",
  //     tags: ["building", "educational"]
  //   },
  //   {
  //     id: 5,
  //     name: "Play-Doh",
  //     description: "A tub of moldable, colorful play dough",
  //     price: 3.99,
  //     discount: 0.15,
  //     category: "art supplies",
  //     tags: ["art", "creative"]
  //   }
  // ];

  // const FilterComponent = () => {
  //   const [filteredItems, setFilteredItems] = useState(items);
  //   const [categories, setCategories] = useState([]);
  //   const [priceRanges, setPriceRanges] = useState([]);
  //   const [discounts, setDiscounts] = useState([]);
  //   const [tags, setTags] = useState([]);
  //   const [search, setSearch] = useState('');
  
  //   useEffect(() => {
  //     applyFilters();
  //   }, [categories, priceRanges, discounts, tags, search]);
  
  //   const applyFilters = () => {
  //     const newItems = items.filter(item => {
  //       const categoryMatch = categories.length === 0 || categories.includes(item.category);
  //       const priceMatch = priceRanges.length === 0 || priceRanges.some(range => {
  //         const [min, max] = range;
  //         return item.price >= min && item.price <= max;
  //       });
  //       const discountMatch = discounts.length === 0 || discounts.some(discount => item.discount && item.discount >= discount);
  //       const tagsMatch = tags.length === 0 || tags.every(tag => item.tags.includes(tag));
  //       const searchMatch = !search || item.name.toLowerCase().includes(search.toLowerCase());
  
  //       return categoryMatch && priceMatch && discountMatch && tagsMatch && searchMatch;
  //     });
  
  //     setFilteredItems(newItems);
  //   };
  
  //   const handleCheckboxChange = (filterType, value) => {
  //     const updateFilter = (filter, setFilter) => {
  //       setFilter(prevFilter => {
  //         return prevFilter.includes(value)
  //           ? prevFilter.filter(v => v !== value)
  //           : [...prevFilter, value];
  //       });
  //     };
  
  //     switch (filterType) {
  //       case 'categories':
  //         updateFilter(categories, setCategories);
  //         break;
  //       case 'priceRanges':
  //         updateFilter(priceRanges, setPriceRanges);
  //         break;
  //       case 'discounts':
  //         updateFilter(discounts, setDiscounts);
  //         break;
  //       case 'tags':
  //         updateFilter(tags, setTags);
  //         break;
  //       default:
  //         break;
  //     }
  //   };
  
  //   const handlePriceRangeChange = (range) => {
  //     setPriceRanges(prevRanges => {
  //       return prevRanges.some(r => r[0] === range[0] && r[1] === range[1])
  //         ? prevRanges.filter(r => r[0] !== range[0] || r[1] !== range[1])
  //         : [...prevRanges, range];
  //     });
  //   };
  
  //   const handleSearchChange = (e) => {
  //     setSearch(e.target.value);
  //   };
  
  //   const resetFilters = () => {
  //     setCategories([]);
  //     setPriceRanges([]);
  //     setDiscounts([]);
  //     setTags([]);
  //     setSearch('');
  //   };
  
  //   const uniqueCategories = [...new Set(items.map(item => item.category))];
  //   const uniqueTags = [...new Set(items.flatMap(item => item.tags))];
  
  //   return (
  //     <div>
  //       <h1>Filter Items</h1>
  //       <input
  //         type="text"
  //         placeholder="Search..."
  //         value={search}
  //         onChange={handleSearchChange}
  //       />
  //       <div>
  //         <h3>Categories</h3>
  //         {uniqueCategories.map(category => (
  //           <label key={category}>
  //             <input
  //               type="checkbox"
  //               checked={categories.includes(category)}
  //               onChange={() => handleCheckboxChange('categories', category)}
  //             />
  //             {category.charAt(0).toUpperCase() + category.slice(1)}
  //           </label>
  //         ))}
  //       </div>
  //       <div>
  //         <h3>Price Range</h3>
  //         <label>
  //           <input
  //             type="checkbox"
  //             checked={priceRanges.some(range => range[0] === 0 && range[1] === 5)}
  //             onChange={() => handlePriceRangeChange([0, 5])}
  //           />
  //           Under ₹5
  //         </label>
  //         <label>
  //           <input
  //             type="checkbox"
  //             checked={priceRanges.some(range => range[0] === 5 && range[1] === 10)}
  //             onChange={() => handlePriceRangeChange([5, 10])}
  //           />
  //           ₹5 - ₹10
  //         </label>
  //         <label>
  //           <input
  //             type="checkbox"
  //             checked={priceRanges.some(range => range[0] === 10 && range[1] === 20)}
  //             onChange={() => handlePriceRangeChange([10, 20])}
  //           />
  //           ₹10 - ₹20
  //         </label>
  //         <label>
  //           <input
  //             type="checkbox"
  //             checked={priceRanges.some(range => range[0] === 20 && range[1] === Number.POSITIVE_INFINITY)}
  //             onChange={() => handlePriceRangeChange([20, Number.POSITIVE_INFINITY])}
  //           />
  //           Above ₹20
  //         </label>
  //       </div>
  //       <div>
  //         <h3>Discount</h3>
  //         <label>
  //           <input
  //             type="checkbox"
  //             checked={discounts.includes(0.1)}
  //             onChange={() => handleCheckboxChange('discounts', 0.1)}
  //           />
  //           Discount 10%+
  //         </label>
  //         <label>
  //           <input
  //             type="checkbox"
  //             checked={discounts.includes(0.2)}
  //             onChange={() => handleCheckboxChange('discounts', 0.2)}
  //           />
  //           Discount 20%+
  //         </label>
  //       </div>
  //       <div>
  //         <h3>Tags</h3>
  //         {uniqueTags.map(tag => (
  //           <label key={tag}>
  //             <input
  //               type="checkbox"
  //               checked={tags.includes(tag)}
  //               onChange={() => handleCheckboxChange('tags', tag)}
  //             />
  //             {tag.charAt(0).toUpperCase() + tag.slice(1)}
  //           </label>
  //         ))}
  //       </div>
  //       <button onClick={resetFilters}>Reset Filters</button>
  //       <div className="grid-container">
  //         {filteredItems.map(item => (
  //           <div key={item.id} className="grid-item">
  //             <h2>{item.name}</h2>
  //             <p>{item.description}</p>
  //             <p>Price: ₹{item.price}</p>
  //             {item.discount && <p>Discount: {item.discount * 100}%</p>}
  //             <p>Category: {item.category}</p>
  //           </div>
  //         ))}
  //       </div>
  //     </div>
  //   );
  // };
  
  // export default FilterComponent;
  

  import React, { useState } from 'react';
 
  const initialProducts = [
    {
      id: 1,
      name: "Teddy Bear",
      description: "A soft and cuddly teddy bear",
      price: 15.99,
      discount: 0.2,
      category: "toys",
      tags: ["plush", "soft"]
    },
    {
      id: 2,
      name: "Lego Fire Truck",
      description: "A buildable fire truck with moving parts",
      price: 24.99,
      category: "toys",
      tags: ["building", "vehicle"]
    },
    {
      id: 3,
      name: "Crayons",
      description: "A pack of 24 vibrant crayons",
      price: 4.99,
      discount: 0.1,
      category: "art supplies",
      tags: ["art", "drawing"]
    },
    {
      id: 4,
      name: "Wooden Blocks",
      description: "A set of colorful wooden building blocks",
      price: 12.99,
      category: "toys",
      tags: ["building", "educational"]
    },
    {
      id: 5,
      name: "Play-Doh",
      description: "A tub of moldable, colorful play dough",
      price: 3.99,
      discount: 0.15,
      category: "art supplies",
      tags: ["art", "creative"]
    }
  ];
 
  const ProductList = () => {
    const [products, setProducts] = useState(initialProducts);
    return (
      <div>
        <input
          type="text"
          placeholder="Search products..."
        />
      <div>
        <h3>Price Range</h3>
        <label>
          <input
            type="checkbox"
          />
          $0 - $10
        </label>
        <label>
          <input
            type="checkbox"
          />
          $10 - $20
        </label>
        <label>
          <input
            type="checkbox"
          />
          $20 - $30
        </label>
      </div>
        <label>
          <input
            type="checkbox"
          />
          Show Discounted Only
        </label>
        <div>
          <h3>Categories</h3>
         
            <label>
              <input
                type="checkbox"
              />
              Unique category will be visible here
            </label>
         
        </div>
        {products.map(product => (
          <div key={product.id}>
            <h2>{product.name}</h2>
            <p>{product.description}</p>
            <p>Price: ${product.price}</p>
            {product.discount && <p>Discount: {product.discount}%</p>}
            <p>Category: {product.category}</p>
            <p>Tags: {product.tags}</p>
          </div>
        ))}
      </div>
    );
  };
 
  export default ProductList;