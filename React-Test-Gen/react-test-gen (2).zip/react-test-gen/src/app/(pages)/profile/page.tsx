'use client';

import React from 'react';
import useAuth from '@hooks/useAuth';
import Loading from '@components/Common/Loading';
import Error from '@components/Common/Error';
import withAuth from '@context/withAuth';

const ProfilePage: React.FC = () => {
    const {isLoggedIn, loading, error} = useAuth();

    if (loading) return <Loading/>;
    if (error) return <Error message="Error loading profile. Please try again later."/>;

    return (
        <div>
            <h1>Profile</h1>
            {isLoggedIn ? <p>Profile details go here.</p> : <p>Please log in to view your profile.</p>}
        </div>
    );
};

export default withAuth(ProfilePage);