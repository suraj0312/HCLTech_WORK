'use client';
import React from 'react';

const ProfileError: React.FC = () => {
    return <div>Error loading profile. Please try again later.</div>;
};

export default ProfileError;