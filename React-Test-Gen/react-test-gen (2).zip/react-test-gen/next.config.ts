import type { NextConfig } from 'next';
import path from 'path';
const withBundleAnalyzer = require('@next/bundle-analyzer')({
    enabled: process.env.ANALYZE === 'true',
  });
  
const nextConfig: NextConfig = withBundleAnalyzer({
    reactStrictMode: false,
    // experimental: {
    //     turbo: {
    //   // A list of webpack loaders to apply when running with Turbopack
      
      
    //   // Use swc_css instead of lightningcss for Turbopack
    // //   useSwcCss: true,
      
    //   // A target memory limit for turbo, in bytes
    // //   memoryLimit: 4096 * 1024 * 1024,// 512 MB
            
    //   // Enable tree shaking for the turbopack dev server and build
    // //   treeShaking: true,
      
    //   // The module ID strategy to use for Turbopack
    //   moduleIdStrategy: 'deterministic',
      
    //   // This is the repo root usually and only files above this directory can be resolved by turbopack
    //   root: __dirname,
      
    //   // Enable minification. Defaults to true in build mode and false in dev mode
    // //   minify: true,

    //     }, 
    // },
    webpack: (config) => {
        config.resolve.alias['@components'] = path.join(__dirname, 'src/app/components');
        config.resolve.alias['@_components'] = path.join(__dirname, 'src/_components');
        config.resolve.alias['@hooks'] = path.join(__dirname, 'src/app/hooks');
        config.resolve.alias['@context'] = path.join(__dirname, 'src/app/context');
        config.resolve.alias['@utils'] = path.join(__dirname, 'src/app/utils');
        config.resolve.alias['@pages'] = path.join(__dirname, 'src/app/(pages)');
        config.resolve.alias['@backend'] = path.join(__dirname, 'src/backend');
        config.resolve.alias['@styles'] = path.join(__dirname, 'src/styles');
        config.resolve.alias['@_types'] = path.join(__dirname, 'src/_types');
        config.resolve.alias['@saga-operations'] = path.join(__dirname, 'src/saga-operations');
        config.resolve.alias['@services'] = path.join(__dirname, 'src/services');
        config.resolve.alias['@config'] = path.join(__dirname, 'src/config');

        return config;
    },
    async headers() {
        return [
            {
                source: '/_next/static/(.*)',
                headers: [
                    {
                        key: 'Cache-Control',
                        value: 'public, max-age=31536000, immutable',
                    },
                ],
            },
            {
                source: '/(.*)',
                headers: [
                    // {
                    //     key: 'Content-Encoding',
                    //     value: 'gzip',
                    //   },
                    {
                        key: 'Cache-Control',
                        value: 'no-store, no-cache, must-revalidate, proxy-revalidate',
                    },
                    {
                        key: 'Pragma',
                        value: 'no-cache',
                    },
                    {
                        key: 'Expires',
                        value: '0',
                    },
                    {
                        key: 'Surrogate-Control',
                        value: 'no-store',
                    },
                ],
            },
        ];
    },
});

export default nextConfig;