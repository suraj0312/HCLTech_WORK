import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { configureStore, EnhancedStore } from '@reduxjs/toolkit';
import rootReducer from '@saga-operations/store/rootReducer';
import Register from '@pages/(auth)/register/page';
import useAuth from '@hooks/useAuth';
import { RootState, AppDispatch } from '@saga-operations/store';
import { useRouter, usePathname } from 'next/navigation';

jest.mock('@hooks/useAuth');

jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
  usePathname: jest.fn(),
}));

const mockUseAuth = useAuth as jest.MockedFunction<typeof useAuth>;
const mockUseRouter = useRouter as jest.MockedFunction<typeof useRouter>;
const mockUsePathname = usePathname as jest.MockedFunction<typeof usePathname>;

const createTestStore = (): EnhancedStore<RootState, any, AppDispatch[]> => {
  return configureStore({
    reducer: rootReducer,
  });
};

describe('Register Component', () => {
  let store: EnhancedStore<RootState, any, AppDispatch[]>;

  beforeEach(() => {
    jest.clearAllMocks();
    store = createTestStore();
    mockUseRouter.mockReturnValue({
      push: jest.fn(),
      query: {},
      asPath: '/',
    } as any); 
    mockUsePathname.mockReturnValue('/');
  });

  it('renders the Register component', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      registerUser: jest.fn(),
      loginUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Register />
      </Provider>
    );

    await waitFor(() => expect(screen.getByRole('heading', { name: /register/i })).toBeInTheDocument());
  });

  it('displays an error message when form is submitted with empty fields', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      registerUser: jest.fn(),
      loginUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Register />
      </Provider>
    );

    await waitFor(() => fireEvent.click(screen.getByRole('button', { name: /register/i })));
    expect(screen.getByRole('alert')).toHaveTextContent('Please fill out this field');
  });

  it('calls registerUser when form is submitted with valid data', async () => {
    const mockRegisterUser = jest.fn();
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      registerUser: mockRegisterUser,
      loginUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Register />
      </Provider>
    );

    await waitFor(() => {
      fireEvent.change(screen.getByLabelText('Username:'), { target: { value: 'testuser' } });
      fireEvent.change(screen.getByLabelText('Password:'), { target: { value: 'password' } });
      fireEvent.click(screen.getByRole('button', { name: /register/i }));
    });

    expect(mockRegisterUser).toHaveBeenCalledWith({ username: 'testuser', password: 'password' });
  });

  it('displays an error message from useAuth', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      registerUser: jest.fn(),
      loginUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: 'Username already taken',
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Register />
      </Provider>
    );

    await waitFor(() => expect(screen.getByRole('alert')).toHaveTextContent('Username already taken'));
  });

  it('disables the register button when loading', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      registerUser: jest.fn(),
      loginUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: true,
      error: null,
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Register />
      </Provider>
    );

    await waitFor(() => expect(screen.getByRole('button', { name: /register/i })).toBeDisabled());
  });
});