import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { configureStore, EnhancedStore } from '@reduxjs/toolkit';
import rootReducer from '@saga-operations/store/rootReducer';
import Login from '@pages/(auth)/login/page';
import useAuth from '@hooks/useAuth';
import { RootState, AppDispatch } from '@saga-operations/store';
import { useRouter, usePathname } from 'next/navigation';

jest.mock('@hooks/useAuth');

jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
  usePathname: jest.fn(),
}));

const mockUseAuth = useAuth as jest.MockedFunction<typeof useAuth>;
const mockUseRouter = useRouter as jest.MockedFunction<typeof useRouter>;
const mockUsePathname = usePathname as jest.MockedFunction<typeof usePathname>;

const createTestStore = (): EnhancedStore<RootState, any, AppDispatch[]> => {
  return configureStore({
    reducer: rootReducer,
  });
};

describe('Login Component', () => {
  let store: EnhancedStore<RootState, any, AppDispatch[]>;

  beforeEach(() => {
    jest.clearAllMocks();
    store = createTestStore();
    mockUseRouter.mockReturnValue({
      push: jest.fn(),
      query: {},
      asPath: '/',
    } as any); 
    mockUsePathname.mockReturnValue('/');
  });

  it('renders the Login component', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      loginUser: jest.fn(),
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Login />
      </Provider>
    );

    await waitFor(() => expect(screen.getByRole('heading', { name: /login/i })).toBeInTheDocument());
  });

  it('displays an error message when form is submitted with empty fields', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      loginUser: jest.fn(),
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Login />
      </Provider>
    );

    await waitFor(() => fireEvent.click(screen.getByRole('button', { name: /login/i })));
    expect(screen.getByRole('alert')).toHaveTextContent('Please fill out this field');
  });

  it('calls loginUser when form is submitted with valid data', async () => {
    const mockLoginUser = jest.fn();
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      loginUser: mockLoginUser,
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Login />
      </Provider>
    );

    await waitFor(() => {
      fireEvent.change(screen.getByLabelText('Username:'), { target: { value: 'test1' } });
      fireEvent.change(screen.getByLabelText('Password:'), { target: { value: 'test' } });
      fireEvent.click(screen.getByRole('button', { name: /login/i }));
    });

    expect(mockLoginUser).toHaveBeenCalledWith({ username: 'test1', password: 'test' });
  });

  it('displays an error message from useAuth', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      loginUser: jest.fn(),
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: 'Invalid credentials',
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Login />
      </Provider>
    );

    await waitFor(() => expect(screen.getByRole('alert')).toHaveTextContent('Invalid credentials'));
  });

  it('disables the login button when loading', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: false,
      loginUser: jest.fn(),
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: true,
      error: null,
      hasNavigated: false,
    });

    render(
      <Provider store={store}>
        <Login />
      </Provider>
    );

    await waitFor(() => expect(screen.getByRole('button', { name: /login/i })).toBeDisabled());
  });
});
