import os
import re
from pathlib import Path
from crewai import Agent, Task, Crew, Process
from crewai_tools import FileWriterTool, FileReadTool
from crewai import LLM
import subprocess
from crewai.tools import BaseTool
from crewai.tools import tool

#llm = LLM(model="ollama/qwen2.5-coder:14b", base_url="http://localhost:11434", temperature=0.4)
#llm = LLM(model="ollama/qwen3:30b", base_url="http://localhost:11434", temperature=0.4)
#llm = LLM(model="ollama/gemma3:27b-it-qat", base_url="http://localhost:11434", temperature=0.4)

#llm = LLM(model="ollama/llama3.2", base_url="http://localhost:11434")
llm = LLM( model="gemini/gemini-2.0-flash",  api_key="AIzaSyA4kLSO3v0WI1bIsN4L6RItLBL7oTGzFM4", temperature=0.4)

#llm = LLM( model="gemini/gemini-2.0-flash",  api_key="AIzaSyBMXkjbMdebR6sGinuI8ehTWjpytiBNRqM", temperature=0.4)

import re

def extract_all_js_code_blocks(markdown: str, component_name) -> str:
    # Match code blocks with js/jsx/tsx/javascript language specifier
    pattern = r"```(?:js|jsx|tsx|javascript|typescript)\s+(.*?)```"
    matches = re.findall(pattern, markdown, re.DOTALL)

    if not matches:
        raise ValueError(f"No valid JavaScript code block found for {component_name}")

    # Combine and return all matched blocks
    return "\n\n".join(block.strip() for block in matches)


def all_tests_passed(jest_output: str) -> bool:
    """
    Check if all Jest tests passed based on the output text.

    Args:
        jest_output (str): The output text from Jest.

    Returns:
        bool: True if all tests passed, False otherwise.
    """
    match = re.search(r"Tests:\s+(\d+)\s+passed,\s+(\d+)\s+total", jest_output)
    if match:
        passed, total = map(int, match.groups())
        return passed == total
    else:
        # If "failed" appears anywhere or parsing fails, treat it as failed
        if "failed" in jest_output.lower():
            return False
        return False

@tool("jest_runner")
def jest_runner(file_path: str) -> str:
    "Runs a specified Jest test file and returns the output"
    try:
        output = subprocess.getoutput(f"npm test -- --watchAll=false {file_path}")
        return output
    except Exception as e:
        return f"Error running Jest test: {str(e)}"

class RjsUnitTest:
    def test_writer(self) -> Agent:
        return Agent(
            role="React Frontend Developer with unit test writing experience using Jest and React Testing Library.",
            goal="Write React component unit test cases using Jest and React Testing Library",
            backstory="You are an expert React developer and testing specialist. You are proficient in writing unit tests. You always ensure code correctness, coverage.",
            verbose=True,
            llm=llm
        )

    def test_runner_agent(self):
            return Agent(
                role="React Frontend Developer with unit test writing and debugging expertise.",
                goal="Run and analyze React unit tests to report precise diagnostics",
                backstory="You are an expert React developer and testing specialist with deep expertise in diagnosing unit test failures. You clearly explain the cause of each failure and recommend how to fix the related test.",
                verbose=True,
                llm=llm
            )
    
    def test_fixer_agent(self):
        return Agent(
            role="React Frontend Developer with unit test writing and debugging and fixing expert.",
            goal="Fix failing unit test without altering passing tests.",
            backstory=(
                "You are a senior React developer, expert in Jest and React Testing Library."
            ),
            verbose=True,
            llm=llm
        )

    def test_case_reviewer(self) -> Agent:
        return Agent(
            role="Senior React Frontend Developer with unit test writing experience using Jest and React Testing Library.",
            goal="Review React component unit test cases for correctness and coverage written by developer.",
            backstory="You are a senior React developer expert in Jest and React Testing Library.",
            verbose=True,
            llm=llm
        )

    def write_test_cases_task(self, component_code: str) -> Task:
        return Task(
            description=f"""
            Write React component unit tests using Jest and React Testing Library.

            --- Component Code Start ---
            {component_code}
            --- Component Code End ---

            Requirements:
            - Cover all props, conditionals, branches, and events
            - Cover key functionality to test (e.g. rendering, event handling)
            - Handle edge cases such as empty or missing props
            

            Note:
            - Only import '@testing-library/jest-dom'. Do not '@testing-library/jest-dom/extend-expect' library in the test file.
            - Always import all required React hooks properly.
            - The code must be enclosed in a single markdown code block (```javascript```).

            Your output must be complete unit test code only.
            """,
            expected_output="Your answer must be complete and correct unit test cases code, only code nothing else.",
            agent=self.test_writer(),
        )

    def review_test_cases_task(self, component_code: str, write_test_task: Task) -> Task:
        return Task(
            description=f"""
            Review and fix the issues in the unit test file for the given React component.
            
            --- Component Code Start ---
            {component_code}
            --- Component Code End ---

            Output requirements:
            - Fix issues and return the **final updated test code only**, as a complete test file.
            - The code must be enclosed in a single markdown code block (```javascript```).
            """,
            expected_output="Your answer must be final updated unit test code only, nothing else.",
            agent=self.test_case_reviewer(),
            context=[write_test_task]
        )
    
    def run_unit_tests_task(self, test_file_path: str, component_code: str) -> Task:
        return Task(
            description=f"""
    Your task is to run the Jest test file located at: `{test_file_path}`
    Also provided is the React component source code being tested.

    --- Component Code Start ---
    {component_code}
    --- Component Code End ---

    Instructions:
    - Project is setup and all required libraries are installed e.g. Jest and React Testing Library.
    - Run the test file and collect the results.
    - If all tests pass, respond with: **"All tests passed."**
    - If any tests fail:
        - Clearly identify which test cases failed.
        - Use the component code to help identify likely root causes.
        - Suggest precise changes to fix the failing test cases.

    Your output will be passed to a test-fixing agent. Make sure your guidance is concise, accurate, and clearly actionable.
            """,
            expected_output=(
                "If tests passed: 'All tests passed.'\n"
                "If tests failed: List of failed tests, error messages, and clear, actionable suggestions for fixes."
            ),
            agent=self.test_runner_agent(),
            tools=[jest_runner],
            inputs={"file_path": test_file_path}
        )


    def fix_failing_tests_task(self, test_code: str, run_unit_tests_task: Task) -> Task:
        return Task(
            description=f"""
    The following Jest test file contains one or more failing tests.

    --- Test Code Start ---
    {test_code}
    --- Test Code End ---

    Use the diagnostic insights provided by the previous task to identify which test cases are failing and why.

    Your responsibilities:
    - Fix **only** the failing test cases.
    - Keep the passing test cases untouched.
    - Preserve the overall structure, formatting, and style of the original file.
    - Ensure the corrected code will execute without errors.
    - Make sure all required imports are present and valid.

    Output requirements:
    - Return the full test code.
    - The code must be enclosed in a single markdown code block (```javascript```).
    - Do not include any explanation or comments outside the code block.
    """,
            expected_output="A single markdown code block containing the corrected Jest test code.",
            agent=self.test_fixer_agent(),
            context=[run_unit_tests_task]
        )



def generate_test(test_dir, component_name, component_code):
        print(f"\n🚀 Running test generation for component: {component_name}")
        runner = RjsUnitTest()

        write_test_task = runner.write_test_cases_task(component_code)
        review_task = runner.review_test_cases_task(component_code, write_test_task)

        crew_gen = Crew(
            agents=[
                runner.test_writer(),
                runner.test_case_reviewer()
            ],
            tasks=[
                write_test_task,
                review_task
            ],
            process=Process.sequential,
            verbose=True
        )

        result = crew_gen.kickoff()

        # Extract JavaScript code block using regex
        try:
            test_code = extract_all_js_code_blocks(result.raw, component_name)
        except ValueError:
            test_code = extract_all_js_code_blocks(write_test_task.output.raw, component_name)

        # Save to test file
        test_path = test_dir / f"{component_name}.test.tsx"
        with open(test_path, "w", encoding="utf-8") as f:
            f.write(test_code)

        print(f"✅ Test written to {test_path}")

def fix_code(test_dir, component_name, component_code):
        print(f"\n🚀 Running test execution and fix for component: {component_name}")
        runner = RjsUnitTest()
        test_path = test_dir / f"{component_name}.test.tsx"
        test_code = Path(test_path).read_text(encoding='utf-8')

        max_attempts = 2
        for attempt in range(1, max_attempts + 1):
            run_task = runner.run_unit_tests_task(test_path, component_code)

            crew_test = Crew(
                agents=[runner.test_runner_agent()],
                tasks=[run_task],
                process=Process.sequential,
                verbose=True
            )
            crew_test_result = crew_test.kickoff()

            if "All tests passed." in crew_test_result.raw:
                print("✅ All tests passed.")
                break

            print("❌ Errors found. Attempting to fix...")

            fix_task = runner.fix_failing_tests_task(test_code, run_task)

            crew_test_fix = Crew(
                agents=[runner.test_fixer_agent()],
                tasks=[fix_task],
                process=Process.sequential,
                verbose=True
            )
            crew_test_fix = crew_test_fix.kickoff()

            # Extract JavaScript code block using regex
            fix_code = extract_all_js_code_blocks(crew_test_fix.raw, component_name)
            Path(test_path).write_text(fix_code)

def run_for_all_components():
    src_dir = Path("src/app/components/Auth")
    test_dir = Path("src/app/components/Auth")
    test_dir.mkdir(parents=True, exist_ok=True)

    for file_path in src_dir.glob("Login.tsx"):
        if not file_path.name.endswith(".test.tsx"):
            component_code = file_path.read_text(encoding="utf-8")
            component_name = file_path.stem

            generate_test(test_dir=test_dir, component_name=component_name, component_code=component_code)
            fix_code(test_dir=test_dir, component_name=component_name, component_code=component_code)


        


if __name__ == "__main__":
    run_for_all_components()
