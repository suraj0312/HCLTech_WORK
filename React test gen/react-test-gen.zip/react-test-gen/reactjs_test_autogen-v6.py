import os
import re
import asyncio
import logging
from pathlib import Path
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_agentchat.conditions import MaxMessageTermination, TextMentionTermination
from autogen_ext.models.ollama import OllamaChatCompletionClient
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient, OpenAIChatCompletionClient
from autogen_core.tools import FunctionTool

from dataclasses import dataclass
import json
import re
import uuid
from typing import Dict, List, Union

from autogen_core import MessageContext, RoutedAgent, TopicId, default_subscription, message_handler
from autogen_core.models import (
    AssistantMessage,
    ChatCompletionClient,
    LLMMessage,
    SystemMessage,
    UserMessage,
)

from autogen_core import DefaultTopicId, SingleThreadedAgentRuntime
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient

import subprocess


azure_api_key=os.getenv("AZURE_OPENAI_API_KEY")
gemini_api_key=os.getenv("GEMINI_API_KEY")

logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Initialize OllamaChatCompletionClient for LLM communication
#model_client = OpenAIChatCompletionClient(
#    model="gemini-2.0-flash",
#    api_key=gemini_api_key,
#    temperature=0.4
#)
#model_client = OllamaChatCompletionClient(model="qwen2.5-coder:14b", temprature=0.4)
#model_client_qr = OllamaChatCompletionClient(model="qwen3:30b", model_info={
#        "id": "qwen3:30b",
#        "max_tokens": 8192,
#        "temperature": 0.7,
#    })

#model_client = AzureOpenAIChatCompletionClient(
#    azure_deployment="gpt-4o",
#    model="gpt-4o-mini",
#    api_version="2024-05-01-preview",
#    azure_endpoint="https://x-generative-ai.openai.azure.com/",
#    api_key=azure_api_key, # For key-based authentication.
#)

#model_client_qr = AzureOpenAIChatCompletionClient(
#    azure_deployment="gpt-4o",
#    model="gpt-4o",
#    api_version="2024-05-01-preview",
#    azure_endpoint="https://x-generative-ai.openai.azure.com/",
#    api_key=azure_api_key, # For key-based authentication.
#)

#model_client = AzureOpenAIChatCompletionClient(
#    azure_deployment="gpt-4o",
#    model="gpt-4o-mini",
#    api_version="2024-05-01-preview",
#    azure_endpoint="https://x-generative-ai.openai.azure.com/",
#    api_key=azure_api_key, # For key-based authentication.
#)

#model_client_qr = AzureOpenAIChatCompletionClient(
#    azure_deployment="gpt-4o",
#    model="gpt-4o",
#    api_version="2024-05-01-preview",
#    azure_endpoint="https://x-generative-ai.openai.azure.com/",
#    api_key=azure_api_key, # For key-based authentication.
#)

model_client = AzureOpenAIChatCompletionClient(
    azure_deployment="o3",
    model="o3",
    api_version="2024-12-01-preview",
    azure_endpoint="https://rfx-openai-001.openai.azure.com/",
    api_key="9Rz2osvYy1ztROguXiEut9VMAOmsw3doByzReiewFFi9ss2jRTeGJQQJ99BBACHYHv6XJ3w3AAABACOGITlC", # For key-based authentication.
    model_info={"family": "o3", "vision": False, "function_calling": True, "json_output": True}
)

model_client_qr = AzureOpenAIChatCompletionClient(
    azure_deployment="o3",
    model="o3",
    api_version="2024-12-01-preview",
    azure_endpoint="https://rfx-openai-001.openai.azure.com/",
    api_key="9Rz2osvYy1ztROguXiEut9VMAOmsw3doByzReiewFFi9ss2jRTeGJQQJ99BBACHYHv6XJ3w3AAABACOGITlC", # For key-based authentication.
    model_info={"family": "o3", "vision": False, "function_calling": True, "json_output": True}
)

def get_relative_path(from_path: str, to_path: str) -> str:
    # If from_path is a file, use its directory
    if os.path.isfile(from_path):
        from_path = os.path.dirname(from_path)

    if os.path.isfile(to_path):
        to_path = os.path.dirname(to_path)
    
    # If to_path is a file, use its full path (but allow filename in the relative path)
    return os.path.relpath(os.path.abspath(to_path), os.path.abspath(from_path))

# ToolExecutor to replace subprocess calls
def jest_executer(test_file: str) -> str:
    """Runs a specified test file and returns the output"""
    try:
        output = subprocess.getoutput(f"npm test -- --watchAll=false {test_file}")
        return output
    except Exception as e:
        return f"Error running test file: {str(e)}"

def extract_json(text: str) -> str:
    result = extract_code_block(text)
    return result if result is not None else text

def extract_code_block(markdown_text: str) -> Union[str, None]:
    pattern = r"```(\w+)\n(.*?)\n```"
    # Search for the pattern in the markdown text
    match = re.search(pattern, markdown_text, re.DOTALL)
    # Extract the language and code block if a match is found
    if match:
        return match.group(2)
    return None


@dataclass
class CodeRunnerTask:
    session_id: str
    task: str
    test_path: str
    code: str


@dataclass
class CodeRunnerResult:
    test_path: str
    code: str
    code_fixing_scratchpad: str
    task: str
    review: str
    session_id: str
    approved: bool

@dataclass
class CodeFixingTask:
    session_id: str
    task: str
    test_path: str
    code: str

@dataclass
class CodeFixingResult:
    session_id: str
    task: str
    test_path: str
    code: str
    review: str



@dataclass
class CodeWritingTask:
    task: str
    test_path: str


@dataclass
class CodeWritingResult:
    task: str
    code: str
    review: str


@dataclass
class CodeReviewTask:
    session_id: str
    code_writing_task: str
    code_writing_scratchpad: str
    code: str
    test_path: str


@dataclass
class CodeReviewResult:
    review: str
    session_id: str
    approved: bool
    test_path: str

# Define the agents

@default_subscription
class CoderAgent(RoutedAgent):
    """An agent that performs code writing tasks."""

    def __init__(self, model_client: ChatCompletionClient) -> None:
        super().__init__("A code writing agent.")
        self._system_messages: List[LLMMessage] = [
            SystemMessage(
                content="""
You are a proficient coder. You write unit test case code for Next.js component using Jest framework and React Testing Library.
Work with the reviewer to improve your code.

Note:
- Always import '@testing-library/jest-dom'

Always put all finished code in a single Markdown code block.
For example:
```tsx
import '@testing-library/jest-dom';
import hello from './hello'; 
test('returns "Hello, World!"', () => {
    expect(hello()).toBe('Hello, World!');
});
```

Respond using the following format:

Thoughts: <Your comments>
Code: <Your code>
""",
            )
        ]
        self._model_client = model_client
        self._session_memory: Dict[str, List[CodeWritingTask | CodeReviewTask | CodeReviewResult]] = {}

    @message_handler
    async def handle_code_writing_task(self, message: CodeWritingTask, ctx: MessageContext) -> None:
        # Store the messages in a temporary memory for this request only.
        session_id = str(uuid.uuid4())
        self._session_memory.setdefault(session_id, []).append(message)
        # Generate a response using the chat completion API.
        response = await self._model_client.create(
            self._system_messages + [UserMessage(content=message.task, source=self.metadata["type"])],
            cancellation_token=ctx.cancellation_token,
        )
        assert isinstance(response.content, str)
        # Extract the code block from the response.
        code_block = extract_code_block(response.content)
        if code_block is None:
            raise ValueError("Code block not found.")
        
        Path(message.test_path).write_text(code_block, encoding="utf-8")

        # Create a code review task.
        code_review_task = CodeReviewTask(
            session_id=session_id,
            code_writing_task=message.task,
            code_writing_scratchpad=response.content,
            code=code_block,
            test_path=message.test_path
        )
        # Store the code review task in the session memory.
        self._session_memory[session_id].append(code_review_task)
        # Publish a code review task.
        await self.publish_message(code_review_task, topic_id=TopicId("default", self.id.key))

    @message_handler
    async def handle_code_review_result(self, message: CodeReviewResult, ctx: MessageContext) -> None:
        # Store the review result in the session memory.
        self._session_memory.setdefault(message.session_id, []).append(message)
        # Obtain the request from previous messages.
        review_request = next( m for m in reversed(self._session_memory[message.session_id]) if isinstance(m, CodeReviewTask))
        assert review_request is not None
        code_writing_task = next(m for m in reversed(self._session_memory[message.session_id]) if isinstance(m, CodeWritingTask))
        # Check if the code is approved.
        if message.approved:
            Path(code_writing_task.test_path).write_text(review_request.code, encoding="utf-8")
            logger.info("Code Fixing Result:")
            logger.info("-" * 80)
            logger.info(f"Task:\n{review_request.code_writing_task}")
            logger.info("-" * 80)
            logger.info(f"Code:\n{review_request.code}")
            logger.info("-" * 80)
            logger.info(f"Review:\n{message.review}")
            logger.info("-" * 80)
        else:
            # Create a list of LLM messages to send to the model.
            messages: List[LLMMessage] = [*self._system_messages]
            for m in self._session_memory[message.session_id]:
                if isinstance(m, CodeReviewResult):
                    messages.append(UserMessage(content=m.review, source="Reviewer"))
                elif isinstance(m, CodeReviewTask):
                    messages.append(AssistantMessage(content=m.code_writing_scratchpad, source="Coder"))
                elif isinstance(m, CodeWritingTask):
                    messages.append(UserMessage(content=m.task, source="User"))
                else:
                    raise ValueError(f"Unexpected message type: {m}")
            # Generate a revision using the chat completion API.
            response = await self._model_client.create(messages, cancellation_token=ctx.cancellation_token)
            assert isinstance(response.content, str)

            self.prompt_tokens += response.usage.prompt_tokens
            self.completion_tokens += response.usage.completion_tokens

            # Extract the code block from the response.
            code_block = extract_code_block(response.content)
            
            if code_block is None:
                raise ValueError("Code block not found.")
            
            Path(code_writing_task.test_path).write_text(code_block, encoding="utf-8")

            # Create a new code review task.
            code_review_task = CodeReviewTask(
                session_id=message.session_id,
                code_writing_task=review_request.code_writing_task,
                code_writing_scratchpad=response.content,
                code=code_block,
                test_path=message.test_path
            )
            # Store the code review task in the session memory.
            self._session_memory[message.session_id].append(code_review_task)
            # Publish a new code review task.
            await self.publish_message(code_review_task, topic_id=TopicId("default", self.id.key))

@default_subscription
class ReviewerAgent(RoutedAgent):
    """An agent that performs code review tasks."""

    def __init__(self, model_client: ChatCompletionClient) -> None:
        super().__init__("A code reviewer agent.")
        self._system_messages: List[LLMMessage] = [
            SystemMessage(
                content="""You are a test case reviewer. You focus on code syntax and test case correctness.
Respond using the following JSON format:
{
    "approval": "<APPROVE or REVISE>",
    "suggested_changes": "<Your point wise comments in string format>"
}
""",
            )
        ]
        self._session_memory: Dict[str, List[CodeReviewTask | CodeReviewResult]] = {}
        self._model_client = model_client
        self.completion_tokens = 0
        self.prompt_tokens = 0

    @message_handler
    async def handle_code_review_task(self, message: CodeReviewTask, ctx: MessageContext) -> None:
        # Format the prompt for the code review.
        # Gather the previous feedback if available.
        previous_feedback = ""
        if message.session_id in self._session_memory:
            previous_review = next(
                (m for m in reversed(self._session_memory[message.session_id]) if isinstance(m, CodeReviewResult)),
                None,
            )
            if previous_review is not None:
                previous_feedback = previous_review.review
        # Store the messages in a temporary memory for this request only.
        self._session_memory.setdefault(message.session_id, []).append(message)
        prompt = f"""The problem statement is: {message.code_writing_task}
The code is:
```
{message.code}
```

Previous feedback:
{previous_feedback}

Please review the code. If previous feedback was provided, see if it was addressed.
"""
        # Generate a response using the chat completion API.
        response = await self._model_client.create(
            self._system_messages + [UserMessage(content=prompt, source=self.metadata["type"])],
            cancellation_token=ctx.cancellation_token,
            json_output=True,
        )
        assert isinstance(response.content, str)

        self.prompt_tokens += response.usage.prompt_tokens
        self.completion_tokens += response.usage.completion_tokens

        # Parse the response JSON.
        content = extract_json(response.content)
        review = json.loads(content)
        # Construct the review text.
        review_text = "Code review:\n" + "\n".join([f"{k}: {v}" for k, v in review.items()])
        approved = review["approval"].lower().strip() == "approve"
        result = CodeReviewResult(
            review=review_text,
            session_id=message.session_id,
            approved=approved,
            test_path=message.test_path
        )
        # Store the review result in the session memory.
        self._session_memory[message.session_id].append(result)
        # Publish the review result.
        await self.publish_message(result, topic_id=TopicId("default", self.id.key))


############## Fixer and Runner Agents ###########
@default_subscription
class FixerAgent(RoutedAgent):
    """An agent that performs code fixing tasks."""

    def __init__(self, model_client: ChatCompletionClient) -> None:
        super().__init__("A code fixing agent.")
        self._system_messages: List[LLMMessage] = [
            SystemMessage(
                content="""
You are a proficient coder. Work with the test runner to fix the test code written for Next.js component using Jest framework and React Testing Library.

Always put all finished code in a single Markdown code block. Code must always import '@testing-library/jest-dom' library.
For example:
```tsx
import '@testing-library/jest-dom';
import hello from './hello'; 
test('returns "Hello, World!"', () => {
    expect(hello()).toBe('Hello, World!');
});
```

Respond using the following format:

Thoughts: <Your comments>
Code: <Your code>
""",
            )
        ]
        self._model_client = model_client
        self._session_memory: Dict[str, List[CodeRunnerResult | CodeFixingTask]] = {}
        self.completion_tokens = 0
        self.prompt_tokens = 0

    @message_handler
    async def handle_code_fixing_task(self, message: CodeFixingTask, ctx: MessageContext) -> None:
        self._session_memory.setdefault(message.session_id, []).append(message)
        code_runner_task=CodeRunnerTask(session_id = message.session_id, task=message.task, code=message.code, test_path=message.test_path)
        await self.publish_message(code_runner_task, topic_id=TopicId("default", self.id.key))

    @message_handler
    async def handle_code_runner_result(self, message: CodeRunnerResult, ctx: MessageContext) -> None:
        # Store the review result in the session memory.
        self._session_memory.setdefault(message.session_id, []).append(message)
        # Check if the code is approved.
        if message.approved:
            Path(message.test_path).write_text(message.code, encoding="utf-8")
            logger.info("Code Fixing Result:")
            logger.info("-" * 80)
            logger.info(f"Code:\n{message.code}")
            logger.info("-" * 80)
            logger.info(f"Review:\n{message.review}")
            logger.info("-" * 80)
        else:
            # Create a list of LLM messages to send to the model.
            messages: List[LLMMessage] = [*self._system_messages]
            for m in self._session_memory[message.session_id]:
                if isinstance(m, CodeRunnerResult):
                    #messages.append(AssistantMessage(content=m.code_fixing_scratchpad, source="Fixer"))
                    code = Path(m.test_path).read_text(encoding="utf-8")
                    prompt = f"""
                        Fix the test code as per the review comments.

                        Test Code: ```{code}```

                        Review Comments:
                        {m.review}

                        Always put all finished code in a single Markdown code block.
                    """
                    messages.append(UserMessage(content=prompt, source="Runner"))
                    
                #elif isinstance(m, CodeRunnerTask):
                    #messages.append(AssistantMessage(content=m.code_writing_scratchpad, source="Fixer"))
                #    logger.info()
                elif isinstance(m, CodeFixingTask):
                    messages.append(UserMessage(content=m.task, source="User"))
                    #logger.info()
                else:
                    raise ValueError(f"Unexpected message type: {m}")
            # Generate a revision using the chat completion API.
            response = await self._model_client.create(messages, cancellation_token=ctx.cancellation_token)
            assert isinstance(response.content, str)

            self.prompt_tokens += response.usage.prompt_tokens
            self.completion_tokens += response.usage.completion_tokens

            # Extract the code block from the response.
            code_block = extract_code_block(response.content)
            if code_block is None:
                raise ValueError("Code block not found.")

            Path(message.test_path).write_text(code_block, encoding="utf-8")
            
            # Create a new code review task.
            code_review_task = CodeRunnerTask(
                session_id=message.session_id,
                test_path=message.test_path,
                task=message.task,
                code=code_block,
            )
            # Store the code review task in the session memory.
            # self._session_memory[message.session_id].append(code_review_task)
            # Publish a new code review task.
            await self.publish_message(code_review_task, topic_id=TopicId("default", self.id.key))


    
@default_subscription
class RunnerAgent(RoutedAgent):
    """An agent that runs the test cases."""

    def __init__(self, model_client: ChatCompletionClient) -> None:
        super().__init__("A test runner agent.")
        self._system_messages: List[LLMMessage] = [
            SystemMessage(
                content="""You are a test case runner. You focus on test result success.
Respond using the following JSON format:
{
    "approval": "<APPROVE or REVISE>",
    "suggested_changes": "<Your point wise comments in string format>"
}
""",
            )
        ]
        self._session_memory: Dict[str, List[CodeRunnerTask | CodeRunnerResult]] = {}
        self._model_client = model_client
        self.completion_tokens = 0
        self.prompt_tokens = 0

    @message_handler
    async def handle_code_runner_task(self, message: CodeRunnerTask, ctx: MessageContext) -> None:
        # Store the messages in a temporary memory for this request only.
        self._session_memory.setdefault(message.session_id, []).append(message)

        test_result = jest_executer(message.test_path)
        code = Path(message.test_path).read_text(encoding="utf-8")
        prompt = f"""
Analyse the test result and suggest precise changes to fix the failing test cases.

Test Code: ```{code}```
Test Result:
{test_result}
"""
        # Generate a response using the chat completion API.
        response = await self._model_client.create(
            self._system_messages + [UserMessage(content=prompt, source=self.metadata["type"])],
            cancellation_token=ctx.cancellation_token,
            json_output=True,
        )
        assert isinstance(response.content, str)

        self.prompt_tokens += response.usage.prompt_tokens
        self.completion_tokens += response.usage.completion_tokens
        
        # Parse the response JSON.
        content = extract_json(response.content)
        review = json.loads(content)
        # Construct the review text.
        review_text = "Code review:\n" + "\n".join([f"{k}: {v}" for k, v in review.items()])
        approved = review["approval"].lower().strip() == "approve"
        result = CodeRunnerResult(
            test_path=message.test_path,
            task=message.task,
            code=message.code,
            review=review_text,
            session_id=message.session_id,
            approved=approved,
            code_fixing_scratchpad=response.content
        )
        # Store the review result in the session memory.
        self._session_memory[message.session_id].append(result)
        # Publish the review result.
        await self.publish_message(result, topic_id=TopicId("default", self.id.key))



# Generate tests for a single component
async def generate_test(component_code: str, component_path: str, test_file_path: Path) -> None:
    logger.info(f"Generating tests for {component_path}")
    text_termination = TextMentionTermination("APPROVE")
    max_msg_termination = MaxMessageTermination(max_messages=10)
    combined_termination = max_msg_termination | text_termination

    component_relative_path = get_relative_path(test_file_path, component_path)
    component_name = component_path.stem
    
    task = f"""
Write TypeScript unit test cases using 'Jest' and 'React Testing Library' framework for the following Next.js component.

Component Path: '{component_relative_path}/{component_name}'

Component Code:```{component_code}```

The final output should be inside a ```javascript``` or ```jsx``` code block.
"""
    
    runtime = SingleThreadedAgentRuntime()
    await ReviewerAgent.register(runtime, "ReviewerAgent", lambda: ReviewerAgent(model_client=model_client_qr))
    await CoderAgent.register(runtime, "CoderAgent", lambda: CoderAgent(model_client=model_client))
    runtime.start()

    await runtime.publish_message(
        message=CodeWritingTask(task=task, test_path=str(test_file_path)),
        topic_id=DefaultTopicId(),
    )

    # Keep processing messages until idle.
    await runtime.stop_when_idle()
    # Close the model client.
    await model_client.close()

# fix tests for a single component
async def fix_test(component_code: str, component_path: str, test_file_path: Path) -> None:
    logger.info(f"Fixing tests for {component_path}")
    text_termination = TextMentionTermination("APPROVE")
    max_msg_termination = MaxMessageTermination(max_messages=10)
    combined_termination = max_msg_termination | text_termination

    test_code = test_file_path.read_text(encoding="utf-8")
    component_relative_path = get_relative_path(test_file_path, component_path)
    component_name = component_path.stem

    task = f"""
Run the test examine the output and fix the test code for the following Next.js component. Do not change component code.

Component Path: '{component_relative_path}/{component_name}'

Component Code:```{component_code}```

Test Code: ```{test_code}```
"""
    
    runtime = SingleThreadedAgentRuntime()
    await RunnerAgent.register(runtime, "RunnerAgent", lambda: RunnerAgent(model_client=model_client_qr))
    await FixerAgent.register(runtime, "FixerAgent", lambda: FixerAgent(model_client=model_client))
    runtime.start()
    await runtime.publish_message(
        message=CodeFixingTask(session_id = str(uuid.uuid4()), task=task, code=test_code, test_path=str(test_file_path)), topic_id=DefaultTopicId(),
    )

    # Keep processing messages until idle.
    await runtime.stop_when_idle()

# Process all components in the directory
async def process_all_components(base_dir: str = "src/app", src_dir: str = "components", test_dir: str = "__tests__", pattern: str = "*.tsx") -> None:
    src_path = Path(base_dir + "/" + src_dir)
    test_path = Path(base_dir + "/" + test_dir)

    if not src_path.exists():
        logger.error(f"❌ Source directory {src_path} does not exist.")
        return

    # Create 
    Path(test_path).mkdir(parents=True, exist_ok=True)

    component_files = list(src_path.glob(pattern))
    component_files = [f for f in component_files if not f.name.endswith(".test.tsx")]

    if not component_files:
        logger.info(f"🔍 No files matching pattern '{pattern}' found in {src_path}")
        return

    for file_path in component_files:
        if file_path.is_file():
            try:
                component_code = file_path.read_text(encoding="utf-8")
                component_name = file_path.stem
                component_path = file_path
                test_file_path = test_path / src_dir / f"{component_name}.test.tsx"

                logger.info(f"📦 Processing component: {file_path}")

                #create empty test file
                Path(test_file_path).parent.mkdir(parents=True, exist_ok=True)
                Path(test_file_path).touch()

                await generate_test(component_code, component_path, test_file_path)
                await fix_test(component_code, component_path, test_file_path)

            except Exception as e:
                logger.error(f"🔥 Error processing file {file_path}: {e}")

# Run the async process
asyncio.run(process_all_components(base_dir="src/app", src_dir="components/Auth", test_dir="__test__", pattern="Logout.tsx"))
