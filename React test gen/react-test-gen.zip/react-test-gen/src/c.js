import fs from "fs";

import path from "path";

// Function to read all .js files in a directory recursively, excluding node_modules, .idea, and the current script file
function readJSFiles(dir, baseDir, currentFile, filesObj = {}) {
    const files = fs.readdirSync(dir);

    files.forEach(file => {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);

        if (stat.isDirectory() && file !== 'node_modules' && file !== '.idea') {
            readJSFiles(filePath, baseDir, currentFile, filesObj);
        } else if (['.tsx', '.ts', 'json'].includes(path.extname(file)) && filePath !== currentFile) {
            const relativePath = path.relative(baseDir, filePath);
            filesObj[relativePath] = fs.readFileSync(filePath, 'utf8');
        }
    });

    return filesObj;
}

const directoryPath = path.resolve('.');

const jsFilesContent = readJSFiles(directoryPath, directoryPath, __filename);
const jsonFilePath = path.join(__dirname, 'jsFilesContent.txt');
fs.writeFileSync(jsonFilePath, JSON.stringify(jsFilesContent, null, 2), 'utf8');

console.log(`JS files content saved to ${jsonFilePath}`);