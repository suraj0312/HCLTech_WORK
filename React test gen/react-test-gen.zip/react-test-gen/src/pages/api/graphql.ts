import { ApolloServer } from 'apollo-server-micro';
import { resolvers, typeDefs } from '@backend/schema';
import { NextApiRequest, NextApiResponse } from 'next';
import { json } from 'micro';

const apolloServer = new ApolloServer({
  typeDefs,
  resolvers,
  context: async ({ req }) => {
    const body = await json(req);
    const operationName = body?.operationName?.toLowerCase();
    const unauthenticatedQueries = ['searchinvestments'];

    if (req.url === '/api/graphql' && !unauthenticatedQueries.includes(operationName)) {
      const authHeader = req.headers.authorization || '';
      if (authHeader) {
        try {
          const { verifyToken } = await import('@backend/middleware/verifyToken');
          const { userId, token } = await verifyToken(req);
          return { userId, token };
        } catch (error) {
          console.error('Token verification failed:', error);
        }
      }
    }
    return {};
  },
});

const startServer = apolloServer.start();

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  await startServer;
  await apolloServer.createHandler({ path: '/api/graphql' })(req, res);
}
