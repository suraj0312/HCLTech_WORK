import { initDb, executeQuery, closeDb, saveChanges } from '@backend/lib/fileUtils';
import { User, Transaction } from './types';
import { v4 as uuidv4 } from 'uuid';



export async function readUserByUsername(username: string) {
  let db;
  try {
    db = await initDb();
    const results = await executeQuery(db, 'SELECT * FROM users WHERE username = ?', [username]);
    if (results && results.length > 0) {
      const row = results[0];
      return { id: row.id, username: row.username, password: row.password, wallet_balance: row.wallet_balance };
    }
    return null;
  } catch (error) {
    console.error('Error reading user by username:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}

export async function saveToken(token: string, userId: string, expiresAt: string) {
  let db;
  try {
    db = await initDb();
    await executeQuery(db, 'DELETE FROM tokens WHERE user_id = ?;', [userId]);
    await saveChanges(db);

    await executeQuery(db, 'INSERT INTO tokens (token, user_id, expires_at) VALUES (?, ?, ?);', [token, userId, expiresAt]);
    await saveChanges(db);
  } catch (error) {
    console.error('Error saving token:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}

export async function removeToken(token: string) {
  let db;
  try {
    db = await initDb();
    await executeQuery(db, 'DELETE FROM tokens WHERE token = ?;', [token]);
    await saveChanges(db);
  } catch (error) {
    console.error('Error removing token:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}

export async function readToken(token: string) {
  let db;
  try {
    db = await initDb();
    const results = await executeQuery(db, 'SELECT * FROM tokens WHERE token = ?', [token]);
    if (results && results.length > 0) {
      const row = results[0];
      return { token: row.token, user_id: row.user_id, expires_at: row.expires_at };
    }
    return null;
  } catch (error) {
    console.error('Error reading token:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}

export async function saveUser(username: string, hashedPassword: string) {
  let db;
  try {
    db = await initDb();
    const userId = uuidv4();
    await executeQuery(db, 'INSERT INTO users (id, username, password, wallet_balance) VALUES (?, ?, ?, ?);', [userId, username, hashedPassword, 0]);
    await saveChanges(db);
    return { id: userId, username, password: hashedPassword, wallet: { balance: 0 } };
  } catch (error) {
    console.error('Error saving user:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}

export async function readUserById(userId: string) {
  let db;
  try {
    db = await initDb();
    const results = await executeQuery(db, 'SELECT * FROM users WHERE id = ?', [userId]);
    if (results && results.length > 0) {
      const row = results[0];
      return { id: row.id, username: row.username, password: row.password, wallet: { balance: row.wallet_balance } };
    }
    return null;
  } catch (error) {
    console.error('Error reading user by ID:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}

export async function updateUser(user: User): Promise<void> {
  let db;
  try {
    db = await initDb();
    await executeQuery(db, 'UPDATE users SET wallet_balance = ? WHERE id = ?;', [user.wallet_balance, user.id]);
    await saveChanges(db);
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}

export async function readUserTransactions(userId: string): Promise<Transaction[]> {
  let db;
  try {
    db = await initDb();
    const results = await executeQuery(db, 'SELECT * FROM transactions WHERE user_id = ?', [userId]);
    if (results) {
      return results.map(row => ({
        id: row.id,
        type: row.type,
        amount: row.amount,
        date: row.date,
        current_value: row.current_value,
        investment_id: row.investment_id,
        user_id: row.user_id
      }));
    }
    return [];
  } catch (error) {
    console.error('Error reading user transactions:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}


export async function addTransaction(transaction: Transaction): Promise<void> {
  let db;
  try {
    db = await initDb();
    await executeQuery(db, 'INSERT INTO transactions (id, type, amount, date, current_value, investment_id, user_id) VALUES (?, ?, ?, ?, ?, ?, ?);', 
                       [transaction.id, transaction.type, transaction.amount, transaction.date, transaction.current_value, transaction.investment_id, transaction.user_id]);
    await saveChanges(db);
  } catch (error) {
    console.error('Error adding transaction:', error);
    throw error;
  } finally {
    if (db) await closeDb(db);
  }
}