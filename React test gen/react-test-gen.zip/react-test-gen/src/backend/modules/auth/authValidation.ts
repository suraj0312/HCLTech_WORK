import Joi from 'joi';

const registerUserSchema = Joi.object({
    username: Joi.string().min(3).required(),
    password: Joi.string().min(3).required(),
});

const loginUserSchema = Joi.object({
    username: Joi.string().required(),
    password: Joi.string().required(),
});

interface UserInput {
    username: string;
    password: string;
}

export const validateRegisterUser = (input: UserInput) => {
    const {error} = registerUserSchema.validate(input);
    if (error) throw new Error(error.details[0].message);
};

export const validateLoginUser = (input: UserInput) => {
    const {error} = loginUserSchema.validate(input);
    if (error) throw new Error(error.details[0].message);
};