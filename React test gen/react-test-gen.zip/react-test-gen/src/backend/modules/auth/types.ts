export interface User {
    id: string;
    username: string;
    password: string;
    wallet_balance: number;
  }
  
  export interface Wallet {
    wallet_balance: number;
  }
  
  export interface Transaction {
    id: string;
    type: string;
    amount: number;
    date: string;
    current_value?: number;
    investment_id?: string;
    user_id: string;
  }
  
  export interface Investment {
    id: string;
    name: string;
    amount: number;
    isInWishlist?: boolean;
  }
  
  export interface UserTransaction {
    id: string;
    user_id?: string;
    type: string;
    amount: number;
    date: string;
    current_value?: number;
    investment_id?: string;
  }
  
  export interface UserTransactions {
    userId: string;
    transactions: UserTransaction[];
  }