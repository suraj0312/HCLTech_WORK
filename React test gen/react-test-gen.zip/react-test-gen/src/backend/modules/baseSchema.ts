import {gql} from 'apollo-server-micro';

const baseSchema = gql`
    type Query {
        _empty: String
    }

    type Mutation {
        _empty: String
    }
`;

export default baseSchema;
