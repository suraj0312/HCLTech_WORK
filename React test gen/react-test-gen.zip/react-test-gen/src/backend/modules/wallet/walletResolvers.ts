import { validateUpdateWallet } from './walletValidation';
import { UserInputError } from 'apollo-server-micro';
import { readUser, updateUser, readUserTransactions, addTransaction } from './fileUtils';
import { IResolvers } from '@graphql-tools/utils';
import { v4 as uuidv4 } from 'uuid';
import { User, Transaction } from '@backend/modules/auth/types';

const walletResolvers: IResolvers<unknown, { userId: string }> = {
  Query: {
    wallet: async (_, __, context) => {
      const { userId } = context;
      const user = await readUser(userId);

      if (!user) {
        throw new UserInputError('User not found');
      }

      return { balance: user.wallet_balance };
    },
    transactionHistory: async (_, __, context) => {
      const { userId } = context;
      const transactions = await readUserTransactions(userId);

      if (transactions.length === 0) {
        throw new UserInputError('No transactions found for this user');
      }

      return transactions;
    },
  },
  Mutation: {
    updateWallet: async (_, { balance, type }, { userId }) => {
      validateUpdateWallet({ balance, type });
      // console.log(userId)
      const user = await readUser(userId);
      console.log('user', user)

      if (!user) {
        throw new UserInputError('User not found');
      }

      if (type === 'deposit') {
        user.wallet_balance += balance;
      } else if (type === 'withdraw') {
        if (balance > user.wallet_balance) {
          throw new Error('Insufficient balance');
        }
        user.wallet_balance -= balance ?? 0;
      } else {
        throw new Error('Invalid operation type');
      }

      const transaction: Transaction = {
        id: uuidv4(),
        type,
        amount: balance,
        date: new Date().toISOString(),
        user_id: userId
      };
       await addTransaction(transaction);
      await updateUser(user);

      return { balance: user.wallet_balance };
    },
  },
};

export default walletResolvers;
