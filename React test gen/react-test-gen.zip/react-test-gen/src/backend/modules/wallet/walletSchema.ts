import {gql} from 'apollo-server-micro';

const walletSchema = gql`
    type Wallet {
        balance: Float
        transactions: [Transaction]
    }

    type TransactionPage {
        transactions: [Transaction]
        totalCount: Int
    }

    extend type Query {
        wallet: Wallet
        transactionHistory(page: Int, limit: Int): TransactionPage
    }

    extend type Mutation {
        updateWallet(balance: Float!, type: String!): Wallet
    }
`;

export default walletSchema;
