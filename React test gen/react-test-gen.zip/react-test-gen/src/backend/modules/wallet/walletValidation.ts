import Joi from 'joi';

const updateWalletSchema = Joi.object({
    balance: Joi.number().positive().required(),
    type: Joi.string().valid('deposit', 'withdraw').required(),
});

const validateUpdateWallet = (input: { balance: number; type: string }) => {
    const {error} = updateWalletSchema.validate(input);
    if (error) throw new Error(error.details[0].message);
};

export {
    validateUpdateWallet,
};
