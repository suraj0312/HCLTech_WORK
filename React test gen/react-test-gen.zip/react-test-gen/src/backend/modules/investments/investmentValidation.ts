import Joi from 'joi';

const addInvestmentSchema = Joi.object({
    name: Joi.string().regex(/^[a-zA-Z0-9 ]+$/).required(),
    amount: Joi.number().positive().max(1000000).required(),
  });

interface AddInvestmentInput {
    name: string;
    amount: number;
}

const validateAddInvestment = (input: AddInvestmentInput): void => {
    const {error} = addInvestmentSchema.validate(input);
    console.log(error);
    if (error) throw new Error(error.details[0].message);
};

export {
    validateAddInvestment,
};