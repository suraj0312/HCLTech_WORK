import {gql} from 'apollo-server-micro';

const investmentSchema = gql`
    type Investment {
        id: ID
        name: String
        amount: Float
        isInWishlist: Boolean
    }

    type InvestmentPage {
        investments: [Investment]
        totalCount: Int
    }

    extend type Query {
        investments(page: Int, limit: Int): InvestmentPage
        getInvestment(id: ID!): Investment
        searchInvestments(query: String!): [Investment]
        purchaseHistory: [Transaction]
    }

    extend type Mutation {
        addInvestment(name: String!, amount: Float!): Investment
        updateInvestment(id: ID!, name: String, amount: Float): Investment
        purchaseInvestment(id: ID!): Investment
        sellInvestment(id: ID!, amount: Float!): Investment
        deleteInvestment(id: ID!): Investment
    }
`;

export default investmentSchema;