import { initDb, executeQuery, closeDb, saveChanges } from '@backend/lib/fileUtils';
import { Investment, UserTransaction } from './types';
import { v4 as uuidv4 } from 'uuid';
import { UserInputError } from 'apollo-server-micro';

export async function readInvestments(page: number, limit: number, userId: string): Promise<{ investments: Investment[], totalCount: number }> {
    let db;
    try {
        db = await initDb();
        const offset = (page - 1) * limit;

        const query = `
            SELECT 
                investments.id AS id, 
                investments.name AS name, 
                investments.amount AS amount, 
                CASE WHEN wishlist.id IS NOT NULL THEN 1 ELSE 0 END AS isInWishlist
            FROM investments
            LEFT JOIN wishlist ON investments.id = wishlist.investment_id AND wishlist.user_id = ?
            LIMIT ? OFFSET ?
        `;
        const investments = (await executeQuery(db, query, [userId, limit, offset])) || [];

        const countQuery = 'SELECT COUNT(*) AS count FROM investments';
        const countResult = await executeQuery(db, countQuery);
        const totalCount = countResult && countResult[0] ? countResult[0].count : 0;

        return { investments, totalCount };
    } catch (error) {
        console.error('Error reading investments:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function writeInvestments(investments: Investment[]): Promise<void> {
    let db;
    try {
        db = await initDb();

        await executeQuery(db, 'DELETE FROM investments');
        const insertQuery = 'INSERT INTO investments (id, name, amount, date, user_id) VALUES (?, ?, ?, ?, ?)';

        for (const investment of investments) {
            await executeQuery(db, insertQuery, [investment.id, investment.name, investment.amount]);
        }

        await saveChanges(db);
    } catch (error) {
        console.error('Error writing investments:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function getInvestment(id: string): Promise<Investment> {
    let db;
    try {
        db = await initDb();

        const query = 'SELECT * FROM investments WHERE id = ?';
        const results = await executeQuery(db, query, [id]);

        if (!results || results.length === 0) {
            throw new UserInputError('Investment not found');
        }

        const row = results[0];
        return {
            id: row.id,
            name: row.name,
            amount: row.amount
        };
    } catch (error) {
        console.error('Error getting investment:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function searchInvestments(query: string): Promise<Investment[]> {
    let db;
    try {
        db = await initDb();

        const lowerCaseQuery = `%${query.trim().toLowerCase()}%`;
        const searchQuery = 'SELECT * FROM investments WHERE LOWER(name) LIKE ?';
        const investments = (await executeQuery(db, searchQuery, [lowerCaseQuery])) || [];

        return investments;
    } catch (error) {
        console.error('Error searching investments:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function addInvestment(name: string, amount: number): Promise<Investment> {
    let db;
    try {
        db = await initDb();

        const checkQuery = 'SELECT COUNT(*) AS count FROM investments WHERE name = ?';
        const checkResult = await executeQuery(db, checkQuery, [name]);
        const count = checkResult && checkResult[0] ? checkResult[0].count : 0;

        if (count > 0) {
            throw new UserInputError('Investment with the same name already exists');
        }

        const newInvestment: Investment = {
            id: uuidv4(),
            name,
            amount // Add appropriate user_id if needed
        };

        const insertQuery = 'INSERT INTO investments (id, name, amount, date, user_id) VALUES (?, ?, ?, ?, ?)';
        await executeQuery(db, insertQuery, [newInvestment.id, newInvestment.name, newInvestment.amount]);

        await saveChanges(db);
        return newInvestment;
    } catch (error) {
        console.error('Error adding investment:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function updateInvestment(id: string, name?: string, amount?: number): Promise<Investment> {
    let db;
    try {
        db = await initDb();

        const fetchQuery = 'SELECT * FROM investments WHERE id = ?';
        const results = await executeQuery(db, fetchQuery, [id]);

        if (!results || results.length === 0) {
            throw new UserInputError('Investment not found');
        }

        const investment = results[0];
        if (name !== undefined) investment.name = name;
        if (amount !== undefined) investment.amount = amount;

        const updateQuery = 'UPDATE investments SET name = ?, amount = ? WHERE id = ?';
        await executeQuery(db, updateQuery, [investment.name, investment.amount, id]);

        await saveChanges(db);
        return investment;
    } catch (error) {
        console.error('Error updating investment:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function deleteInvestment(id: string): Promise<Investment> {
    let db;
    try {
        db = await initDb();

        const fetchQuery = 'SELECT * FROM investments WHERE id = ?';
        const results = await executeQuery(db, fetchQuery, [id]);

        if (!results || results.length === 0) {
            throw new UserInputError('Investment not found');
        }

        const investment = results[0];

        const deleteQuery = 'DELETE FROM investments WHERE id = ?';
        await executeQuery(db, deleteQuery, [id]);

        await saveChanges(db);
        return investment;
    } catch (error) {
        console.error('Error deleting investment:', error);
        throw error;
    } finally {
        if (db) await closeDb(db);
    }
}

export async function purchaseHistory(user_id: string): Promise<UserTransaction[]> {
  let db;
  try {
      db = await initDb();
      const results = await executeQuery(db, 'SELECT * FROM transactions WHERE user_id = ?', [user_id]);
      if (!results) {
        throw new Error('Query returned no results');
    }

      const transactions: UserTransaction[] = results.map(row => ({
          id: row.id,
          type: row.type,
          amount: row.amount,
          date: row.date,
          current_value: row.current_value,
          investment_id: row.investment_id
      }));
      return transactions;
  } catch (error) {
      console.error('Error fetching purchase history:', error);
      throw error;
  } finally {
      if (db) await closeDb(db);
  }
}

export async function sellInvestment(id: string, amount: number, user_id: string): Promise<Investment> {
  let db;
  try {
      db = await initDb();
      const investmentResults = await executeQuery(db, 'SELECT * FROM investments WHERE id = ?', [id]);
      if (!investmentResults || investmentResults.length === 0) {
        throw new UserInputError('Investment not found');
    }
      const investment = investmentResults[0];
      if (amount > investment.amount) {
          throw new UserInputError('Insufficient amount to sell');
      }

      const userTransactions = await executeQuery(db, 'SELECT * FROM transactions WHERE user_id = ?', [user_id]);
      const transaction: UserTransaction = {
          id: uuidv4(),
          user_id,
          type: 'sell',
          amount,
          date: new Date().toISOString(),
          current_value: amount,
          investment_id: id
      };
      await executeQuery(db, 'INSERT INTO transactions (id, user_id, type, amount, date, current_value, investment_id) VALUES (?, ?, ?, ?, ?, ?, ?)', 
          [transaction.id, transaction.user_id, transaction.type, transaction.amount, transaction.date, transaction.current_value, transaction.investment_id]);
      await executeQuery(db, 'UPDATE investments SET amount = amount - ? WHERE id = ?', [amount, id]);
      await saveChanges(db);
      return investment;
  } catch (error) {
      console.error('Error selling investment:', error);
      throw error;
  } finally {
      if (db) await closeDb(db);
  }
}

export async function purchaseInvestment(id: string, user_id: string): Promise<Investment> {
  let db;
  try {
      db = await initDb();
      const investmentResults = await executeQuery(db, 'SELECT * FROM investments WHERE id = ?', [id]);
      if (!investmentResults || investmentResults.length === 0) {
        throw new UserInputError('Investment not found');
    }
          const investment = investmentResults[0];

      const userResults = await executeQuery(db, 'SELECT * FROM users WHERE id = ?', [user_id]);
      if (userResults && userResults.length === 0) {
          throw new UserInputError('User not found');
      }
      if (!userResults || userResults.length === 0) {
        throw new UserInputError('User not found');
    }

      const user = userResults[0];
      if (user.wallet_balance < investment.amount) {
          throw new UserInputError('Insufficient balance to purchase this investment');
      }

      const userTransactions = await executeQuery(db, 'SELECT * FROM transactions WHERE user_id = ?', [user_id]);
      user.wallet_balance -= investment.amount;
      await executeQuery(db, 'UPDATE users SET wallet_balance = ? WHERE id = ?', [user.wallet_balance, user_id]);

      const randomValue = Math.floor(Math.random() * (500 - 100 + 1)) + 100;
      const shouldAdd = Math.random() >= 0.5;
      let amount = investment.amount;
      amount = shouldAdd ? amount + randomValue : Math.abs(amount - randomValue);

      const transaction: UserTransaction = {
          id: uuidv4(),
          user_id,
          type: 'purchase',
          amount: investment.amount,
          date: new Date().toISOString(),
          current_value: amount,
          investment_id: id
      };
      await executeQuery(db, 'INSERT INTO transactions (id, user_id, type, amount, date, current_value, investment_id) VALUES (?, ?, ?, ?, ?, ?, ?)', 
          [transaction.id, transaction.user_id, transaction.type, transaction.amount, transaction.date, transaction.current_value, transaction.investment_id]);
      await executeQuery(db, 'DELETE FROM wishlist WHERE investment_id = ? AND user_id = ?', [id, user_id]);
      await saveChanges(db);
      return investment;
  } catch (error) {
      console.error('Error purchasing investment:', error);
      throw error;
  } finally {
      if (db) await closeDb(db);
  }
}
