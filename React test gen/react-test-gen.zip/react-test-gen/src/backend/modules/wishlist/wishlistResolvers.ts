import { IResolvers } from '@graphql-tools/utils';
import { validateWishlistId } from './wishlistValidation';
import { UserInputError } from 'apollo-server-micro';
import { WishlistItem } from './types';
import { v4 as uuidv4 } from 'uuid';
import { getWishlist, getInvestmentById, checkWishlistItem, addWishlistItem, removeWishlistItem } from './fileUtils';

const wishlistResolvers: IResolvers = {
  Query: {
    wishlist: async (_: unknown, { page = 1, limit = 10 }: { page: number; limit: number }, { userId }: { userId: string }) => {
      const offset = (page - 1) * limit;
      const { wishlist, totalCount } = await getWishlist(userId, limit, offset);
      return { wishlist, totalCount };
    },
  },
  Mutation: {
      addToWishlist: async (_: unknown, { id }: { id: string }, { userId }: { userId: string }): Promise<{ wishlistItem: WishlistItem, totalCount: number }> => {
        validateWishlistId({ id });
  
        const investment = await getInvestmentById(id);
        if (!investment) {
          throw new UserInputError('Investment not found');
        }
  
        const exists = await checkWishlistItem(id, userId);
        if (exists) {
          throw new UserInputError('Investment already in wishlist');
        }
        const randomValue = Math.floor(Math.random() * (500 - 100 + 1)) + 100;
        const shouldAdd = Math.random() >= 0.5;
        let amount = investment.amount;
        amount = shouldAdd ? amount + randomValue : Math.abs(amount - randomValue);
  
        const wishlistItem: WishlistItem = {
          id: uuidv4(),
          investment_id: investment.id,
          name: investment.name,
          current_value: amount,
          amount: investment.amount,
          user_id: userId,
        };
  
        const totalCount = await addWishlistItem(wishlistItem);
        return { wishlistItem, totalCount };
      },
          removeFromWishlist: async (_: unknown, { id, limit, pageNumber }: { id: string; limit: number; pageNumber: number }, { userId }: { userId: string }): Promise<{ removedItem: WishlistItem, nextItem: WishlistItem | null, totalCount: number }> => {
        const offset = (pageNumber - 1) * limit;
        const { removedItem, nextItem, totalCount } = await removeWishlistItem(id, userId, limit, offset);
        return { removedItem, nextItem, totalCount };
      },
  },
};

export default wishlistResolvers;
