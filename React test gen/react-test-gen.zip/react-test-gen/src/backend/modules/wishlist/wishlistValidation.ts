import Joi from 'joi';

const wishlistIdSchema = Joi.object({
    id: Joi.string().required(),
});

interface WishlistIdInput {
    id: string;
}

const validateWishlistId = (input: WishlistIdInput): void => {
    const {error} = wishlistIdSchema.validate(input);
    if (error) throw new Error(error.details[0].message);
};

export {
    validateWishlistId,
};