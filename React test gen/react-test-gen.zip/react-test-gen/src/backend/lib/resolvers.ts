import {mergeResolvers} from '@graphql-tools/merge';
import {IResolvers} from '@graphql-tools/utils';

import authResolvers from '../modules/auth/authResolvers';
import investmentResolvers from '../modules/investments/investmentResolvers';
import walletResolvers from '../modules/wallet/walletResolvers';
import wishlistResolvers from '../modules/wishlist/wishlistResolvers';

// Define the context type
interface Context {
    userId: string;
    token: string;
}

// Merge all resolvers
const resolvers: IResolvers<unknown, Context> = mergeResolvers([
    authResolvers,
    investmentResolvers,
    walletResolvers,
    // mutualFundResolvers,
    wishlistResolvers,
]);

export default resolvers;
