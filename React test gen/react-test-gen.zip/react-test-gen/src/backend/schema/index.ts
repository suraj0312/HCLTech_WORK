import {mergeResolvers, mergeTypeDefs} from '@graphql-tools/merge';
import authSchema from '../modules/auth/authSchema';
import investmentSchema from '../modules/investments/investmentSchema';
import walletSchema from '../modules/wallet/walletSchema';
import wishlistSchema from '../modules/wishlist/wishlistSchema';
import authResolvers from '../modules/auth/authResolvers';
import investmentResolvers from '../modules/investments/investmentResolvers';
import walletResolvers from '../modules/wallet/walletResolvers';
import wishlistResolvers from '../modules/wishlist/wishlistResolvers';

const typeDefs = mergeTypeDefs([authSchema, investmentSchema, walletSchema, wishlistSchema]);

const resolvers = mergeResolvers([authResolvers, investmentResolvers, walletResolvers, wishlistResolvers]);

export {typeDefs, resolvers};
