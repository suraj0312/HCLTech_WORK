import jwt, {JwtPayload} from 'jsonwebtoken';
import {isTokenActive} from '../lib/tokenManager';
import {NextApiRequest} from 'next';
import { readToken } from '@backend/modules/auth/fileUtils';

const SECRET_KEY = process.env.SECRET_KEY ?? 'your_secret_key';

interface DecodedToken extends JwtPayload {
    userId: string;
}

interface AuthenticatedRequest extends NextApiRequest {
    userId?: string;
    token?: string;
}

export const verifyToken = async(req: AuthenticatedRequest): Promise<{ userId: string; token: string; }> => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      throw new Error('Authorization header is required');
    }
    const token = authHeader.split(' ')[1];
    if (!token) {
      throw new Error('Token is required');
    }
    try { 
      const tokenData = await readToken(token);
      if (!tokenData || new Date(tokenData.expires_at) < new Date()) {
        throw new Error('Invalid or expired token');
      }
      const decoded = jwt.verify(token, SECRET_KEY) as DecodedToken;
       return { userId: decoded.userId, token };
    } catch (error) {
      console.log(token)
      throw new Error(`Invalid Token: ${(error as Error).message}`,);
    }
  };
  
