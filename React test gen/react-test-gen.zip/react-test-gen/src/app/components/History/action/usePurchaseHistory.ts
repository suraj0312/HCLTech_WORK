import {  useEffect, useActionState, startTransition } from 'react';
import useInvestment from '@hooks/useInvestment';

interface DashboardState {
  hasFetched: boolean;
}

interface Action {
  type: string;
}

const usePurchaseHistory = () => {
  const { fetchPurchaseHistory, totalCount, purchaseHistory, loading, error } = useInvestment();
  const [state, dispatch] = useActionState<DashboardState, Action>(async (prevState, { type }) => {
    if (type === 'fetchHistory' && !prevState.hasFetched) {
       fetchPurchaseHistory();
      return { ...prevState, hasFetched: true };
    }
    return prevState;
  }, { hasFetched: false });

  useEffect(() => {
    if (!state.hasFetched) {
      startTransition(() => {
        dispatch({ type: 'fetchHistory' });
      });
    }
  }, [state.hasFetched, dispatch]);

  return { totalCount, purchaseHistory, loading, error };
};

export default usePurchaseHistory;
