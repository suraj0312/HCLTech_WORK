'use client';

import React, { useCallback } from 'react';
import {useRouter} from 'next/navigation';
import Pagination from '@components/Common/Pagination';
import Button from '@_components/Button';
import AddToWishlistButton from '@components/Wishlist/AddToWishlistButton';
import { Investment } from '@_types/Investment';

interface InvestmentTableProps {
    data: Investment[];
    totalCount: number;
    currentPage: number;
    setPage: (page: number) => void;
    itemsPerPage: number;
    wishListcurrentPage:number;
}

const InvestmentTable: React.FC<InvestmentTableProps> = ({
                                                             data = [],
                                                             totalCount,
                                                             currentPage,
                                                             setPage,
                                                             itemsPerPage,
                                                             wishListcurrentPage
                                                         }) => {
    const router = useRouter();
    const handleViewClick = useCallback((id: string) => {
        router.push(`/investments/${id}`);
      }, [router]);
    return (
        <>
            <table>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Amount</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                {data?.map((investment) => (
                    <tr key={investment.id}>
                        <td>{investment.name}</td>
                        <td>{investment.amount}</td>
                        <td>
                        <Button onClick={() => handleViewClick(investment.id)}>View</Button>
                        <AddToWishlistButton
                                id={investment.id}
                                name={investment.name}
                                // current_value={investment.current_value}
                                // amount={investment.amount}
                                isInWishlist={investment.isInWishlist}
                                limit={itemsPerPage}
                                pageNumber={currentPage}
                                wishListpageNumber={wishListcurrentPage}
                                showRemove={false}
                            />
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            {(data && data?.length > 0 && totalCount > 0 && (
                <Pagination
                    currentPage={currentPage}
                    totalCount={totalCount}
                    itemsPerPage={itemsPerPage}
                    onPageChange={setPage}
                />
            ))}
        </>
    );
};

export default InvestmentTable;