'use client';
import React, {useEffect} from 'react';
import useWallet from '@hooks/useWallet';
import Navbar from '@components/Common/Navbar';
import Footer from '@components/Common/Footer';

const Wallet: React.FC = () => {
    const {fetchWalletBalance, walletBalance} = useWallet();

    useEffect(() => {
        fetchWalletBalance();
    }, []);

    return (
        <div>
            <main>
                <h1>Wallet</h1>
                <p>Balance: ₹{walletBalance}</p>
            </main>
        </div>
    );
};

export default Wallet;
