'use client';

import React from 'react';
import useWallet from '@hooks/useWallet';
import Button from "@_components/Button";

const WithdrawBalance: React.FC = () => {
    const {withdrawBalance} = useWallet();

    const handleWithdrawBalance = () => {
        const amount = parseFloat(prompt('Enter amount to withdraw:') || '0');
        if (amount > 0) {
            withdrawBalance(amount);
        } else {
            alert('Invalid amount');
        }
    };

    return (
        <Button onClick={handleWithdrawBalance}>Withdraw Balance</Button>
    );
};

export default WithdrawBalance;
