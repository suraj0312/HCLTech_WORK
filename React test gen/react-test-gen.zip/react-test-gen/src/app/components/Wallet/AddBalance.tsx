'use client';

import React from 'react';
import useWallet from '@hooks/useWallet';
import Button from "@_components/Button";

const AddBalance: React.FC = () => {
    const {addBalance} = useWallet();

    const handleAddBalance = () => {
        const amount = parseFloat(prompt('Enter amount to add:') || '0');
        if (amount > 0) {
            addBalance(amount);
        } else {
            alert('Invalid amount');
        }
    };

    return (
        <Button onClick={handleAddBalance}>Add Balance</Button>
    );
};

export default AddBalance;
