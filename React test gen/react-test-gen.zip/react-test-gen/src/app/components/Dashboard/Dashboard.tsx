'use client';
import React, { startTransition,  useCallback, useEffect, useMemo, useState } from 'react';
import useInvestment from '@hooks/useInvestment';
import useWallet from '@hooks/useWallet';
import useWishlist from '@hooks/useWishlist';
import ErrorComponent from './Error';
import config from '@config/config';
import styles from '@styles/DashboardPage.module.css';
import Loading from '@components/Common/Loading';
import InvestmentTable from './InvestmentTable';
import WalletDetails from './WalletDetails';
import WishlistTable from './WishlistTable';
import useDashboardActions from './action/useDashboardActions';

const DashboardPage: React.FC = () => {
    const { walletBalance, fetchWalletBalance } = useWallet();
    const [investmentPage, setInvestmentPage] = useState(1);
    const [wishlistPage, setWishlistPage] = useState(1);
    const itemswishlistPerPage = config.dashboard.wishlist.itemPerPage;
    const itemsinvestmentsPerPage = config.dashboard.investments.itemPerPage;

    const {  formAction, investments, investmentTotalCount, wishlist, wishlistTotalCount } = useDashboardActions(investmentPage, wishlistPage, itemsinvestmentsPerPage, itemswishlistPerPage);

    useEffect(() => {
        fetchWalletBalance();
    }, []);

    const handleInvestmentPageChange = useCallback((page: number) => {
        console.log(page)
        setInvestmentPage(page);
        startTransition(() => {
            formAction({ type: 'resetInvestments' });
        });

    }, [formAction]);

    const handleWishlistPageChange = useCallback((page: number) => {
        
        setWishlistPage(page);
        startTransition(() => {
            formAction({ type: 'resetWishlist' });
        });

    }, [formAction]);

    const { loading: investmentLoading, error: investmentError } = useInvestment();
    const { loading: walletLoading, error: walletError } = useWallet();
    const { loading: wishlistLoading, error: wishlistError, pageLoadingMessage, page:wishListPageUpdate } = useWishlist();

    useEffect(()=>{
        console.log(wishlistTotalCount <= itemswishlistPerPage, itemswishlistPerPage, wishlistTotalCount)
        if (wishlistTotalCount <= itemswishlistPerPage) {
                setWishlistPage(1);
              }
    },[wishlistTotalCount])

    const errors = useMemo(
        () => [
            { key: 'investmentError', message: investmentError },
            { key: 'walletError', message: walletError },
            { key: 'wishlistError', message: wishlistError },
        ],
        [investmentError, walletError, wishlistError]
    );

    return (
        <div className={styles.dashboardContainer} key='dashboard-page'>
            <div className={styles.header}>
                <h1 className={styles.title}>Dashboard</h1>
                {errors.map(
                    (error) => error.message && <ErrorComponent key={error.key} message={error.message} />
                )}
            </div>

            <div className={styles.sections}>
                {investmentLoading ? <Loading message={'Investment List is loading'} /> :
                    <section className={styles.section}>
                        <h2 className={styles.sectionTitle}>Investment List</h2>
                        <InvestmentTable
                            data={investments}
                            totalCount={investmentTotalCount}
                            currentPage={investmentPage}
                            wishListcurrentPage={wishlistPage}
                            setPage={handleInvestmentPageChange}
                            itemsPerPage={itemsinvestmentsPerPage}
                            currency={config.currency}
                        />
                    </section>}
                {walletLoading ? <Loading message={'Wallet Details is loading'} /> :
                    <section className={styles.section}>
                        <h2 className={styles.sectionTitle}>Wallet Details</h2>
                        <WalletDetails balance={walletBalance} />
                    </section>
                }
                {wishlistLoading ? <Loading message={pageLoadingMessage ?? 'Wishlist is loading'} /> :
                    <section className={styles.section}>
                        <h2 className={styles.sectionTitle}>Wishlist</h2>
                        <WishlistTable
                            data={wishlist}
                            totalCount={wishlistTotalCount}
                            currentPage={wishlistPage}
                            setPage={handleWishlistPageChange}
                            itemsPerPage={itemswishlistPerPage}
                            currency={config.currency}
                        />
                    </section>
                }
            </div>
        </div>
    );
};

export default DashboardPage;
