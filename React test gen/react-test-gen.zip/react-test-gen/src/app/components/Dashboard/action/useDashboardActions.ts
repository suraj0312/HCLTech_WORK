import {  useEffect, useActionState, startTransition } from 'react';
import useInvestment from '@hooks/useInvestment';
import useWishlist from '@hooks/useWishlist';
interface DashboardState {
  hasFetchedInvestments: boolean;
  hasFetchedWishlist: boolean;
}

interface Action {
  type: string;
}

const useDashboardActions = (investmentPage: number, wishlistPage: number, itemsinvestmentsPerPage: number, itemswishlistPerPage: number) => {
  const { investments, totalCount: investmentTotalCount, fetchInvestment } = useInvestment();
  const { wishlist, totalCount: wishlistTotalCount, fetchWishlist } = useWishlist();
  
  const [state, formAction] = useActionState<DashboardState, Action>(async (prevState, { type }) => {
    if (type === 'fetchInvestments' && !prevState.hasFetchedInvestments) {
      console.log('Fetching investments for page:', investmentPage);
      fetchInvestment(investmentPage, itemsinvestmentsPerPage);

      return { ...prevState, hasFetchedInvestments: true };
    }
    if (type === 'fetchWishlist' && !prevState.hasFetchedWishlist) {
      console.log('Fetching wishlist for page:', wishlistPage);
      
       fetchWishlist(wishlistPage, itemswishlistPerPage);
      return { ...prevState, hasFetchedWishlist: true };
    }
    if (type === 'resetInvestments') {
      return { ...prevState, hasFetchedInvestments: false };
    }
    if (type === 'resetWishlist') {
      return { ...prevState, hasFetchedWishlist: false };
    }
    return prevState;
  }, { hasFetchedInvestments: false, hasFetchedWishlist: false });

  useEffect(() => {
    if (!state.hasFetchedInvestments) {
      startTransition(() => {
        formAction({ type: 'fetchInvestments' });
      });
    }
  }, [investmentPage, itemsinvestmentsPerPage, fetchInvestment, formAction]);


  useEffect(() => {
    if (!state.hasFetchedWishlist) {
      startTransition(() => {

        formAction({ type: 'fetchWishlist' });
         
      });
    }
  }, [wishlistPage, itemswishlistPerPage, fetchWishlist, formAction]);

  return { state, formAction, investments, investmentTotalCount,currentWishlistPage:wishlistPage, wishlist, wishlistTotalCount };
};

export default useDashboardActions;
