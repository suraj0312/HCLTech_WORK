'use client';

import React from 'react';
import {useRouter} from 'next/navigation';
import Pagination from '@components/Common/Pagination';
import Button from '@_components/Button';
import AddToWishlistButton from '@components/Wishlist/AddToWishlistButton';
import { WishlistItem } from '@_types/WishlistItem';
import config from '@config/config';

interface WishlistTableProps {
    data: WishlistItem[];
    totalCount: number;
    currentPage: number;
    setPage: (page: number) => void;
    itemsPerPage: number;
    currency: string;

}

const WishlistTable: React.FC<WishlistTableProps> = ({data = [], totalCount, currentPage, setPage, itemsPerPage, currency}) => {
    const router = useRouter();
    return (
        <>
            {data.length > 0 ? (
                <>
                    <table>
                        <thead>
                        <tr>
                            <th>Name</th>
                            {/* <th>Current Value</th> */}
                            <th>Amount</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {data.map((item) => (
                            <tr key={item.id}>
                                <td>{item.name}</td>
                                {/* <td>{item.current_value !== null ? `₹${item.current_value}` : 'N/A'}</td> */}
                                <td>{item.amount !== null ? `${currency}${item.amount}` : 'N/A'}</td>
                                <td>
                                    <Button onClick={() => router.push(`/investments/${item.investment_id}`)}>View</Button>
                                    <AddToWishlistButton
                                        id={item.id}
                                        name={item.name}
                                        // current_value={item.current_value}
                                        // amount={item.amount}
                                        isInWishlist={true}
                                        limit={itemsPerPage}
                                        pageNumber={currentPage}
                                        showRemove={true}
                                    />
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                    {(data && data?.length > 0 && totalCount > 0 && (
                        <Pagination
                            currentPage={currentPage}
                            totalCount={totalCount}
                            itemsPerPage={itemsPerPage}
                            onPageChange={setPage}
                        />
                    ))}
                </>
            ) : (
                <p>No items in your wishlist.</p>
            )}
        </>
    );
};

export default WishlistTable;