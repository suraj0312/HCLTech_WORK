'use client';
import React from 'react';

interface WishlistItemProps {
    item: {
        id: string;
        name: string;
        current_value: number | null;
        amount: number | null;
    };
    onRemove: (id: string) => void;
}

const WishlistItem: React.FC<WishlistItemProps> = ({item, onRemove}) => {
    return (
        <tr>
            <td>{item.name}</td>
            <td>{item.current_value !== null ? `₹${item.current_value}` : 'N/A'}</td>
            <td>{item.amount !== null ? `₹${item.amount}` : 'N/A'}</td>
            <td>
                <button onClick={() => onRemove(item.id)}>Remove</button>
            </td>
        </tr>
    );
};

export default WishlistItem;