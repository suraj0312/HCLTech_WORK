import React from 'react';
import useForm from '@hooks/useForm';
import styles from '@styles/Login.module.css';
import Button from '@_components/Button';
import { useFormStatus } from 'react-dom';

interface AuthFormProps {
  type: 'login' | 'register';
  onSubmit: ((values: { username: string; password: string }) => void) | null;
}

const AuthForm: React.FC<AuthFormProps> = ({ type, onSubmit }) => {
  const { values, handleChange, handleSubmit } = useForm({ username: '', password: '' }, onSubmit);
  const { pending } = useFormStatus();

  return (
    <div className={styles.loginPage} key={type}>
      <form onSubmit={handleSubmit}>
        <label htmlFor="username" className={styles.label}>Username:</label>
        <input id="username" type="text" placeholder='Username' className={styles.input} name="username" value={values.username}
          onChange={handleChange} required />
        <label htmlFor="password" className={styles.label}>Password:</label>
        <input id="password" type="password" placeholder='Password' className={styles.input} name="password" value={values.password}
          onChange={handleChange} required />
        <Button type='submit' onClick={handleSubmit} prefetch={true} className={styles.button} disabled={pending || !onSubmit}>
          {type === 'login' ? 'Login' : 'Register'}
        </Button>
      </form>
      <p className={styles.infoText}>
        {type === 'register' ? (
          <>
            Already Registered? <Button href="/login">Login</Button>
          </>
        ) : (
          <>
            New here? <Button href="/register">Register</Button>
          </>
        )}
      </p>
    </div>
  );
};

export default AuthForm;