'use client';

import React, {useCallback} from 'react';
import useAuth from '@hooks/useAuth';

interface LogoutProps {
    className?: string;
}

const Logout: React.FC<LogoutProps> = ({className}) => {
    const {logoutUser} = useAuth();

    const handleLogout = useCallback(() => {
        console.log('Logout button clicked');
        logoutUser();
    }, []);

    console.log('Logout component rendered');

    return (
        <button key="logout-button" onClick={handleLogout} className={className}>
            Logout
        </button>
    );
};

export default React.memo(Logout);