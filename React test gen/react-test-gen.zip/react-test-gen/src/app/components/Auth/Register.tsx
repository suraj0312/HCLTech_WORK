'use client';

import React, { useState } from 'react';
import AuthForm from '@components/Auth/AuthForm';
import Loading from '@components/Common/Loading';
import Error from '@components/Common/Error';
import useAuth from '@hooks/useAuth';

const Register: React.FC = () => {
  const { registerUser, isLoggedIn, loading, error } = useAuth();
  const [formError, setFormError] = useState<string | null>(null);

  const handleSubmit = (values: { username: string; password: string }) => {
    if (!values.username || !values.password) {
      setFormError('Please fill out this field');
      return;
    }
    setFormError(null);
    registerUser(values);
  };

  if (isLoggedIn) return <Loading />;

  return (
    <div>
      <h1>Register</h1>
      {error && <Error message={error || "Something went wrong"} />}
      {formError && <Error message={formError} />}
      <AuthForm type="register" onSubmit={loading ? null : handleSubmit} />
    </div>
  );
};

export default Register;