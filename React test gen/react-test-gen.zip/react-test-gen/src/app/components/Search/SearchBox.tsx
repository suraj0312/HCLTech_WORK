'use client';
import React, {useEffect, useState} from 'react';
import styles from '@styles/SearchBox.module.css';

interface SearchBoxProps {
    onSearch: (query: string) => void;
}

const SearchBox: React.FC<SearchBoxProps> = ({onSearch}) => {
    const [query, setQuery] = useState('');

    useEffect(() => {
        if (query.length >= 3) {
            onSearch(query);
        }
    }, [query, onSearch]);

    return (
        <div className={styles.searchBox}>
            <input
                type="text"
                placeholder="Search..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className={styles.input}
            />
        </div>
    );
};

export default SearchBox;
