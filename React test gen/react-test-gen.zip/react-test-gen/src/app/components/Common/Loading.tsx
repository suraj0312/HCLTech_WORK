'use client';

import React from 'react';

interface LoadingProps {
    message?: string;
}

const Loading: React.FC<LoadingProps> = ({message}) => {
    return <div>{message || 'Loading...'}</div>;
};

export default Loading;
