'use client';

import React, {  useMemo, useRef,  useCallback, Suspense } from 'react';
import { usePathname } from 'next/navigation';
import { useAppSelector } from '@hooks/useAppSelector';
import Button from '@_components/Button';
import styles from '@styles/NavigationLinks.module.css';
import dynamic from 'next/dynamic';

const GuestLinks = dynamic(() => import('./GuestLinks'), { ssr: false });
const UserLinks = dynamic(() => import('./UserLinks'), { ssr: false });

const NavigationLinks: React.FC = React.memo(() => {
    const { isLoggedIn } = useAppSelector((state) => state.auth);
   
    const linksRef = useRef(false);

    const generateLinks = useCallback(() => {

        if (!isLoggedIn && !linksRef.current) {
             linksRef.current = true;
            return <GuestLinks key='guest-links'  />;
        }
         if (isLoggedIn) {
             return <UserLinks key={'user-links'}/>;
        }
        return null;
    }, [isLoggedIn]);

    const links = useMemo(() => generateLinks(), [generateLinks]);

    // if (!isReady) {
    //     return null;
    // }

    // console.log('Rendering NavigationLinks');
    return (
        <nav className={styles.nav} key="nav">
        <ul key="nav-ul">
            <li key="nav-home">
                <Button href="/home" prefetch={true} className={styles.button}>
                    Home
                </Button>
            </li>
            <Suspense fallback={<div>Loading links...</div>} key="nav-suspense">
                {links}
            </Suspense>
        </ul>
    </nav>

    );
});

export default React.memo(NavigationLinks);