'use client';

import React from 'react';

interface ErrorProps {
    message: string;
}

const Error: React.FC<ErrorProps> = ({message}) => {
    return <div role="alert" style={{
        color: 'red',
        backgroundColor: '#f8d7da',
        padding: '10px',
        borderRadius: '5px',
        border: '1px solid #f5c6cb',
        margin: '10px 0',
        fontFamily: 'Arial, sans-serif',
        fontSize: '14px',
    }}>{message}</div>;
};

export default Error;
