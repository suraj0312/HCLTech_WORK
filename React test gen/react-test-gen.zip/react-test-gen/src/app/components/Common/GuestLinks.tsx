'use client';

import React from 'react';
import Button from '@_components/Button';
import styles from '@styles/NavigationLinks.module.css';
import { usePathname } from 'next/navigation';

// interface GuestLinksProps {
//     currentPath: string;
// }

const GuestLinks: React.FC = React.memo(() => {
    // console.log('Rendering GuestLinks');
    const currentPath = usePathname();
    //  if(currentPath == '/dashboard')
    //     return null;
    return (
        <>
        {(currentPath !== '/login' && currentPath !== '/dashboard') && (
            <li key="login">
                <Button href="/login" prefetch={true} className={styles.button}>
                    Login
                </Button>
            </li>
        )}
        {(currentPath !== '/register' && currentPath !== '/dashboard') && (
            <li key="register">
                <Button href="/register" prefetch={true} className={styles.button}>
                    Register
                </Button>
            </li>
        )}
    </>
    );
});

export default GuestLinks;