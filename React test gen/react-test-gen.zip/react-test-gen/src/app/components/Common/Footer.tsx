'use client';

import React from 'react';

const Footer = () => {
    return (
        <footer key='footer' style={{ textAlign: 'center' }}>
            <p >&copy; {new Date().getFullYear()} Investment Dashboard. By Kunal.</p>
        </footer>
    );
};

export default Footer;