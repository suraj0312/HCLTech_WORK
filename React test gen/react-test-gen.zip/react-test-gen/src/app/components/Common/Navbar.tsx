'use client';

import React from 'react';
import NavigationLinks from '@components/Common/NavigationLinks';

const Navbar: React.FC = () => {
    // console.log('navbar rendered');
    return (
          <NavigationLinks key='nav-bar'/> 
        
    );
};

export default React.memo(Navbar);