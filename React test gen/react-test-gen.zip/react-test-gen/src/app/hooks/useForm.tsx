'use client';
import React, {useState} from 'react';

const useForm = (
    initialValues: { username: string; password: string },
    onSubmit: ((values: { username: string; password: string }) => void) | null
) => {
    const [values, setValues] = useState(initialValues);

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const {name, value} = event.target;
        setValues({
            ...values,
            [name]: value,
        });
    };

    const handleSubmit = (event: React.FormEvent) => {
        event.preventDefault();
        if (onSubmit) {
            onSubmit(values);
        }
    };

    return {
        values,
        handleChange,
        handleSubmit,
    };
};

export default useForm;
