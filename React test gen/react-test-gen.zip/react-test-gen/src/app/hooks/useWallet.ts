import {useAppDispatch, useAppSelector} from '@hooks/useAppSelector';
import {
    addBalance as addBalanceAction,
    fetchBalanceStart,
    withdrawBalance as withdrawBalanceAction
} from '@saga-operations/actions/walletActions';

const useWallet = () => {
    const dispatch = useAppDispatch();
    const {walletBalance, loading, error} = useAppSelector((state) => state.wallet);

    const fetchWalletBalance = () => {
        dispatch(fetchBalanceStart());
    };
    const addBalance = (amount: number) => {
        dispatch(addBalanceAction(amount));
    };
    const withdrawBalance = (amount: number) => {
        dispatch(withdrawBalanceAction(amount));
    };
    return {walletBalance, loading, error, fetchWalletBalance, addBalance, withdrawBalance};
};

export default useWallet;
