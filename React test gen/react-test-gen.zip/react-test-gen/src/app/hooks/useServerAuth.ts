import { GetServerSidePropsContext } from 'next';
import { checkAuthStateStart } from '@saga-operations/actions/authActions';
import { AppDispatch } from '@saga-operations/store';

export const useServerAuth = async (context: GetServerSidePropsContext, dispatch: AppDispatch) => {
  dispatch(checkAuthStateStart());
};