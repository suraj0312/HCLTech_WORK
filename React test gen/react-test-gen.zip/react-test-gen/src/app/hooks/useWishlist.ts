import { useAppDispatch, useAppSelector } from '@hooks/useAppSelector';
import {
    addToWishlistStart as addToWishlistAction,
    fetchWishlistStart,
    removeFromWishlistStart as removeFromWishlistAction,
    setWishlistPage,
} from '@saga-operations/actions/wishlistActions';
import { WishlistItem } from '@_types/WishlistItem';

const useWishlist = () => {
    const dispatch = useAppDispatch();
    const { items: wishlist, totalCount, loading, error, page, message } = useAppSelector((state) => state.wishlist);

    const fetchWishlist = (page: number, limit: number) => {
        dispatch(fetchWishlistStart({ page, limit }));
    };

    const addToWishlist = (item: WishlistItem) => {
        dispatch(addToWishlistAction(item));
    };

    const removeFromWishlist = (id: string, limit: number, pageNumber: number) => {
        dispatch(removeFromWishlistAction({ id, limit, pageNumber }));
    };
    
    const setPage = (page: number) => {
        console.log('setWishlistPage',page)
        dispatch(setWishlistPage({page}));
      };
    
    return {
        wishlist,
        totalCount, 
        loading,
        error,
        fetchWishlist,
        addToWishlist,
        removeFromWishlist,
        setPage,
        page,
        pageLoadingMessage: message
    };
};

export default useWishlist;