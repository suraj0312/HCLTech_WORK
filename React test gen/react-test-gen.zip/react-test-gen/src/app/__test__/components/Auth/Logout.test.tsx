import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import Logout from '../../../components/Auth/Logout';

// Create a reusable mock for logoutUser
const mockLogoutUser = jest.fn();

// Mock the useAuth hook to return the mocked logoutUser function
jest.mock('@hooks/useAuth', () => ({
  __esModule: true,
  default: () => ({
    logoutUser: mockLogoutUser,
  }),
}));

describe('Logout component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders a button with "Logout" text', () => {
    render(<Logout />);
    const button = screen.getByRole('button', { name: /logout/i });
    expect(button).toBeInTheDocument();
  });

  it('calls logoutUser when the button is clicked', () => {
    render(<Logout />);
    const button = screen.getByRole('button', { name: /logout/i });

    expect(mockLogoutUser).not.toHaveBeenCalled();
    fireEvent.click(button);
    expect(mockLogoutUser).toHaveBeenCalledTimes(1);
  });

  it('applies the provided className to the button', () => {
    const customClass = 'my-custom-class';
    render(<Logout className={customClass} />);
    const button = screen.getByRole('button', { name: /logout/i });
    expect(button).toHaveClass(customClass);
  });
});