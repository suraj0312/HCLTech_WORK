import '@testing-library/jest-dom';
import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

// System under test
import Login from '../../../components/Auth/Login';

// ─── Mock hooks and child components ──────────────────────────────────────────
/**
 * Mock for useAuth hook
 */
const loginUserMock = jest.fn();
jest.mock('@hooks/useAuth', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    loginUser: loginUserMock,
    loading: false,
    error: null,
  })),
}));

/**
 * Mock for Error component – just render the message so we can assert it
 */
jest.mock('@components/Common/Error', () => (props: { message: string }) => (
  <div data-testid="error">{props.message}</div>
));

/**
 * Mock for AuthForm component.
 *  – Renders two buttons so tests can decide what kind of data is sent to onSubmit
 *  – Still spreads other props (e.g. `type`) for completeness
 */
jest.mock('@components/Auth/AuthForm', () => (props: { onSubmit?: any; type: string }) => {
  const { onSubmit } = props;
  return (
    <div data-testid="auth-form">
      <button onClick={() => onSubmit && onSubmit({ username: 'john', password: 'doe' })}>
        submit-valid
      </button>
      <button onClick={() => onSubmit && onSubmit({ username: '', password: '' })}>
        submit-empty
      </button>
    </div>
  );
});

// ─── Tests ────────────────────────────────────────────────────────────────────
describe('Login Component', () => {
  const useAuthMock = require('@hooks/useAuth').default as jest.Mock;

  beforeEach(() => {
    jest.clearAllMocks();
    // default return for happy-path unless overridden in tests
    useAuthMock.mockReturnValue({
      loginUser: loginUserMock,
      loading: false,
      error: null,
    });
  });

  test('renders heading and AuthForm', () => {
    render(<Login />);

    expect(screen.getByRole('heading', { name: /login/i })).toBeInTheDocument();
    expect(screen.getByTestId('auth-form')).toBeInTheDocument();
    // No error messages by default
    expect(screen.queryByTestId('error')).not.toBeInTheDocument();
  });

  test('displays backend error from useAuth', () => {
    useAuthMock.mockReturnValue({
      loginUser: loginUserMock,
      loading: false,
      error: 'Something went wrong',
    });

    render(<Login />);

    expect(screen.getByTestId('error')).toHaveTextContent('Something went wrong');
  });

  test('shows validation error when required fields are empty', async () => {
    render(<Login />);

    // Trigger empty submit
    await userEvent.click(screen.getByRole('button', { name: /submit-empty/i }));

    expect(screen.getByTestId('error')).toHaveTextContent('Please fill out this field');
    expect(loginUserMock).not.toHaveBeenCalled();
  });

  test('calls loginUser with valid credentials when not loading', async () => {
    render(<Login />);

    await userEvent.click(screen.getByRole('button', { name: /submit-valid/i }));

    expect(loginUserMock).toHaveBeenCalledWith({ username: 'john', password: 'doe' });
  });

  test('does not submit when loading is true', async () => {
    useAuthMock.mockReturnValue({
      loginUser: loginUserMock,
      loading: true,
      error: null,
    });

    render(<Login />);

    // AuthForm receives onSubmit = null when loading is true, so click shouldn't do anything
    await userEvent.click(screen.getByRole('button', { name: /submit-valid/i }));
    expect(loginUserMock).not.toHaveBeenCalled();
  });
});