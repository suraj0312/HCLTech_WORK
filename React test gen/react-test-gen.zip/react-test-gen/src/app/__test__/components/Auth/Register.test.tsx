import '@testing-library/jest-dom';
import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Register from '../../../components/Auth/Register';
import useAuth from '@hooks/useAuth';

// Mock the custom hook
jest.mock('@hooks/useAuth', () => jest.fn());

// Mock the AuthForm component with proper onSubmit handling
jest.mock('@components/Auth/AuthForm', () => {
  // we need React in scope for JSX
  const React = require('react');

  return (props: any) => {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();

      if (props.onSubmit) {
        const form = e.currentTarget;
        const username =
          (form.elements.namedItem('username') as HTMLInputElement | null)
            ?.value ?? '';
        const password =
          (form.elements.namedItem('password') as HTMLInputElement | null)
            ?.value ?? '';

        props.onSubmit({ username, password });
      }
    };

    return (
      <form onSubmit={handleSubmit}>
        <label htmlFor="username">Username</label>
        <input id="username" name="username" />

        <label htmlFor="password">Password</label>
        <input id="password" name="password" type="password" />

        <button
          type="submit"
          // Disable when explicitly disabled OR loading OR there is no submit handler
          disabled={props.disabled || props.loading || !props.onSubmit}
        >
          Submit
        </button>
      </form>
    );
  };
});

// Utility to configure mock useAuth behavior
const setupMockUseAuth = (
  overrides: Partial<ReturnType<typeof useAuth>> = {}
) => ({
  registerUser: jest.fn(),
  isLoggedIn: false,
  loading: false,
  error: null,
  ...overrides,
});

describe('Register Component', () => {
  let mockUseAuth: jest.MockedFunction<typeof useAuth>;

  beforeEach(() => {
    mockUseAuth = useAuth as jest.MockedFunction<typeof useAuth>;
  });

  it('renders the Register component with initial state', () => {
    mockUseAuth.mockReturnValue(setupMockUseAuth());

    render(<Register />);

    expect(screen.getByText('Register')).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: /submit/i })
    ).toBeInTheDocument();
  });

  it('renders loading state when isLoggedIn is true', () => {
    mockUseAuth.mockReturnValue(setupMockUseAuth({ isLoggedIn: true }));

    render(<Register />);

    expect(screen.getByText(/loading/i)).toBeInTheDocument();
  });

  it('renders error when useAuth provides an error', () => {
    mockUseAuth.mockReturnValue(setupMockUseAuth({ error: 'Network error' }));

    render(<Register />);

    expect(screen.getByText(/network error/i)).toBeInTheDocument();
  });

  it('displays form error when fields are left empty', async () => {
    mockUseAuth.mockReturnValue(setupMockUseAuth());
    render(<Register />);

    const submitButton = screen.getByRole('button', { name: /submit/i });

    await userEvent.click(submitButton);

    expect(
      screen.getByText(/please fill out this field/i)
    ).toBeInTheDocument();
  });

  it('calls registerUser when valid data is submitted', async () => {
    const mockRegisterUser = jest.fn();
    mockUseAuth.mockReturnValue(
      setupMockUseAuth({ registerUser: mockRegisterUser })
    );

    render(<Register />);

    const usernameInput = screen.getByLabelText(/username/i);
    const passwordInput = screen.getByLabelText(/password/i);
    const submitButton = screen.getByRole('button', { name: /submit/i });

    await userEvent.type(usernameInput, 'testUser');
    await userEvent.type(passwordInput, '123456');
    await userEvent.click(submitButton);

    expect(mockRegisterUser).toHaveBeenCalledWith({
      username: 'testUser',
      password: '123456',
    });
  });

  it('disables form submission while loading', async () => {
    const mockRegisterUser = jest.fn();
    mockUseAuth.mockReturnValue(
      setupMockUseAuth({ registerUser: mockRegisterUser, loading: true })
    );

    render(<Register />);

    const submitButton = screen.getByRole('button', { name: /submit/i });

    // Verify the button is disabled when loading is true
    expect(submitButton).toBeDisabled();

    // Simulate clicking the button while the form is disabled
    await userEvent.click(submitButton);

    // Verify registerUser was not called
    expect(mockRegisterUser).not.toHaveBeenCalled();
  });
});