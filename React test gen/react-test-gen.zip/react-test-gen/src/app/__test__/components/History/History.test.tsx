import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import HistoryPage from '../../../components/History/History';
import * as usePurchaseHistoryHook from '../../../components/History/action/usePurchaseHistory';

jest.mock('../../../components/History/action/usePurchaseHistory');

describe('HistoryPage Component', () => {
    jest.setTimeout(10000); // Increase timeout for all tests in this suite

    it('renders Loading component when loading is true', () => {
        (usePurchaseHistoryHook.default as jest.Mock).mockReturnValue({
            loading: true,
            error: null,
            purchaseHistory: [],
            totalCount: 0,
        });

        render(<HistoryPage />);
        expect(screen.getByRole('status')).toBeInTheDocument(); // Assuming Loading component uses role="status"
    });

    it('renders Error component when error is not null', () => {
        (usePurchaseHistoryHook.default as jest.Mock).mockReturnValue({
            loading: false,
            error: 'An error occurred',
            purchaseHistory: [],
            totalCount: 0,
        });

        render(<HistoryPage />);
        expect(screen.getByText('An error occurred')).toBeInTheDocument();
    });

    it('renders TransactionTable component with purchaseHistory data when loading is false and error is null', () => {
        const mockPurchaseHistory = [{ id: 1, amount: 100 }, { id: 2, amount: 200 }];
        (usePurchaseHistoryHook.default as jest.Mock).mockReturnValue({
            loading: false,
            error: null,
            purchaseHistory: mockPurchaseHistory,
            totalCount: 2,
        });

        render(<HistoryPage />);
        expect(screen.getByRole('table')).toBeInTheDocument(); // Assuming TransactionTable renders a table
    });

    it('renders the title "Investment History"', () => {
        (usePurchaseHistoryHook.default as jest.Mock).mockReturnValue({
            loading: false,
            error: null,
            purchaseHistory: [],
            totalCount: 0,
        });

        render(<HistoryPage />);
        expect(screen.getByText('Investment History')).toBeInTheDocument();
    });
});