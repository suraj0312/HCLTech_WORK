import React from 'react';
import { render, screen, waitFor, act } from '@testing-library/react';
import '@testing-library/jest-dom';
import DashboardPage from '../../../components/Dashboard/Dashboard';
import * as useInvestmentModule from '@hooks/useInvestment';
import * as useWalletModule from '@hooks/useWallet';
import * as useWishlistModule from '@hooks/useWishlist';
import * as useDashboardActionsModule from '../../../components/Dashboard/action/useDashboardActions';
import config from '@config/config';

// Mock the styles to prevent CSS-related errors during testing
jest.mock('../../../components/Dashboard/Dashboard.module.css', () => ({
    dashboardContainer: 'dashboardContainer',
    header: 'header',
    title: 'title',
    sections: 'sections',
    section: 'section',
    sectionTitle: 'sectionTitle',
}));

jest.mock('../../../components/Common/Loading', () => {
    return {
        __esModule: true,
        default: ({ message }: { message: string }) => <div>Loading: {message}</div>,
    };
});

jest.mock('../../../components/Dashboard/Error', () => {
    return {
        __esModule: true,
        default: ({ message }: { message: string }) => <div>Error: {message}</div>,
    };
});

jest.mock('../../../components/Dashboard/InvestmentTable', () => {
    return {
        __esModule: true,
        default: ({ data, totalCount, currentPage, setPage, itemsPerPage, currency }: any) => (
            <div>
                InvestmentTable:
                <div>Data Length: {data.length}</div>
                <div>Total Count: {totalCount}</div>
                <div>Current Page: {currentPage}</div>
                <div>Items Per Page: {itemsPerPage}</div>
                <button onClick={() => setPage(currentPage + 1)}>Next Page</button>
            </div>
        ),
    };
});

jest.mock('../../../components/Dashboard/WalletDetails', () => {
    return {
        __esModule: true,
        default: ({ balance }: { balance: number }) => <div>WalletDetails: {balance}</div>,
    };
});

jest.mock('../../../components/Dashboard/WishlistTable', () => {
    return {
        __esModule: true,
        default: ({ data, totalCount, currentPage, setPage, itemsPerPage, currency }: any) => (
            <div>
                WishlistTable:
                <div>Data Length: {data.length}</div>
                <div>Total Count: {totalCount}</div>
                <div>Current Page: {currentPage}</div>
                <div>Items Per Page: {itemsPerPage}</div>
                <button onClick={() => setPage(currentPage + 1)}>Next Page</button>
            </div>
        ),
    };
});

describe('DashboardPage Component', () => {
    let mockUseInvestment: jest.SpyInstance;
    let mockUseWallet: jest.SpyInstance;
    let mockUseWishlist: jest.SpyInstance;
    let mockUseDashboardActions: jest.SpyInstance;

    beforeEach(() => {
        mockUseInvestment = jest.spyOn(useInvestmentModule, 'default');
        mockUseWallet = jest.spyOn(useWalletModule, 'default');
        mockUseWishlist = jest.spyOn(useWishlistModule, 'default');
        mockUseDashboardActions = jest.spyOn(useDashboardActionsModule, 'default');

        mockUseInvestment.mockReturnValue({ loading: false, error: null });
        mockUseWallet.mockReturnValue({ walletBalance: 1000, fetchWalletBalance: jest.fn(), loading: false, error: null });
        mockUseWishlist.mockReturnValue({ loading: false, error: null, pageLoadingMessage: null, page: 1 });
        mockUseDashboardActions.mockReturnValue({
            formAction: jest.fn(),
            investments: [{ id: 1, name: 'Investment 1' }],
            investmentTotalCount: 10,
            wishlist: [{ id: 1, name: 'Wishlist 1' }],
            wishlistTotalCount: 5,
        });
    });

    afterEach(() => {
        mockUseInvestment.mockRestore();
        mockUseWallet.mockRestore();
        mockUseWishlist.mockRestore();
        mockUseDashboardActions.mockRestore();
    });

    it('renders the dashboard with data', async () => {
        render(<DashboardPage />);

        // Check for title
        expect(screen.getByText('Dashboard')).toBeInTheDocument();

        // Check for InvestmentTable
        expect(screen.getByText('Investment List')).toBeInTheDocument();
        expect(screen.getByText('Data Length: 1')).toBeInTheDocument();
        expect(screen.getByText('Total Count: 10')).toBeInTheDocument();
        expect(screen.getByText('Current Page: 1')).toBeInTheDocument();
        expect(screen.getByText('Items Per Page: 5')).toBeInTheDocument(); // Ensure this value matches config

        // Check for WalletDetails
        expect(screen.getByText('Wallet Details')).toBeInTheDocument();
        expect(screen.getByText('WalletDetails: 1000')).toBeInTheDocument();

        // Check for WishlistTable
        expect(screen.getByText('Wishlist')).toBeInTheDocument();
        expect(screen.getByText('Data Length: 1')).toBeInTheDocument();
        expect(screen.getByText('Total Count: 5')).toBeInTheDocument();
        expect(screen.getByText('Current Page: 1')).toBeInTheDocument();
        expect(screen.getByText('Items Per Page: 3')).toBeInTheDocument(); // Ensure this value matches config
    });

    it('displays loading messages when loading is true', async () => {
        mockUseInvestment.mockReturnValue({ loading: true, error: null });
        mockUseWallet.mockReturnValue({ walletBalance: 0, fetchWalletBalance: jest.fn(), loading: true, error: null });
        mockUseWishlist.mockReturnValue({ loading: true, error: null, pageLoadingMessage: 'Custom wishlist loading message', page: 1 });
        mockUseDashboardActions.mockReturnValue({
            formAction: jest.fn(),
            investments: [],
            investmentTotalCount: 0,
            wishlist: [],
            wishlistTotalCount: 0,
        });

        render(<DashboardPage />);

        expect(screen.getByText('Loading: Investment List is loading')).toBeInTheDocument();
        expect(screen.getByText('Loading: Wallet Details is loading')).toBeInTheDocument();
        expect(screen.getByText('Loading: Custom wishlist loading message')).toBeInTheDocument();
    });

    it('displays error messages when errors occur', async () => {
        mockUseInvestment.mockReturnValue({ loading: false, error: 'Investment Error' });
        mockUseWallet.mockReturnValue({ walletBalance: 0, fetchWalletBalance: jest.fn(), loading: false, error: 'Wallet Error' });
        mockUseWishlist.mockReturnValue({ loading: false, error: 'Wishlist Error', pageLoadingMessage: null, page: 1 });
        mockUseDashboardActions.mockReturnValue({
            formAction: jest.fn(),
            investments: [],
            investmentTotalCount: 0,
            wishlist: [],
            wishlistTotalCount: 0,
        });

        render(<DashboardPage />);

        expect(screen.getByText('Error: Investment Error')).toBeInTheDocument();
        expect(screen.getByText('Error: Wallet Error')).toBeInTheDocument();
        expect(screen.getByText('Error: Wishlist Error')).toBeInTheDocument();
    });

    it('calls setPage for investments when next page button is clicked in InvestmentTable', async () => {
        const setInvestmentPageMock = jest.fn();
        mockUseDashboardActions.mockReturnValue({
            formAction: jest.fn(),
            investments: [{ id: 1, name: 'Investment 1' }],
            investmentTotalCount: 10,
            wishlist: [{ id: 1, name: 'Wishlist 1' }],
            wishlistTotalCount: 5,
        });

        render(<DashboardPage />);

        act(() => {
            screen.getByText('Next Page').click();
        });
    });

    it('calls setPage for wishlist when next page button is clicked in WishlistTable', async () => {
         const setWishlistPageMock = jest.fn();
        mockUseDashboardActions.mockReturnValue({
            formAction: jest.fn(),
            investments: [{ id: 1, name: 'Investment 1' }],
            investmentTotalCount: 10,
            wishlist: [{ id: 1, name: 'Wishlist 1' }],
            wishlistTotalCount: 5,
        });

        render(<DashboardPage />);

        act(() => {
            screen.getAllByText('Next Page')[1].click();
        });
    });
});