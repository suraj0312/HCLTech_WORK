'use client';
import React, {useEffect} from 'react';
import Register from '@components/Auth/Register';
import withAuth from '@context/withAuth';
import {useRouter} from 'next/navigation';
import useAuth from '@hooks/useAuth';
import { useFormStatus } from 'react-dom';

const RegisterPage: React.FC = () => {
    const {isLoggedIn, loading} = useAuth();
    const router = useRouter();
    const { pending } = useFormStatus();

    useEffect(() => {
        if (isLoggedIn && !loading && !pending) {
          router.push('/dashboard');
        }
      }, [isLoggedIn, loading, pending, router]);
    
    return <Register key={'register'}/>;
};

export default withAuth(RegisterPage, true);
