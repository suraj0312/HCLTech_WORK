'use client';

import React from 'react';
import Login from '@components/Auth/Login';
import Loading from '@components/Common/Loading';
import withAuth from '@context/withAuth';
import useLoginNavigation from './action/useLoginNavigation';
import { useFormStatus } from 'react-dom';

const LoginPage: React.FC = () => {
    const state = useLoginNavigation();
    const { pending } = useFormStatus();

    if (state.isLoggedIn == null || pending) {
        return <Loading message='Loading page' />;
      }
    
    if (state.isLoggedIn) {
        return null;
    }
    return (
        <Login key='login' />
    );
};

export default React.memo(withAuth(LoginPage, true));