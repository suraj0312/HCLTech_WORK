import { useEffect, useActionState, startTransition } from 'react';
import { useRouter } from 'next/navigation';
import useAuth from '@hooks/useAuth';

interface State {
    hasNavigated: boolean;
    isLoggedIn?: boolean | null;
}

interface Action {
    type: string;
}

const useLoginNavigation = () => {
    const { isLoggedIn } = useAuth();
    const router = useRouter();

    const [state, formAction] = useActionState<State, Action>(async (prevState, { type }) => {
        if (type === 'navigate' && isLoggedIn) {
            router.push('/dashboard');
            return { ...prevState, hasNavigated: true, isLoggedIn };
        }
        return { ...prevState, isLoggedIn };
    }, { hasNavigated: false, isLoggedIn: null });

    useEffect(() => {
        if (isLoggedIn !== null) {
            startTransition(() => {
                formAction({ type: 'navigate' });
            });
        }
        console.log('login rendered', isLoggedIn);
    }, [isLoggedIn, formAction]);

    return state;
};

export default useLoginNavigation;