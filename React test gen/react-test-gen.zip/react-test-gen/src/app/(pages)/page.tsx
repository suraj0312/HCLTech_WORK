'use client';
import Index from './index/index';

const HomePage = () => {
    console.log('Index component mounted')
    return (
        <Index/>
    );
};

export default HomePage;
