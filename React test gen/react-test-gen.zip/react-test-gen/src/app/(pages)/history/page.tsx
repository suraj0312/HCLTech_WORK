'use client';
import React from 'react';
import withAuth from '@context/withAuth';
import History from "@components/History/History";


const HistoryPage: React.FC = () => {

    return (
        <History/>
    );
};

export default withAuth(React.memo(HistoryPage));
