'use client';
import React from 'react';

const HistoryError: React.FC = () => {
    return <div>Error loading history. Please try again later.</div>;
};

export default HistoryError;