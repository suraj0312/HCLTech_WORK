'use client';
import React, { useEffect, useRef, useState } from 'react';
import useInvestment from '@hooks/useInvestment';
import Loading from '@components/Common/Loading';
import Error from '@components/Common/Error';
import styles from '@styles/MFDetailsPage.module.css';
import useAuth from '@hooks/useAuth';
import { useRouter } from "next/navigation";
import { LoginPortal } from "@pages/investments/LoginPortal";

type Params = {
    id: string;
}

interface InvestmentDetailsPageProps {
    params: Params;
}   

const InvestmentDetailsPage: React.FC<InvestmentDetailsPageProps> = ({ params }) => {
    const [id, setId] = useState<string | null>(null);
    const { fetchInvestmentDetails, investmentDetails, loading, error, purchaseInvestment, purchaseSuccess } = useInvestment();
    const { isLoggedIn } = useAuth();
    const [showLogin, setShowLogin] = useState(false);
    const router = useRouter();
    const hasFetchedDetails = useRef(false);

    useEffect(() => {
        const unwrapParams = async () => {
            const unwrappedParams = await params;
            setId(unwrappedParams.id);
        };
        unwrapParams();
    }, [params]);

    useEffect(() => {
        if (id && !hasFetchedDetails.current) {
            fetchInvestmentDetails(id);
            hasFetchedDetails.current = true;
        }
    }, [id]);
    useEffect(() => {
        if (purchaseSuccess && !loading && !error) {
            console.log('Redirecting to /history');
            router.push('/history');
        }
    }, [purchaseSuccess, loading, error, router]);

    const handlePurchase = () => {
        if (id) {
            purchaseInvestment(id);
        }
    };

    // console.log(error)
    if (loading) return <Loading />;
    // if (error) return <Error message={error}/>;
    if (!investmentDetails) {
        return <Error message="Investment details not found." />;
    }

    return (
        <div key='investment-page'>
            <main className={styles.container}>
                <h1>{investmentDetails.name}</h1>
                <table className={styles.table}>
                    <tbody>
                        <tr>
                            <td>Amount</td>
                            <td>{investmentDetails.amount}</td>
                        </tr>
                        <tr>
                            <td colSpan={2} style={{ textAlign: 'center' }}>Details</td>
                        </tr>
                        {Object.entries(investmentDetails).map(([key, value]) =>
                            typeof value === 'string' && value.trim() && (
                                <tr key={key}>
                                    <td colSpan={2} style={{ textAlign: 'center' }}>{value}</td>
                                </tr>
                            )
                        )}

                    </tbody>
                </table>
                {isLoggedIn ? (
                    <>{error && <Error message={error} />}
                        {purchaseSuccess && <p className={styles.successMessage}>{'Purchase successful!'}</p>}

                        <button className={styles.button} onClick={handlePurchase}>
                            Purchase
                        </button>
                    </>
                ) : (
                    <>{error && <Error message={error} />}
                        <button className={styles.button} onClick={() => setShowLogin(true)}>
                            Login
                        </button> </>
                )}
            </main>
            {(!isLoggedIn && showLogin) && (
                <LoginPortal setShowLogin={setShowLogin} />
            )}
        </div>
    );
};

export default InvestmentDetailsPage;
