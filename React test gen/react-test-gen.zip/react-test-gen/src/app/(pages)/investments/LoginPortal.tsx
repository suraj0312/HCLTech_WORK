import styles from "@styles/MFDetailsPage.module.css";
import Login from "@components/Auth/Login";
import React from "react";
import Button from "@_components/Button";

interface LoginPortalProps {
    setShowLogin: (show: boolean) => void;
}

export const LoginPortal: React.FC<LoginPortalProps> = ({ setShowLogin }) => {

    return (
        <div className={styles.popup}>
            <div className={styles.popupContent}>
                <Button className={styles.closeButton} onClick={() => setShowLogin(false)}>X</Button>
                <Login/>
            </div>
        </div>
    )
}