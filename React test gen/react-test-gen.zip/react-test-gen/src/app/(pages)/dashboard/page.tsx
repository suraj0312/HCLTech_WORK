'use client';

import React, { Suspense, lazy } from 'react';
import withAuth from '@context/withAuth';

const Dashboard = lazy(() => import('@components/Dashboard/Dashboard'));

const DashboardPage: React.FC = () => {
  return (
    <Suspense fallback={<div>Loading Dashboard component...</div>}>
      <Dashboard key='dashboard' />
    </Suspense>
  );
};

export default withAuth(DashboardPage);