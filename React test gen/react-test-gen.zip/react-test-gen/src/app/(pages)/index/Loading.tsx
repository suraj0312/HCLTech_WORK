'use client';
import React from 'react';

const IndexLoading: React.FC = () => {
    return <div>Loading page...</div>;
};

export default IndexLoading;