'use client';
import React from 'react';

const IndexError: React.FC = () => {
    return <div>Error loading page. Please try again later.</div>;
};

export default IndexError;