'use client';
import React from 'react';
import Login from "@pages/(auth)/login/page";

const HomePage: React.FC = () => {
    return (
        <div key='default-login'>
            <Login/>
        </div>
    );
};

export default HomePage;
