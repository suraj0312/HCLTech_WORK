'use client';

import React, { Suspense, lazy } from 'react';
import { NextPage, NextPageContext } from 'next';

const ErrorContent = lazy(() => import('./ErrorContent'));

interface ErrorPageProps {
  statusCode: number;
}

const ErrorPage: NextPage<ErrorPageProps> = ({ statusCode }) => {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ErrorContent statusCode={statusCode} />
    </Suspense>
  );
};

ErrorPage.getInitialProps = ({ res, err }: NextPageContext) => {
  const statusCode = res ? res.statusCode : err ? err.statusCode : 404;
  return { statusCode: statusCode ?? 404 };
};

export default ErrorPage;