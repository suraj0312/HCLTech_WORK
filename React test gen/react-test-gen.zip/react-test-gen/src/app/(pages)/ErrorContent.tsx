'use client';

import React from 'react';

interface ErrorContentProps {
  statusCode: number;
}

const ErrorContent: React.FC<ErrorContentProps> = ({ statusCode }) => {
  return (
    <div>
      <h1>{statusCode ? `An error ${statusCode} occurred on server` : 'An error occurred on client'}</h1>
      <p>Please try again later.</p>
    </div>
  );
};

export default ErrorContent;
