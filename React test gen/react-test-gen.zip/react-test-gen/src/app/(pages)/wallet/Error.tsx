'use client';
import React from 'react';

const WalletError: React.FC = () => {
    return <div>Error loading wallet. Please try again later.</div>;
};

export default WalletError;