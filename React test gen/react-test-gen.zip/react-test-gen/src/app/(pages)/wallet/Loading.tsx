'use client';
import React from 'react';

const WalletLoading: React.FC = () => {
    return <div>Loading wallet...</div>;
};

export default WalletLoading;