'use client';
import React from 'react';
import Wishlist from '@components/Wishlist/Wishlist';
import withAuth from '@context/withAuth';

const WishlistPage: React.FC = () => {
    return <Wishlist/>;
};

export default withAuth(React.memo(WishlistPage));