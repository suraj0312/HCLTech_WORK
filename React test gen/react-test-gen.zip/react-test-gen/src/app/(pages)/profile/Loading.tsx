'use client';
import React from 'react';

const ProfileLoading: React.FC = () => {
    return <div>Loading profile...</div>;
};

export default ProfileLoading;