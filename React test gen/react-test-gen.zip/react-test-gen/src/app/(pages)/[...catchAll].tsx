'use client';
import React from 'react';
import {useRouter, useSearchParams} from 'next/navigation';

const CatchAll: React.FC = () => {
    const router = useRouter();
    const searchParams = useSearchParams();
    const catchAll = searchParams?.get('catchAll');

    return (
        <div>
            <h1>Page Not Found</h1>
            <p>No page found in app dir for: {catchAll}</p>
        </div>
    );
};

export default CatchAll;