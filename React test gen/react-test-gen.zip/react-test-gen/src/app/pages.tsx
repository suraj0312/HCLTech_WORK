// 'use client';

// import React, {useEffect} from 'react';
// import {usePathname, useRouter} from 'next/navigation';
// import {AppProps} from 'next/app';

// const Home: React.FC<AppProps> = ({Component, pageProps}) => {
//     useRouter();
//     const pathname = usePathname();

//     useEffect(() => {
//         console.log('Home component mounted');
//     }, [pathname]);

//     console.log(pathname);

//     return <Component {...pageProps} />;
// };

// export default Home;