import {call, put, takeEvery} from 'redux-saga/effects';
import {PayloadAction} from '@reduxjs/toolkit';
import {
    fetchInvestmentDetailsFailure,
    fetchInvestmentDetailsStart,
    fetchInvestmentDetailsSuccess,
    fetchInvestmentFailure,
    fetchInvestmentStart,
    fetchInvestmentSuccess,
    fetchPurchaseHistoryFailure,
    fetchPurchaseHistoryStart,
    fetchPurchaseHistorySuccess,
    purchaseInvestmentFailure,
    purchaseInvestmentStart,
    purchaseInvestmentSuccess,
} from '../actions/investmentActions';
import {
    fetchInvestmentDetails,
    fetchInvestment,
    fetchPurchaseHistory,
    purchaseInvestment,
} from '@services/investmentService';
import {Investment} from "@_types/Investment";

function* fetchInvestmentSaga(action: PayloadAction<{ page: number; limit: number }>) {
    try {
        //console.log('started')

        const {investments, totalCount} = yield call(fetchInvestment, action.payload.page, action.payload.limit);
      //console.log('done', investments,totalCount)
        yield put(fetchInvestmentSuccess({investments, totalCount}));
    } catch (error) {
        yield put(fetchInvestmentFailure((error as Error).message));
    }
}

function* fetchInvestmentDetailsSaga(action: PayloadAction<string>): Generator {
    try {
        const investmentDetails = yield call(fetchInvestmentDetails, action.payload);
        yield put(fetchInvestmentDetailsSuccess(investmentDetails));
    } catch (error) {
        yield put(fetchInvestmentDetailsFailure((error as Error).message));
    }
}

function* purchaseInvestmentSaga(action: PayloadAction<string>): Generator {
    try {
        const investment: Investment = yield call(purchaseInvestment, action.payload);
        yield put(purchaseInvestmentSuccess(investment));
    } catch (error) {
        yield put(purchaseInvestmentFailure((error as Error).message));
    }
}

function* fetchPurchaseHistorySaga(): Generator {
    try {
        const purchaseHistory = yield call(fetchPurchaseHistory);
        yield put(fetchPurchaseHistorySuccess(purchaseHistory));
    } catch (error) {
        yield put(fetchPurchaseHistoryFailure((error as Error).message));
    }
}

export default function* watchInvestmentSaga() {
    yield takeEvery(fetchInvestmentStart.type, fetchInvestmentSaga);
    yield takeEvery(fetchInvestmentDetailsStart.type, fetchInvestmentDetailsSaga);
    yield takeEvery(purchaseInvestmentStart.type, purchaseInvestmentSaga);
    yield takeEvery(fetchPurchaseHistoryStart.type, fetchPurchaseHistorySaga);

}
