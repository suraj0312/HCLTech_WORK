import {call, put, takeEvery} from 'redux-saga/effects';
import {PayloadAction} from '@reduxjs/toolkit';
import {
    checkAuthStateFailure,
    checkAuthStateStart,
    checkAuthStateSuccess,
    fetchAuthStateFailure,
    fetchAuthStateStart,
    fetchAuthStateSuccess,
    loginFailure,
    loginStart,
    loginSuccess,
    logoutStart,
    logoutSuccess,
    registerAuthStart,
    registerStart
} from '@saga-operations/actions/authActions';
import {checkAuthState, loginUser, logoutUser, registerUser} from '@services/authService';

interface AuthPayload {
    username: string;
    password: string;
}

function* loginUserSaga(action: PayloadAction<AuthPayload>): Generator {
    try {
        const user = yield call(loginUser, action.payload.username, action.payload.password);
        localStorage.setItem('authToken', user.token);
        yield put(loginSuccess(user));
    } catch (error) {
        yield put(loginFailure((error as Error).message));
    }
}

function* registerUserSaga(action: PayloadAction<AuthPayload>): Generator {
    try {
        yield put(registerAuthStart());
        const user = yield call(registerUser, action.payload.username, action.payload.password);
        localStorage.setItem('authToken', user.token);
        yield put(loginSuccess(user));
        //console.log('ye')
    } catch (error) {
        //console.log((error as Error).message)
        yield put(loginFailure((error as Error).message));
    }
}

function* logoutUserSaga(): Generator {
    try {
        const success = yield call(logoutUser);
        if (success) {
            yield put(logoutSuccess());
        }
    } catch (error) {
        yield put(loginFailure((error as Error).message));
        console.error('Error logging out:', error);
    }
}


function* fetchAuthStateSaga(): Generator {
    try {
        const isLoggedIn = yield call(checkAuthState);
        yield put(fetchAuthStateSuccess(isLoggedIn));
    } catch (error) {
        yield put(fetchAuthStateFailure((error as Error).message));
    }
}
function* checkAuthStateSaga(): Generator {
    try {
      const isLoggedIn = yield call(checkAuthState);
      yield put(checkAuthStateSuccess(isLoggedIn));
    } catch (error) {
      yield put(checkAuthStateFailure((error as Error).message));
    }
  }
  
export default function* authSaga() {
    yield takeEvery(loginStart.type, loginUserSaga);
    yield takeEvery(registerStart.type, registerUserSaga);
    yield takeEvery(logoutStart.type, logoutUserSaga);
    yield takeEvery(fetchAuthStateStart.type, fetchAuthStateSaga);
    yield takeEvery(checkAuthStateStart.type, checkAuthStateSaga);

}