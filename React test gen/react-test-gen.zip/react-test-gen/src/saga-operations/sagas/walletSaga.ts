import {call, put, takeEvery} from 'redux-saga/effects';
import {PayloadAction} from '@reduxjs/toolkit';
import {
    addBalance,
    fetchBalanceFailure,
    fetchBalanceStart,
    fetchBalanceSuccess,
    withdrawBalance
} from '../actions/walletActions';
import {fetchWalletBalance, updateWalletBalance} from '@services/walletService';

function* fetchWalletBalanceSaga(): Generator {
    try {
        const balance = yield call(fetchWalletBalance);
        yield put(fetchBalanceSuccess(balance));
    } catch (error) {
        yield put(fetchBalanceFailure((error as Error).message));
    }
}

function* addBalanceSaga({ payload }: PayloadAction<number>): Generator {
    try {
        const balance = yield call(updateWalletBalance, payload, 'deposit');
        yield put(fetchBalanceSuccess(balance));
    } catch (error) {
        yield put(fetchBalanceFailure((error as Error).message));
    }
}

function* withdrawBalanceSaga({ payload }: PayloadAction<number>): Generator {
    try {
        const balance = yield call(updateWalletBalance, payload, 'withdraw');
        console.log(balance)
        // yield put(fetchBalanceSuccess(balance));
    } catch (error) {
        console.log(payload)
        yield put(fetchBalanceFailure((error as Error).message));
    }
}

export default function* walletSaga() {
    yield takeEvery(fetchBalanceStart.type, fetchWalletBalanceSaga);
    yield takeEvery(addBalance.type, addBalanceSaga);
    yield takeEvery(withdrawBalance.type, withdrawBalanceSaga);
}
