import {call, put, takeEvery} from 'redux-saga/effects';
import {PayloadAction} from '@reduxjs/toolkit';
import {
    addToWishlistStart,
    addToWishlistSuccess,
    fetchWishlistFailure,
    fetchWishlistStart,
    fetchWishlistSuccess,
    removeFromWishlistStart,
    removeFromWishlistSuccess,
    setWishlistPage,
} from '../actions/wishlistActions';
import {
    addToWishlist as addWishlistItem,
    fetchWishlist,
    removeFromWishlist as removeWishlistItem,
    updateWishlistCache
} from '@services/wishlistService';
import {WishlistItem,Payload,RemovedItem,WishlistResponse} from '@_types/WishlistItem';
import { updateInvestmentWishlistStatus } from '@saga-operations/actions/investmentActions';
 

function* fetchWishlistSaga({ payload }: PayloadAction<{ page: number; limit: number }>) {
    try {
      let { wishlist, totalCount }: { wishlist: WishlistItem[]; totalCount: number } = yield call(fetchWishlist, payload.page, payload.limit);
  
        yield put(fetchWishlistSuccess({ wishlist, totalCount }));
      
    } catch (error) {
      yield put(fetchWishlistFailure((error as Error).message));
    }
  }

function* addToWishlistSaga({ payload }: PayloadAction<{ id: string }>): Generator {
    try {
        const {wishlistItem, totalCount} = yield call(addWishlistItem, {id: payload.id});
        yield call(updateWishlistCache, wishlistItem, 'add',undefined, totalCount);
        yield put(addToWishlistSuccess(wishlistItem));
        yield put(updateInvestmentWishlistStatus({ id: payload.id, isInWishlist: true }));
    } catch (error) {
        yield put(fetchWishlistFailure((error as Error).message));
    }
}

function* removeFromWishlistSaga({ payload }: PayloadAction<Payload>): Generator {
  try {
    const { removedItem, nextItem, totalCount }: WishlistResponse = yield call(removeWishlistItem, payload.id, payload.limit, payload.pageNumber);
    const { id, investment_id = null }: RemovedItem = removedItem;

    if (totalCount === 0) {
      // console.log('Total count is 0');
      yield put(setWishlistPage({ page: 1, message: 'Your wishlist is empty' }));
      yield put(fetchWishlistSuccess({ wishlist: [], totalCount: 0 }));
    } else {
      const newPageNumber = determineNewPageNumber(payload, nextItem, totalCount);
      // console.log('New page number determined:', newPageNumber);
      
      if (payload.pageNumber !== newPageNumber) {
        // console.log('Page number changed from', payload.pageNumber, 'to', newPageNumber);
        yield put(setWishlistPage({ page: newPageNumber, message: `Page number reduced to ${newPageNumber} due to insufficient items` }));
        const fetchedWishlist = yield call(fetchWishlist, newPageNumber, payload.limit);
        // console.log('Fetched wishlist for new page number:', fetchedWishlist);
        yield put(fetchWishlistSuccess(fetchedWishlist));
      } else {
        // console.log('Removing item from wishlist:', id);
        const nextItemData = getNextItem(payload, totalCount, nextItem);
        // console.log('Next item data:', nextItemData);
        yield put(removeFromWishlistSuccess({ id, nextItem: nextItemData, totalCount }));
      }
    }

    yield put(updateInvestmentWishlistStatus({ id, investment_id: investment_id ?? undefined, isInWishlist: false }));
  } catch (error: any) {
    yield put(updateInvestmentWishlistStatus({ id: payload.id, isInWishlist: false }));
    yield put(fetchWishlistFailure((error as Error).message));
  }
}

// Helper functions
function determineNewPageNumber(payload: Payload, nextItem: any | null, totalCount: number): number {
  return nextItem === null && totalCount <= (payload.pageNumber - 1) * payload.limit && payload.wishListpageNumber !== 1
    ? Math.max(payload.pageNumber - 1, 1)
    : payload.pageNumber;
}

function getNextItem(payload: Payload, totalCount: number, nextItem: any | null): any | null {
  return nextItem;
  return payload.wishListpageNumber === 1 && totalCount === payload.limit ? null : nextItem;
}


export default function* watchWishlistSaga() {
    yield takeEvery(fetchWishlistStart.type, fetchWishlistSaga);
    yield takeEvery(addToWishlistStart.type, addToWishlistSaga);
    yield takeEvery(removeFromWishlistStart.type, removeFromWishlistSaga);
}
