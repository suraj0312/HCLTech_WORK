import {combineReducers} from '@reduxjs/toolkit';
import authReducer from '../reducers/authReducer';
import walletReducer from '../reducers/walletReducer';
import wishlistReducer from '../reducers/wishlistReducer';
import searchReducer from '../reducers/searchReducer';
import investmentReducer from '../reducers/investmentReducer';

const rootReducer = combineReducers({
    auth: authReducer,
    wallet: walletReducer,
    wishlist: wishlistReducer,
    search: searchReducer,
    investment: investmentReducer,

});

export default rootReducer;
