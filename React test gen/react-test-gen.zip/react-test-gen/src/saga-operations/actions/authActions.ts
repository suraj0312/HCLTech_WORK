import {createAction} from '@reduxjs/toolkit';

interface AuthPayload {
    username: string;
    password: string;
}

export const loginStart = createAction<AuthPayload>('auth/loginStart');
export const loginSuccess = createAction('auth/loginSuccess');
export const loginFailure = createAction<string>('auth/loginFailure');
export const logoutStart = createAction('auth/logoutStart');
export const registerStart = createAction<AuthPayload>('auth/registerStart');
export const registerAuthStart = createAction('auth/registerAuthStart');
export const fetchAuthStateStart = createAction('auth/fetchAuthStateStart');
export const fetchAuthStateSuccess = createAction<boolean>('auth/fetchAuthStateSuccess');
export const fetchAuthStateFailure = createAction<string>('auth/fetchAuthStateFailure');
export const logoutSuccess = createAction('auth/logoutSuccess');

export const checkAuthStateStart = createAction('auth/checkAuthStateStart');
export const checkAuthStateSuccess = createAction<boolean>('auth/checkAuthStateSuccess');
export const checkAuthStateFailure = createAction<string>('auth/checkAuthStateFailure');