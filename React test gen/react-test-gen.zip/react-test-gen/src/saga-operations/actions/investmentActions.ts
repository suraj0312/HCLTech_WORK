import {createAction} from '@reduxjs/toolkit';
import {Investment, InvestmentDetails, Transaction} from '@_types/Investment';

export const fetchInvestmentStart = createAction<{
    page: number;
    limit: number
}>('investment/fetchInvestmentStart');
export const fetchInvestmentSuccess = createAction<{
    investments: Investment[];
    totalCount: number
}>('investment/fetchInvestmentSuccess');
export const fetchInvestmentFailure = createAction<string>('investment/fetchInvestmentFailure');

export const fetchInvestmentDetailsStart = createAction<string>('investment/fetchInvestmentDetailsStart');
export const fetchInvestmentDetailsSuccess = createAction<InvestmentDetails>('investment/fetchInvestmentDetailsSuccess');
export const fetchInvestmentDetailsFailure = createAction<string>('investment/fetchInvestmentDetailsFailure');

export const purchaseInvestmentStart = createAction<string>('investment/purchaseInvestmentStart');
export const purchaseInvestmentSuccess = createAction<Investment>('investment/purchaseInvestmentSuccess');
export const purchaseInvestmentFailure = createAction<string>('investment/purchaseInvestmentFailure');

export const fetchPurchaseHistoryStart = createAction('investment/fetchPurchaseHistoryStart');
export const fetchPurchaseHistorySuccess = createAction<Transaction[]>('investment/fetchPurchaseHistorySuccess');
export const fetchPurchaseHistoryFailure = createAction<string>('investment/fetchPurchaseHistoryFailure');
export const updateInvestmentWishlistStatus = createAction<{id:string, investment_id?:string, isInWishlist:boolean}>('investment/updateInvestmentWishlistStatus');
