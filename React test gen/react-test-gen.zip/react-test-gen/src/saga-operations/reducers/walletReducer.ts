import {createSlice, PayloadAction} from '@reduxjs/toolkit';

interface WalletState {
    walletBalance: number;
    loading: boolean;
    error: string | null;
}

const initialState: WalletState = {
    walletBalance: 0,
    loading: false,
    error: null,
};

const walletSlice = createSlice({
    name: 'wallet',
    initialState,
    reducers: {
        fetchBalanceStart(state) {
            //console.log('fetchBalanceStart action dispatched');
            state.loading = true;
            state.error = null;
        },
        fetchBalanceSuccess(state, action: PayloadAction<number>) {
            //console.log('fetchBalanceSuccess action dispatched', JSON.stringify(action.payload, null, "\t"));
            state.walletBalance = action.payload;
            state.loading = false;
        },
        fetchBalanceFailure(state, action: PayloadAction<string>) {
            //console.log('fetchBalanceFailure action dispatched', JSON.stringify(action.payload, null, "\t"));
            state.loading = false;
            state.error = action.payload;
        },
        addBalance(state, action: PayloadAction<number>) {
            //console.log('addBalance action dispatched', JSON.stringify(action.payload, null, "\t"));
            state.walletBalance += action.payload;
        },
        withdrawBalance(state, action: PayloadAction<number>) {
            //console.log('withdrawBalance action dispatched', JSON.stringify(action.payload, null, "\t"));
           
            if (state.walletBalance <= 0 || state.walletBalance < action.payload) {
                state.error = 'Insufficient balance';
            } else {
                state.walletBalance -= action.payload;
                state.error = null; 
            }

        },
    },
});

export const {
    fetchBalanceStart,
    fetchBalanceSuccess,
    fetchBalanceFailure,
    addBalance,
    withdrawBalance,
} = walletSlice.actions;

export default walletSlice.reducer;