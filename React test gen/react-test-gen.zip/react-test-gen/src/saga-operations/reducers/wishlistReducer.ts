import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { WishlistItem } from '@_types/WishlistItem';
import config from '@config/config';
const MAX_WISHLIST_ITEMS = config.wishlist.itemPerPage;

interface WishlistState {
    items: WishlistItem[];
    totalCount: number;
    loading: boolean;
    error: string | null;
    page: number;
    message: string | null;
}

const initialState: WishlistState = {
    items: [],
    totalCount: 0,
    loading: false,
    error: null,
    page: 1,
    message: null, 
};

const wishlistSlice = createSlice({
    name: 'wishlist',
    initialState,
    reducers: {
        fetchWishlistStart(state) {
            //console.log('fetchWishlistStart action dispatched');
            state.loading = true;
            state.error = null;
            state.message = null;
        },
        fetchWishlistSuccess(state, { payload }: PayloadAction<{ wishlist: WishlistItem[]; totalCount: number }>) {
            //console.log('fetchWishlistSuccess action dispatched', payload);
            state.items = payload.wishlist;
            state.totalCount = payload.totalCount;
            state.loading = false;
            state.message = null;
        },
        fetchWishlistFailure(state, { payload }: PayloadAction<string>) {
            //console.log('fetchWishlistFailure action dispatched', payload);
            state.loading = false;
            state.error = payload;
            state.message = null;
        },
        addToWishlistStart(state) {
            //console.log('addToWishlistStart action dispatched');
            state.loading = true;
            state.error = null;
            state.message = null;
        },
        addToWishlistSuccess(state, { payload }: PayloadAction<WishlistItem>) {
            //console.log('addToWishlistSuccess action dispatched', payload);
            state.items = [...state.items, payload];
            state.totalCount += 1;

            // Check if the number of items exceeds the items per page
            if (state.items.length > MAX_WISHLIST_ITEMS) {
                state.items = state.items.slice(0, MAX_WISHLIST_ITEMS);
            }

            state.loading = false;
            state.message = null;
        },
        addToWishlistFailure(state, { payload }: PayloadAction<string>) {
            //console.log('addToWishlistFailure action dispatched', payload);
            state.loading = false;
            state.error = payload;
            state.message = null;
        },
        removeFromWishlistStart(state) {
            //console.log('removeFromWishlistStart action dispatched');
            state.loading = true;
            state.error = null;
            state.message = null;
        },
        removeFromWishlistSuccess(state, { payload: { id, nextItem, totalCount, message } }: PayloadAction<{ id: string; nextItem?: WishlistItem; totalCount: number; message?: string }>) {
            //console.log('removeFromWishlistSuccess action dispatched', { id, nextItem, totalCount });
            state.items = state.items.filter(item => {
                const investmentId = item.investment_id || id;  
                return item.id !== id && investmentId !== id;
                            });
              
             if (nextItem) {
                state.items = [...state.items.filter(item => item.id !== nextItem.id), nextItem];
            }

            state.totalCount = totalCount;
            state.loading = false;
            state.message = null;
        },
        removeFromWishlistFailure(state, { payload }: PayloadAction<string>) {
            //console.log('removeFromWishlistFailure action dispatched', payload);
            state.loading = false;
            state.error = payload;
            state.message = null;
        },
        setWishlistPage(state, { payload:{page,message} }: PayloadAction<{ page: number; message?: string }>) { 
            state.page = page;
            state.message = message ?? null;
          },
      
    },
});

export const {
    fetchWishlistStart,
    fetchWishlistSuccess,
    fetchWishlistFailure,
    addToWishlistStart,
    addToWishlistSuccess,
    addToWishlistFailure,
    removeFromWishlistStart,
    removeFromWishlistSuccess,
    removeFromWishlistFailure,
    setWishlistPage
} = wishlistSlice.actions;

export default wishlistSlice.reducer;
    