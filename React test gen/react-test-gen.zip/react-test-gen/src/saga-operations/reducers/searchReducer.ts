import {createSlice, PayloadAction} from '@reduxjs/toolkit';
import {SearchResult} from '@_types/Investment';

interface SearchState {
    results: SearchResult[];
    loading: boolean;
    error: string | null;
}

const initialState: SearchState = {
    results: [],
    loading: false,
    error: null,
};

const searchSlice = createSlice({
    name: 'search',
    initialState,
    reducers: {
        searchInvestmentsStart(state) {
            //console.log('searchInvestmentsStart action dispatched');
            state.loading = true;
            state.error = null;
        },
        searchInvestmentsSuccess(state, action: PayloadAction<SearchResult[]>) {
            //console.log('searchInvestmentsSuccess action dispatched');
            state.results = action.payload;
            state.loading = false;
        },
        searchInvestmentsFailure(state, action: PayloadAction<string>) {
            //console.log('searchInvestmentsFailure action dispatched');
            state.loading = false;
            state.error = action.payload;
        },
    },
});

export const {
    searchInvestmentsStart,
    searchInvestmentsSuccess,
    searchInvestmentsFailure,
} = searchSlice.actions;

export default searchSlice.reducer;
