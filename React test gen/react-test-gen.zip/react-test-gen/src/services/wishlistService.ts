import client from '@utils/apolloClient';
import {gql} from '@apollo/client';
import { WishlistItem } from '@_types/WishlistItem';
import { updateInvestmentCache } from './investmentService';

const FETCH_WISHLIST = gql`
    query FetchWishlist($page: Int, $limit: Int) {
        wishlist(page: $page, limit: $limit) {
            wishlist {
                id
                investment_id
                name
                amount
                current_value
            }
            totalCount
        }
    }
`;


const REMOVE_FROM_WISHLIST = gql`
  mutation RemoveFromWishlist($id: ID!, $limit: Int!, $pageNumber: Int!) {
    removeFromWishlist(id: $id, limit: $limit, pageNumber: $pageNumber) {
      removedItem {
        id
        name
        amount
        investment_id
      }
      nextItem {
        id
        name
        amount
        current_value
        investment_id
      }
      totalCount
    }
  }
`;

const ADD_TO_WISHLIST_MUTATION = gql`
  mutation AddToWishlist($id: ID!) {
    addToWishlist(id: $id) {
      wishlistItem {
        id
        name
        current_value
        amount
        investment_id
      }
      totalCount
    }
  }
`;
export const fetchWishlist = async (page: number, limit: number) => {

    const {data} = await client.query({
        query: FETCH_WISHLIST,
        variables: {page, limit},
        fetchPolicy: 'no-cache',
    });
    console.log(data.wishlist)
    return data.wishlist;
};


export const addToWishlist = async ({id}: { id: string }) => {
    const {data} = await client.mutate({
        mutation: ADD_TO_WISHLIST_MUTATION,
        variables: {id},
        fetchPolicy: 'no-cache',
    });
    // await updateInvestmentCache(data.addToWishlist, 'add');

    return data.addToWishlist;
};

export const removeFromWishlist = async (id: string, limit: number, pageNumber: number) => {
  console.log({id, limit, pageNumber})
  const {data} = await client.mutate({
        mutation: REMOVE_FROM_WISHLIST,
        variables: {id, limit, pageNumber},
        fetchPolicy: 'no-cache',
    });
    // await updateInvestmentCache(data.removeFromWishlist, 'remove', id);

    return data.removeFromWishlist;
};

export const updateWishlistCache = async (item: WishlistItem, actionType: 'add' | 'remove', removedItemId?: string, totalCount?: number): Promise<void> => {
    try {
      console.log('Updating cache...');
      console.log('Action Type:', actionType);
      console.log('Item:', item);
      console.log('Removed Item ID:', removedItemId);
      console.log('Total Count:', totalCount);
  

      client.cache.modify({
        fields: {
          wishlist(existingWishlistRefs: ReadonlyArray<any> = [], { readField }) {
            console.log('Existing Wishlist Refs:', existingWishlistRefs);
  
            if (actionType === 'add') {
              const newItemRef = client.cache.writeFragment({
                data: item,
                fragment: gql`
                  fragment NewWishlistItem on WishlistItem {
                    id
                    name
                    current_value
                    amount
                  }
                `,
              });
              console.log('New Item Ref:', newItemRef);
              return [...existingWishlistRefs, newItemRef];
            } else if (actionType === 'remove' && removedItemId) {
              const updatedWishlistRefs = existingWishlistRefs.filter(
                (wishlistRef: any) => removedItemId !== readField('id', wishlistRef)
              );
              console.log('Updated Wishlist Refs:', updatedWishlistRefs);
              return updatedWishlistRefs;
            }
          },
          totalCount(existingTotalCount = 0) {
            console.log('Existing Total Count:', existingTotalCount);
            return totalCount ?? existingTotalCount;
          },
        },
      });
  
      console.log('Cache updated successfully.');
    } catch (error) {
      console.log('Error updating wishlist cache:', error);
    }
  };