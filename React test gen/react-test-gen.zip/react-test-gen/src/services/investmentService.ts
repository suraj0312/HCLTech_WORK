import client from '@utils/apolloClient';
import {gql} from '@apollo/client';
import {Investment} from '@_types/Investment';

const FETCH_INVESTMENT = gql`
    query FetchInvestment($page: Int, $limit: Int) {
        investments(page: $page, limit: $limit) {
            investments {
                id
                name
                amount
                isInWishlist
            }
            totalCount
        }
    }
`;

const FETCH_INVESTMENT_DETAILS = gql`
    query FetchInvestmentDetails($id: ID!) {
        getInvestment(id: $id) {
            id
            name
            amount
        }
    }
`;

const PURCHASE_INVESTMENT = gql`
    mutation PurchaseInvestment($id: ID!) {
        purchaseInvestment(id: $id) {
            id
            name
            amount
            
        }
    }
`;
export const PURCHASE_HISTORY = gql`
    query PurchaseHistory {
        purchaseHistory {
            id
            type
            amount
            date
            current_value
            investment_id
        }
    }
`;
export const fetchPurchaseHistory = async () => {
    const {data} = await client.query({
        query: PURCHASE_HISTORY,
        fetchPolicy: 'no-cache',

    });
    return data.purchaseHistory;
};

export const fetchInvestment = async (page: number, limit: number) => {
    const {data} = await client.query({
        query: FETCH_INVESTMENT,
        variables: {page, limit},
        fetchPolicy: 'no-cache',
        // fetchPolicy: 'cache-first',
    });
    return data.investments;
};

export const fetchInvestmentDetails = async (id: string): Promise<Investment> => {
    const {data} = await client.query({
        query: FETCH_INVESTMENT_DETAILS,
        variables: {id},
    });
    return data.getInvestment;
};

export const purchaseInvestment = async (id: string) => {
    const {data} = await client.mutate({
        mutation: PURCHASE_INVESTMENT,
        variables: {id},
        fetchPolicy: 'no-cache',
    });
    return data.purchaseInvestment;
};

export const updateInvestmentCache = async (
    item: Investment,
    actionType: 'add' | 'remove',
    removedItemId?: string,
    totalCount?: number
  ): Promise<void> => {
    try {
      console.log('Updating cache...');
      console.log('Action Type:', actionType);
      console.log('Item:', item);
      console.log('Removed Item ID:', removedItemId);
      console.log('Total Count:', totalCount);
  
      client.cache.modify({
        fields: {
          investments(existingInvestmentRefs = { investments: [], totalCount: 0 }, { readField }) {
            console.log('Existing Investment Refs:', existingInvestmentRefs);
  
            let updatedInvestments = existingInvestmentRefs.investments;
  
            if (actionType === 'add') {
              const newItemRef = client.cache.writeFragment({
                data: { ...item, isInWishlist: true },
                fragment: gql`
                  fragment NewInvestmentItem on Investment {
                    id
                    name
                    amount
                    isInWishlist
                  }
                `,
              });
              console.log('New Item Ref:', newItemRef);
              updatedInvestments = [...updatedInvestments, newItemRef];
            } else if (actionType === 'remove' && removedItemId) {
              updatedInvestments = updatedInvestments.map((investmentRef: any) =>
                removedItemId === readField('id', investmentRef)
                  ? { ...investmentRef, isInWishlist: false }
                  : investmentRef
              );
              console.log('Updated Investment Refs:', updatedInvestments);
            }
  
            return {
              ...existingInvestmentRefs,
              investments: updatedInvestments,
              totalCount: totalCount ?? existingInvestmentRefs.totalCount,
            };
          },
        },
      });
  
      console.log('Cache updated successfully.');
    } catch (error) {
      console.log('Error updating investment cache:', error);
    }
  };  