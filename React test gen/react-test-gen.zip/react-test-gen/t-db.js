const express = require('express');
const path = require('path');
const fs = require('fs');
const initSqlJs = require('sql.js');

const app = express();
const PORT = 3000;

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname)));

app.get('/data', async (req, res) => {
  try {
    const SQL = await initSqlJs();
    const dbFilePath = path.join(__dirname, 'database.db');
    const fileBuffer = fs.readFileSync(dbFilePath);
    const db = new SQL.Database(new Uint8Array(fileBuffer));

    const queries = {
      users: 'SELECT * FROM users',
      investments: 'SELECT * FROM investments',
      wishlist: 'SELECT * FROM wishlist',
      transactions: 'SELECT * FROM transactions'
    };

    const results = {};

    for (const [key, query] of Object.entries(queries)) {
        const result = db.exec(query);
        if (result.length > 0) {
          results[key] = result[0].values.map(row => {
            const record = {};
            result[0].columns.forEach((col, index) => {
              record[col] = row[index];
            });
            return record;
          });
        } else {
          results[key] = [];
        }
      }
      
    db.close();
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});