import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { configureStore, EnhancedStore } from '@reduxjs/toolkit';
import rootReducer from '@saga-operations/store/rootReducer';
import WishlistPage from '@pages/wishlist/page';
import useAuth from '@hooks/useAuth';
import useWishlist from '@hooks/useWishlist';

jest.mock('@hooks/useAuth');
jest.mock('@hooks/useWishlist');

const mockUseAuth = useAuth as jest.MockedFunction<typeof useAuth>;
const mockUseWishlist = useWishlist as jest.MockedFunction<typeof useWishlist>;

const createTestStore = (): EnhancedStore => {
  return configureStore({
    reducer: rootReducer,
  });
};

describe('Wishlist Page', () => {
  let store: EnhancedStore;

  beforeEach(() => {
    jest.clearAllMocks();
    store = createTestStore();
  });

  it('renders the Wishlist page', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: true,
      loginUser: jest.fn(),
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    mockUseWishlist.mockReturnValue({
      wishlist: [],
      totalCount: 0,
      fetchWishlist: jest.fn(),
      addToWishlist: jest.fn(),
      removeFromWishlist: jest.fn(),
      loading: false,
      error: null,
      page: 1,
      setPage: jest.fn(),
      pageLoadingMessage: null,
    });

    render(
      <Provider store={store}>
        <WishlistPage />
      </Provider>
    );

    await waitFor(() => expect(screen.getByText('Wishlist')).toBeInTheDocument());
  });

  it('displays loading indicator', async () => {
    mockUseWishlist.mockReturnValueOnce({
      wishlist: [],
      totalCount: 0,
      fetchWishlist: jest.fn(),
      addToWishlist: jest.fn(),
      removeFromWishlist: jest.fn(),
      loading: true,
      error: null,
      page: 1,
      setPage: jest.fn(),
      pageLoadingMessage: 'Wishlist is loading',
    });

    render(
      <Provider store={store}>
        <WishlistPage />
      </Provider>
    );

    expect(screen.getByText('Wishlist is loading')).toBeInTheDocument();
  });

  it('displays error message', async () => {
    const errorMessage = 'Error occurred';
    mockUseWishlist.mockReturnValueOnce({
      wishlist: [],
      totalCount: 0,
      fetchWishlist: jest.fn(),
      addToWishlist: jest.fn(),
      removeFromWishlist: jest.fn(),
      loading: false,
      error: errorMessage,
      page: 1,
      setPage: jest.fn(),
      pageLoadingMessage: null,
    });

    render(
      <Provider store={store}>
        <WishlistPage />
      </Provider>
    );

    expect(screen.getByText(errorMessage)).toBeInTheDocument();
  });

  it('handles add to wishlist', async () => {
    const mockAddToWishlist = jest.fn();
    mockUseWishlist.mockReturnValue({
      wishlist: [],
      totalCount: 0,
      fetchWishlist: jest.fn(),
      addToWishlist: mockAddToWishlist,
      removeFromWishlist: jest.fn(),
      loading: false,
      error: null,
      page: 1,
      setPage: jest.fn(),
      pageLoadingMessage: null,
    });

    render(
      <Provider store={store}>
        <WishlistPage />
      </Provider>
    );

    fireEvent.click(screen.getByText('Add to Wishlist'));

    await waitFor(() => expect(mockAddToWishlist).toHaveBeenCalled());
  });

  it('handles remove from wishlist', async () => {
    const mockRemoveFromWishlist = jest.fn();
    mockUseWishlist.mockReturnValue({
      wishlist: [{ id: '1', name: 'Test Item', amount: 100, current_value: 100, investment_id: '1' }],
      totalCount: 1,
      fetchWishlist: jest.fn(),
      addToWishlist: jest.fn(),
      removeFromWishlist: mockRemoveFromWishlist,
      loading: false,
      error: null,
      page: 1,
      setPage: jest.fn(),
      pageLoadingMessage: null,
    });

    render(
      <Provider store={store}>
        <WishlistPage />
      </Provider>
    );

    fireEvent.click(screen.getByText('Remove'));

    await waitFor(() => expect(mockRemoveFromWishlist).toHaveBeenCalled());
  });
});