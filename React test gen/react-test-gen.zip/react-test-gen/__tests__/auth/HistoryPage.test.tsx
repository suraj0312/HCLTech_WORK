import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { configureStore, EnhancedStore } from '@reduxjs/toolkit';
import rootReducer from '@saga-operations/store/rootReducer';
import HistoryPage from '@pages/history/page';
import useAuth from '@hooks/useAuth';
import usePurchaseHistory from '@components/History/action/usePurchaseHistory';

jest.mock('@hooks/useAuth');
jest.mock('@components/History/action/usePurchaseHistory');

const mockUseAuth = useAuth as jest.MockedFunction<typeof useAuth>;
const mockUsePurchaseHistory = usePurchaseHistory as jest.MockedFunction<typeof usePurchaseHistory>;

const createTestStore = (): EnhancedStore => {
  return configureStore({
    reducer: rootReducer,
  });
};

describe('History Page', () => {
  let store: EnhancedStore;

  beforeEach(() => {
    jest.clearAllMocks();
    store = createTestStore();
  });

  it('renders the History page', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: true,
      loginUser: jest.fn(),
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    mockUsePurchaseHistory.mockReturnValue({
      totalCount: 0,
      purchaseHistory: [],
      loading: false,
      error: null,
    });

    render(
      <Provider store={store}>
        <HistoryPage />
      </Provider>
    );

    await waitFor(() => expect(screen.getByText('Investment History')).toBeInTheDocument());
  });

  it('displays loading indicator', async () => {
    mockUsePurchaseHistory.mockReturnValueOnce({
      totalCount: 0,
      purchaseHistory: [],
      loading: true,
      error: null,
    });

    render(
      <Provider store={store}>
        <HistoryPage />
      </Provider>
    );

    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('displays error message', async () => {
    const errorMessage = 'Error occurred';
    mockUsePurchaseHistory.mockReturnValueOnce({
      totalCount: 0,
      purchaseHistory: [],
      loading: false,
      error: errorMessage,
    });

    render(
      <Provider store={store}>
        <HistoryPage />
      </Provider>
    );

    expect(screen.getByText(errorMessage)).toBeInTheDocument();
  });
});