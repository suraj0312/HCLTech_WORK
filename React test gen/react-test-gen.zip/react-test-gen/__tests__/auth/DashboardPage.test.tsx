import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { configureStore, EnhancedStore } from '@reduxjs/toolkit';
import rootReducer from '@saga-operations/store/rootReducer';
import DashboardPage from '@pages/dashboard/page';
import useAuth from '@hooks/useAuth';
import useInvestment from '@hooks/useInvestment';
import useWallet from '@hooks/useWallet';
import useWishlist from '@hooks/useWishlist';
import { useRouter, usePathname } from 'next/navigation';

jest.mock('@hooks/useAuth');
jest.mock('@hooks/useInvestment');
jest.mock('@hooks/useWallet');
jest.mock('@hooks/useWishlist');
jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
  usePathname: jest.fn(),
}));

const mockUseAuth = useAuth as jest.MockedFunction<typeof useAuth>;
const mockUseInvestment = useInvestment as jest.MockedFunction<typeof useInvestment>;
const mockUseWallet = useWallet as jest.MockedFunction<typeof useWallet>;
const mockUseWishlist = useWishlist as jest.MockedFunction<typeof useWishlist>;

const createTestStore = (): EnhancedStore => {
  return configureStore({
    reducer: rootReducer,
  });
};

describe('Dashboard Page', () => {
  let store: EnhancedStore;
  const mockRouter = {
    push: jest.fn(),
    replace: jest.fn(),
    prefetch: jest.fn(),
    route: '/',
    pathname: '',
    query: {},
    asPath: '',
  };

  beforeEach(() => {
    jest.clearAllMocks();
    store = createTestStore();
    (useRouter as jest.Mock).mockReturnValue(mockRouter);
    (usePathname as jest.Mock).mockReturnValue('/');
    mockUseAuth.mockReturnValue({
      isLoggedIn: true,
      loginUser: jest.fn(),
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });
    mockUseInvestment.mockReturnValue({
      investments: [],
      totalCount: 0,
      investmentDetails: null,
      purchaseHistory: [],
      fetchInvestment: jest.fn(),
      fetchInvestmentDetails: jest.fn(),
      purchaseInvestment: jest.fn(),
      fetchPurchaseHistory: jest.fn(),
      loading: false,
      error: null,
      purchaseSuccess: false,
    });
    mockUseWallet.mockReturnValue({
      walletBalance: 0,
      fetchWalletBalance: jest.fn(),
      addBalance: jest.fn(),
      withdrawBalance: jest.fn(),
      loading: false,
      error: null,
    });
    mockUseWishlist.mockReturnValue({
      wishlist: [],
      totalCount: 0,
      fetchWishlist: jest.fn(),
      addToWishlist: jest.fn(),
      removeFromWishlist: jest.fn(),
      loading: false,
      error: null,
      page: 1,
      setPage: jest.fn(),
      pageLoadingMessage: null,
    });

    localStorage.setItem('authToken', 'testAuthToken');
  });

  afterEach(() => {
    localStorage.clear();
  });

  it('renders the Dashboard page', async () => {
    render(
      <Provider store={store}>
        <DashboardPage />
      </Provider>
    );

    await waitFor(() => expect(screen.queryByText('Loading...')).not.toBeInTheDocument());
    await waitFor(() => expect(screen.getByText('Dashboard')).toBeInTheDocument());
  });

  it('displays loading indicators', async () => {
    mockUseInvestment.mockReturnValueOnce({
      investments: [],
      totalCount: 0,
      investmentDetails: null,
      purchaseHistory: [],
      fetchInvestment: jest.fn(),
      fetchInvestmentDetails: jest.fn(),
      purchaseInvestment: jest.fn(),
      fetchPurchaseHistory: jest.fn(),
      loading: true,
      error: null,
      purchaseSuccess: false,
    });

    mockUseWallet.mockReturnValueOnce({
      walletBalance: 0,
      fetchWalletBalance: jest.fn(),
      addBalance: jest.fn(),
      withdrawBalance: jest.fn(),
      loading: true,
      error: null,
    });

    mockUseWishlist.mockReturnValueOnce({
      wishlist: [],
      totalCount: 0,
      fetchWishlist: jest.fn(),
      addToWishlist: jest.fn(),
      removeFromWishlist: jest.fn(),
      loading: true,
      error: null,
      page: 1,
      setPage: jest.fn(),
      pageLoadingMessage: 'Loading wishlist...',
    });

    render(
      <Provider store={store}>
        <DashboardPage />
      </Provider>
    );

    await waitFor(() => expect(screen.getByText((content, element) => element?.textContent === 'Investment List is loading')).toBeInTheDocument());
    await waitFor(() => expect(screen.getByText((content, element) => element?.textContent === 'Wallet Details is loading')).toBeInTheDocument());
    await waitFor(() => expect(screen.getByText((content, element) => element?.textContent === 'Loading wishlist...')).toBeInTheDocument());
  });

  it('handles investment page change', async () => {
    render(
      <Provider store={store}>
        <DashboardPage />
      </Provider>
    );

    fireEvent.click(screen.getByText((content, element) => element?.textContent === '2'));

    await waitFor(() => expect(mockUseInvestment().fetchInvestment).toHaveBeenCalledWith(2, 2));
  });

  it('handles wishlist page change', async () => {
    render(
      <Provider store={store}>
        <DashboardPage />
      </Provider>
    );

    fireEvent.click(screen.getByText((content, element) => element?.textContent === '2'));

    await waitFor(() => expect(mockUseWishlist().fetchWishlist).toHaveBeenCalledWith(2, 2));
  });

  it('displays error messages', async () => {
    const errorMessage = 'Error occurred';
    mockUseInvestment.mockReturnValueOnce({
      investments: [],
      totalCount: 0,
      investmentDetails: null,
      purchaseHistory: [],
      fetchInvestment: jest.fn(),
      fetchInvestmentDetails: jest.fn(),
      purchaseInvestment: jest.fn(),
      fetchPurchaseHistory: jest.fn(),
      loading: false,
      error: errorMessage,
      purchaseSuccess: false,
    });

    mockUseWallet.mockReturnValueOnce({
      walletBalance: 0,
      fetchWalletBalance: jest.fn(),
      addBalance: jest.fn(),
      withdrawBalance: jest.fn(),
      loading: false,
      error: errorMessage,
    });

    mockUseWishlist.mockReturnValueOnce({
      wishlist: [],
      totalCount: 0,
      fetchWishlist: jest.fn(),
      addToWishlist: jest.fn(),
      removeFromWishlist: jest.fn(),
      loading: false,
      error: errorMessage,
      page: 1,
      setPage: jest.fn(),
      pageLoadingMessage: null,
    });

    render(
      <Provider store={store}>
        <DashboardPage />
      </Provider>
    );

    await waitFor(() => expect(screen.queryByText('Loading...')).not.toBeInTheDocument());
    expect(screen.getByText(errorMessage)).toBeInTheDocument();
  });
});