import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { configureStore, EnhancedStore } from '@reduxjs/toolkit';
import rootReducer from '@saga-operations/store/rootReducer';
import WalletPage from '@pages/wallet/page';
import useAuth from '@hooks/useAuth';
import useWallet from '@hooks/useWallet';

jest.mock('@hooks/useAuth');
jest.mock('@hooks/useWallet');

const mockUseAuth = useAuth as jest.MockedFunction<typeof useAuth>;
const mockUseWallet = useWallet as jest.MockedFunction<typeof useWallet>;

const createTestStore = (): EnhancedStore => {
  return configureStore({
    reducer: rootReducer,
  });
};

describe('Wallet Page', () => {
  let store: EnhancedStore;

  beforeEach(() => {
    jest.clearAllMocks();
    store = createTestStore();
  });

  it('renders the Wallet page', async () => {
    mockUseAuth.mockReturnValue({
      isLoggedIn: true,
      loginUser: jest.fn(),
      registerUser: jest.fn(),
      logoutUser: jest.fn(),
      loading: false,
      error: null,
      hasNavigated: false,
    });

    mockUseWallet.mockReturnValue({
      walletBalance: 0,
      fetchWalletBalance: jest.fn(),
      addBalance: jest.fn(),
      withdrawBalance: jest.fn(),
      loading: false,
      error: null,
    });

    render(
      <Provider store={store}>
        <WalletPage />
      </Provider>
    );

    await waitFor(() => expect(screen.getByText('Wallet')).toBeInTheDocument());
  });

  it('displays loading indicator', async () => {
    mockUseWallet.mockReturnValueOnce({
      walletBalance: 0,
      fetchWalletBalance: jest.fn(),
      addBalance: jest.fn(),
      withdrawBalance: jest.fn(),
      loading: true,
      error: null,
    });

    render(
      <Provider store={store}>
        <WalletPage />
      </Provider>
    );

    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('displays error message', async () => {
    const errorMessage = 'Error occurred';
    mockUseWallet.mockReturnValueOnce({
      walletBalance: 0,
      fetchWalletBalance: jest.fn(),
      addBalance: jest.fn(),
      withdrawBalance: jest.fn(),
      loading: false,
      error: errorMessage,
    });

    render(
      <Provider store={store}>
        <WalletPage />
      </Provider>
    );

    expect(screen.getByText(errorMessage)).toBeInTheDocument();
  });

  it('handles add balance', async () => {
    const mockAddBalance = jest.fn();
    mockUseWallet.mockReturnValue({
      walletBalance: 0,
      fetchWalletBalance: jest.fn(),
      addBalance: mockAddBalance,
      withdrawBalance: jest.fn(),
      loading: false,
      error: null,
    });

    render(
      <Provider store={store}>
        <WalletPage />
      </Provider>
    );

    fireEvent.click(screen.getByText('Add Balance'));

    await waitFor(() => expect(mockAddBalance).toHaveBeenCalled());
  });

  it('handles withdraw balance', async () => {
    const mockWithdrawBalance = jest.fn();
    mockUseWallet.mockReturnValue({
      walletBalance: 100,
      fetchWalletBalance: jest.fn(),
      addBalance: jest.fn(),
      withdrawBalance: mockWithdrawBalance,
      loading: false,
      error: null,
    });

    render(
      <Provider store={store}>
        <WalletPage />
      </Provider>
    );

    fireEvent.click(screen.getByText('Withdraw Balance'));

    await waitFor(() => expect(mockWithdrawBalance).toHaveBeenCalled());
  });
});