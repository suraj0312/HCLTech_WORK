This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.


UI Flows--	 
 	 
Header-- Home, Profile (show only when user is logged in) else show option to login/Register, Dashboard (Loged in user) , Logout (show only when user is logged in), Wallet	 
Register/login--- If User is verified then send to --- Dashboard	 
Dashboard	Investment details (table with rows clickable), wallet details (Remaining Balance, click here (href) to navigate Wallet page ), wishlist with current value (table with rows clickable)
Home- Search box with 3 character filter- display search result in Home page only	 
List of MF based on search criteria on click of single entry (anchor) user will be navigated to MF Details Page	 
MF page- Table of particular MF details with 2 buttons- Purchase, my MF details	 
Purchase-	If user is not logged in- Send user to Login screen with Register button in it.
 	If logged in then then show purchase history/buy option.
My Investment-	If user is not logged in- Send user to Login screen with Register button in it. then show below page as per logged in status
 	If Logged in- Show the result of already purchased history for the particular MF.
 	 
 	 
Wallet Page- will display only if we get an insufficient balance error while transaction from Mf page.	Button to Add Balance, withdraw Balance

tell me u understood or not Frontend
Frontend (FE):
Actions:

purchaseInvestmentStart, purchaseInvestmentSuccess, purchaseInvestmentFailure
File: saga-operations/actions/investmentActions.ts
Saga:

purchaseInvestmentSaga
File: saga-operations/sagas/investmentSaga.ts
Reducer:

Handle purchase actions
File: saga-operations/reducers/investmentReducer.ts
Hook:

purchaseInvestment
File: app/hooks/useInvestment.ts
Component:

Handle purchase action in InvestmentDetailsPage
File: app/pages/investments/[id]/page.tsx
Backend (BE):
Schema:

Define purchaseInvestment mutation
File: backend/modules/investments/investmentSchema.ts
Resolvers:

Implement purchaseInvestment resolver
File: backend/modules/investments/investmentResolvers.ts
Service:

Add purchaseInvestment function to call the GraphQL mutation
File: services/investmentService.ts

app/(pages)/(auth)/login/page.tsx	- Consolidate Loading component.
- Optimize useEffect to avoid unnecessary re-renders.
app/(pages)/(auth)/register/page.tsx	- Consolidate Loading component.
- Optimize useEffect to avoid unnecessary re-renders.
app/(pages)/dashboard/page.tsx	- Consolidate Loading and Error components.
- Optimize data fetching with batching and caching.
- Use memoization for state updates.
app/(pages)/history/page.tsx	- Consolidate Loading and Error components.
- Optimize data fetching and use memoization.
app/(pages)/home/page.tsx	- Consolidate Loading and Error components.
- Optimize search logic with debounce.
app/(pages)/investments/[id]/page.tsx	- Consolidate Loading and Error components.
- Optimize data fetching and use memoization.
app/(pages)/profile/page.tsx	- Consolidate Loading and Error components.
- Optimize data fetching and use memoization.
app/(pages)/wallet/page.tsx	- Consolidate Loading and Error components.
- Optimize data fetching and use memoization.
app/(pages)/wishlist/page.tsx	- Consolidate Loading and Error components.
- Optimize data fetching and use memoization.
app/components/Auth/AuthForm.tsx	- Merge Login and Register forms into a single component with a prop to switch modes.
app/components/Common/*	- Consolidate Error, Loading, Navbar, Pagination components.
- Use dynamic imports if necessary.
app/components/Dashboard/*	- Optimize data fetching with batching and caching.
- Consolidate similar components and use memoization.
app/components/History/*	- Consolidate similar components and optimize for client-side rendering.
app/components/Layout/*	- Ensure efficient layout rendering and use dynamic imports if necessary.
app/components/Search/*	- Optimize search logic with debounce.
app/components/Wallet/*	- Consolidate similar components and optimize for client-side rendering.
app/components/Wishlist/*	- Consolidate similar components and optimize for client-side rendering.
app/context/withAuth.tsx	- Optimize state management and use memoization to avoid unnecessary re-renders.
app/hooks/*	- Optimize data fetching with batching and caching.
- Use memoization to avoid unnecessary re-renders.
app/layout.tsx	- Optimize layout rendering and use dynamic imports if necessary.
app/pages.tsx	- Optimize component rendering and use dynamic imports if necessary.
app/utils/apolloClient.ts	- Optimize Apollo Client setup with batching and caching.
backend/lib/*	- Optimize with batching and caching.
- Use ES6+ features like const, let, arrow functions, and template literals.
backend/middleware/verifyToken.ts	- Optimize token verification logic.
- Use ES6+ features.
backend/modules/*	- Optimize resolvers with batching and caching.
- Use dataloader for efficient data fetching.
- Use ES6+ features.
config/config.ts	- Ensure optimized configuration settings.
pages/api/graphql.ts	- Optimize Apollo Server setup with batching and caching.
- Use ES6+ features.
saga-operations/actions/*	- Consolidate similar actions and optimize action creators.
- Use ES6+ features.
saga-operations/reducers/*	- Consolidate similar reducers and optimize state management.
- Use ES6+ features.
saga-operations/sagas/*	- Optimize with batching and caching.
- Use dataloader for efficient data fetching.
- Use ES6+ features.
saga-operations/store/*	- Optimize store configuration and use middleware for efficient state management.
- Use ES6+ features.
services/*	- Optimize data fetching with batching and caching.
- Use dataloader for efficient data fetching.
- Use ES6+ features.