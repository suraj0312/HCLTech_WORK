import re
import asyncio
import logging
from pathlib import Path
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.teams import RoundRobinGroupChat, MagenticOneGroupChat
from autogen_agentchat.conditions import MaxMessageTermination, TextMentionTermination
from autogen_ext.models.ollama import OllamaChatCompletionClient
from autogen_core.tools import FunctionTool
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient, OpenAIChatCompletionClient
import subprocess

# Set up logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

def file_reader(file_path: str) -> str:
    """Reads file and returns content"""
    try:
        test_code = Path(file_path).read_text(encoding='utf-8')
        return test_code
    except Exception as e:
        logger.error(f"Error reading file {file_path}: {e}")
        return ""

code_reader = FunctionTool(file_reader, name="code_reader", description="Read code from the file.")

def file_writer(file_path: str, file_content: str):
    """Writes file_content into the file"""
    try:
        Path(file_path).write_text(file_content)
        logger.info(f"Successfully wrote to file {file_path}")
    except Exception as e:
        logger.error(f"Error writing to file {file_path}: {e}")

code_writer = FunctionTool(file_writer, name="code_writer", description="Write or update code in the file.")

# ToolExecutor to replace subprocess calls
def jest_executer(test_file: str) -> dict:
    """Runs a specified test file and returns the output"""
    try:
        output = subprocess.getoutput(f"npm test -- --watchAll=false {test_file}")
        return output
    except Exception as e:
        return f"Error running test file: {str(e)}"

test_runner = FunctionTool(jest_executer, name="test_runner", description="Runs test file and returns output.")

def extract_js_code(text: str) -> str:
    pattern = pattern = r"```(?:js|jsx|tsx|javascript|typescript)\s+(.*?)```"
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
    if match:
        return match.group(1).strip()
    match_fallback = re.search(r"```\\s*\n(.*?)\n```", text, re.DOTALL)
    if match_fallback:
        return match_fallback.group(1).strip()
    return None

# Initialize OllamaChatCompletionClient for LLM communication
model_client_qc = OllamaChatCompletionClient(model="qwen2.5-coder:14b", temprature=0.4)
from autogen_core.models import ModelFamily
#model_client = OllamaChatCompletionClient(model="codestral:22b", model_info={
#        "vision": False,
#        "function_calling": True,
#        "json_output": True,
#        "family": ModelFamily.ANY,
#        "structured_output": True,
#    })

#model_client_qr = AzureOpenAIChatCompletionClient(
#    azure_deployment="gpt-4o",
#    model="o4-mini",
#    api_version="2024-05-01-preview",
#    azure_endpoint="https://x-generative-ai.openai.azure.com/",
#    api_key="3aded81a5c834dbfb1a9470022ef8cb3", # For key-based authentication.
#)

#model_client_qr = OpenAIChatCompletionClient(
#    model="gemini-2.0-flash",
#    api_key="AIzaSyA4kLSO3v0WI1bIsN4L6RItLBL7oTGzFM4",
#    temperature=0.4
#)

model_client_qr = OllamaChatCompletionClient(model="qwen2.5-coder:32b")

# Define the agents
tester = AssistantAgent(
    name="Tester",
    description= "Write the unit test cases for the Next.js component.",
    model_client=model_client_qc,
    system_message="""
You are a proficient coder. You write unit test case code for Next.js component using Jest framework and React Testing Library.
Work with the reviewer to improve your code.

Note:
- Never import '@testing-library/jest-dom/extend-expect' library.
- Always put all finished code in a single Markdown code block.
"""
)

reviewer = AssistantAgent(
    name="Reviewer",
    description= "Review the unit test cases written by test case writer",
    model_client=model_client_qc,
    system_message="""
You are a code reviewer. You critically review all test condition for correctness and provide feedback. 
. 
Respond with 'APPROVE' only when all your feedbacks are addressed.
    """
)

executer = AssistantAgent(
    name="Executer",
    reflect_on_tool_use=True,
    model_client=model_client_qc,
    description= "Runs test file, analyse the test result and suggest precise changes to fix the failing test cases.",
    system_message="""
    - Run the test file and collect the results.
    - If all tests pass, respond with: "APPROVE"
    - If any tests fail:
        - Clearly identify which test cases failed identify likely root causes.
        - Suggest precise changes to fix the failing test cases (but do NOT modify any code).

    Your output will be passed to a fixing agent. Make sure your guidance is concise, accurate, and clearly actionable.
    """,
    tools=[test_runner],
)

fixer = AssistantAgent(
    name="Fixer",
    reflect_on_tool_use=True,
    model_client=model_client_qc,
    description="Fix failing test cases as reported by the test case executor.",
    system_message="""
Your task is to fix the test cases that have failed as reported by the test case executor.

Follow these steps:
2. Identify and address the failing test cases based on the executor's output.
3. Modify only the necessary parts of the test code to resolve the issues.
4. Ensure the overall structure and intent of the tests are preserved.
5. Save the updated test code back to the file on disk.

Note: 
- Avoid modifying the structure or logic of the test case unless necessary to make it pass.
- Ensure all fixes are precise and do not alter the original behavior of the tests unless explicitly required.
    """,
    tools=[code_writer],
)

# Generate tests for a single component
async def generate_test(component_code: str, component_path: str, test_path: Path) -> None:
    logger.info(f"Generating tests for {component_path}")
    text_termination = TextMentionTermination("APPROVE")
    max_msg_termination = MaxMessageTermination(max_messages=10)
    combined_termination = max_msg_termination | text_termination

    team = RoundRobinGroupChat(
        participants=[tester, reviewer],
        termination_condition=combined_termination,
    )

    message = f"""
Write TypeScript unit test cases using 'Jest' and 'React Testing Library' framework for the following Next.js component.

Next.js Component Path: {component_path}

Next.js Component:
{component_code}

The final output should be inside a ```javascript``` or ```jsx``` code block.
"""
    # Send the message and await the response from the team
    result = await team.run(task=message)
    
    # Log or process the result as needed
    logger.info(f"Generated test code: {result}")
    last_message = result.messages[-2]
    # Save the generated test code
    if last_message:
        with open(test_path, "w", encoding="utf-8") as test_file:
            code = extract_js_code(last_message.content)
            test_file.write(code)

async def fix_test(test_file: str) -> None:
    logger.info(f"Fixing tests for {test_file}")
    text_termination = TextMentionTermination("APPROVE")
    max_msg_termination = MaxMessageTermination(max_messages=10)
    combined_termination = max_msg_termination | text_termination

    # Set up the team with round robin and termination condition
    team = RoundRobinGroupChat(
        participants=[executer, fixer],
        termination_condition=combined_termination
    )
    test_code = Path(test_file).read_text(encoding="utf-8")

    message = f"""
Fix the failing test cases.

Test File: 
{test_file}

Test Code:
{test_code}
"""
    # Send the message and await the response from the team
    result = await team.run(task=message)
    print(result)

# Process all components in the directory
async def process_all_components(src_dir: str = "src/components", test_dir: str = "src/__tests__", pattern: str = "*.jsx") -> None:
    src_path = Path(src_dir)
    test_path = Path(test_dir)

    if not src_path.exists():
        logger.error(f"❌ Source directory {src_path} does not exist.")
        return

    component_files = list(src_path.glob(pattern))
    component_files = [f for f in component_files if not f.name.endswith(".test.tsx")]

    if not component_files:
        logger.info(f"🔍 No files matching pattern '{pattern}' found in {src_path}")
        return

    for file_path in component_files:
        if file_path.is_file():
            try:
                component_code = file_path.read_text(encoding="utf-8")
                component_name = file_path.stem
                component_path = file_path
                test_file_path = test_path / f"{component_name}.test.tsx"

                logger.info(f"📦 Processing component: {file_path}")

                # Generate and save the test for the component
                #await generate_test(component_code, component_path, test_file_path)

                await fix_test(test_file_path)

            except Exception as e:
                logger.error(f"🔥 Error processing file {file_path}: {e}")

# Run the async process
asyncio.run(process_all_components(src_dir="src/app/components/Auth", test_dir="src/app/components/Auth", pattern="Login.tsx"))
