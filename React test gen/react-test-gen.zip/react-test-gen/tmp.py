from pathlib import Path
import os

def get_relative_path(from_path: str, to_path: str) -> str:
    # If from_path is a file, use its directory
    if os.path.isfile(from_path):
        from_path = os.path.dirname(from_path)

    if os.path.isfile(to_path):
        to_path = os.path.dirname(to_path)
    
    # If to_path is a file, use its full path (but allow filename in the relative path)
    return os.path.relpath(os.path.abspath(to_path), os.path.abspath(from_path))

# Example
test_path = "src/__test__"
component_path = "src/app/components/Auth"

print(get_relative_path(test_path, component_path))  # Output: data/files