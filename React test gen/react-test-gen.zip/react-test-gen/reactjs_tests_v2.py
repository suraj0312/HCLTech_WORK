import os
import re
from pathlib import Path
from crewai import Agent, Task, Crew, Process
from crewai_tools import FileWriterTool, FileReadTool
from crewai import LLM
import subprocess
from crewai.tools import BaseTool
from crewai.tools import tool

#llm = LLM(model="ollama/qwen2.5-coder:14b", base_url="http://localhost:11434", temperature=0.4)
#llm = LLM(model="ollama/gemma3:27b-it-qat", base_url="http://localhost:11434", temperature=0.4)

#llm = LLM(model="ollama/llama3.2", base_url="http://localhost:11434")
#llm = LLM( model="gemini/gemini-2.0-flash",  api_key="AIzaSyA4kLSO3v0WI1bIsN4L6RItLBL7oTGzFM4", temperature=0.4)

llm = LLM( model="gemini/gemini-2.0-flash",  api_key="AIzaSyBMXkjbMdebR6sGinuI8ehTWjpytiBNRqM", temperature=0.4)

import re

def extract_all_js_code_blocks(markdown: str, component_name) -> str:
    # Match code blocks with js/jsx/tsx/javascript language specifier
    pattern = r"```(?:js|jsx|tsx|javascript|typescript)\s+(.*?)```"
    matches = re.findall(pattern, markdown, re.DOTALL)

    if not matches:
        raise ValueError(f"No valid JavaScript code block found for {component_name}")

    # Combine and return all matched blocks
    return "\n\n".join(block.strip() for block in matches)
    

@tool("jest_runner")
def jest_runner(file_path: str) -> str:
    "Runs a specified Jest test file and returns the output"
    try:
        output = subprocess.getoutput(f"npm test -- --watchAll=false {file_path}")
        return output
    except Exception as e:
        return f"Error running Jest test: {str(e)}"

class RjsUnitTest:
    def component_analyzer(self) -> Agent:
        return Agent(
        role="React Component Analyzer",
        goal="Identify all testable elements with in a React component including props, internal logic, and UI behaviors.",
        backstory=(
            "You are a senior ReactJS developer and testing expert. "
            "You specialize in breaking down React components into precise, testable units, identifying critical props, event handlers, state logic, and user interactions that should be covered in unit tests."
        ),
        verbose=True,
        llm=llm
    )

    def test_writer(self) -> Agent:
        return Agent(
        role="React Unit Test Writer",
        goal="Write high-quality unit tests for React components using Jest and React Testing Library.",
        backstory=(
            "You are a highly skilled React developer and testing expert. "
            "You specialize in writing clean, maintainable, and comprehensive unit tests using Jest and React Testing Library. "
            "You ensure test coverage for all component behavior, including props, state changes, event handling, conditional rendering, and edge cases."
        ),
        verbose=True,
        llm=llm
    )

    def test_runner_agent(self):
        return Agent(
        role="Jest Unit Test Diagnostician",
        goal="Run and analyze Jest unit test results to identify root causes of failures and suggest precise fixes.",
        backstory=(
            "You are a QA automation specialist with deep expertise in diagnosing unit test failures. "
            "You interpret Jest error messages, stack traces, and assertion failures, and link them back to specific component behavior, logic errors, or missing edge case handling. "
            "You clearly explain the cause of each failure and recommend how to fix the related test or component logic."
        ),
        verbose=True,
        llm=llm
    )
    
    def test_case_reviewer(self) -> Agent:
        return Agent(
        role="React Unit Test Reviewer",
        goal="Review unit test cases for React components to ensure correctness, completeness, and best practices using Jest and React Testing Library.",
        backstory=(
            "You are a senior React developer and testing expert, highly experienced in Jest and React Testing Library. "
            "You evaluate test cases for accuracy, clarity, edge case coverage, and alignment with testing best practices. "
            "You provide specific feedback on missing scenarios, redundant tests, and opportunities to improve test readability and maintainability."
        ),
        verbose=True,
        llm=llm
    )
    
    def test_fixer_agent(self):
        return Agent(
        role="Unit Test Fixer",
        goal="Analyze Jest test errors and fix only the failing unit tests, preserving the structure and behavior of passing tests.",
        backstory=(
            "You are a senior React developer with deep expertise in Jest and React Testing Library. "
            "You specialize in resolving unit test failures with minimal changes. "
            "You carefully examine error messages, stack traces, and component logic to apply precise fixes that address the root cause without introducing regressions or altering working tests."
        ),
        verbose=True,
        llm=llm
    )



    def analyze_component_task(self, component_code: str) -> Task:
        return Task(
        description=f"""
        Analyze the following React component code:

        --- Component Code Start ---
        {component_code}
        --- Component Code End ---

        Your analysis should identify and describe:
        1. Component props and their usage
        2. Conditional rendering and logical branches
        3. User-triggered events and handlers
        4. Key functionalities and behaviors that should be tested

        Output a clear, structured analysis to assist in writing comprehensive unit tests.
        """,
        expected_output="A structured and detailed breakdown of component props, conditionals, branches, events, and testable functionality.",
        agent=self.component_analyzer()
    )


    def write_test_cases_task(self, component_code: str, analyze_task: Task) -> Task:
        return Task(
        description=f"""
        Write comprehensive unit tests for the following React component using Jest and React Testing Library.

        --- Component Code Start ---
        {component_code}
        --- Component Code End ---

        Requirements:
        - Cover all props, conditional rendering, logical branches, and event handlers
        - Simulate user interactions (e.g., clicks, input changes)
        - Handle edge cases (e.g., missing or empty props)

        Constraints:
        - Only import from '@testing-library/jest-dom' (do **not** use '@testing-library/jest-dom/extend-expect')
        - Ensure all required React hooks are properly imported

        Output:
        - Provide **only** the complete unit test code
        - Do **not** include explanations, comments, or any non-code text
        """,
        expected_output="A complete and correct unit test file (code only) written using Jest and React Testing Library.",
        agent=self.test_writer(),
        context=[analyze_task]
    )


    def review_test_cases_task(self, component_code: str, write_test_task: Task) -> Task:
        return Task(
        description=f"""
        Review and fix any issues in the unit test file for the following React component:

        --- Component Code Start ---
        {component_code}
        --- Component Code End ---

        Requirements:
        - Identify and correct problems in the unit test file (e.g., incorrect assertions, missing imports, test logic errors)

        Output:
        - Return the complete, corrected unit test code only
        - Wrap the code in a single markdown code block with language tag: ```javascript```
        - Do **not** include explanations, comments, or any text outside the code block
        """,
        expected_output="A corrected and complete Jest unit test file, inside a single ```javascript``` code block, with no extra text.",
        agent=self.test_case_reviewer(),
        context=[write_test_task]
    )

    
    def run_unit_tests_task(self, test_file_path: str, component_code: str) -> Task:
        return Task(
            description=f"""
    Your task is to run the Jest test file located at: `{test_file_path}`
    Also provided is the React component source code being tested.

    --- Start Component Code ---
    {component_code}
    --- End Component Code ---

    Instructions:
    - Run the test file and collect the results.
    - If all tests pass, respond with: **"All tests passed."**
    - If any tests fail:
        - Clearly identify which test cases failed.
        - Use the component code to help identify likely root causes.
        - Suggest precise changes to fix the failing test cases (but do NOT modify any code).

    Your output will be passed to a test-fixing agent. Make sure your guidance is concise, accurate, and clearly actionable.
            """,
            expected_output=(
                "If tests passed: 'All tests passed.'\n"
                "If tests failed: List of failed tests, error messages, and clear, actionable suggestions for fixes."
            ),
            agent=self.test_runner_agent(),
            tools=[jest_runner],
            inputs={"file_path": test_file_path}
        )


    def fix_failing_tests_task(self, test_code: str, run_unit_tests_task: Task) -> Task:
        return Task(
            description=f"""
    The following Jest test file contains one or more failing tests.

    --- Start Test Code ---
    {test_code}
    --- End Test Code ---

    Use the diagnostic insights provided by the previous task to identify which test cases are failing and why.

    Your responsibilities:
    - Fix **only** the failing test cases.
    - Keep the passing test cases untouched.
    - Preserve the overall structure, formatting, and style of the original file.
    - Ensure the corrected code will execute without errors.
    - Make sure all required imports are present and valid.

    Output requirements:
    - Return only the full corrected test code.
    - The code must be enclosed in a single markdown code block (```javascript```).
    - Do not include any explanation or comments outside the code block.
    """,
            expected_output="A single markdown code block containing the corrected Jest test code.",
            agent=self.test_fixer_agent(),
            context=[run_unit_tests_task]
        )



def generate_test(test_dir, component_name, component_code):
        print(f"\n🚀 Running test generation for component: {component_name}")
        runner = RjsUnitTest()

        analyze_task = runner.analyze_component_task(component_code)
        write_test_task = runner.write_test_cases_task(component_code, analyze_task)
        review_task = runner.review_test_cases_task(component_code, write_test_task)

        crew_gen = Crew(
            agents=[
                runner.component_analyzer(),
                runner.test_writer(),
                runner.test_case_reviewer()
            ],
            tasks=[
                analyze_task,
                write_test_task,
                review_task
            ],
            process=Process.sequential,
            verbose=True
        )

        result = crew_gen.kickoff()

        # Extract JavaScript code block using regex
        try:
            test_code = extract_all_js_code_blocks(result.raw, component_name)
        except ValueError:
            test_code = extract_all_js_code_blocks(write_test_task.output.raw, component_name)

        # Save to test file
        test_path = test_dir / f"{component_name}.test.tsx"
        with open(test_path, "w", encoding="utf-8") as f:
            f.write(test_code)

        print(f"✅ Test written to {test_path}")

def fix_code(test_dir, component_name, component_code):
        print(f"\n🚀 Running test execution and fix for component: {component_name}")
        runner = RjsUnitTest()
        test_path = test_dir / f"{component_name}.test.tsx"
        test_code = Path(test_path).read_text(encoding='utf-8')

        max_attempts = 2
        for attempt in range(1, max_attempts + 1):
            run_task = runner.run_unit_tests_task(test_path, component_code)

            crew_test = Crew(
                agents=[runner.test_runner_agent()],
                tasks=[run_task],
                process=Process.sequential,
                verbose=True
            )
            crew_test_result = crew_test.kickoff()

            if "All tests passed." in crew_test_result.raw:
                print("✅ All tests passed.")
                break

            print("❌ Errors found. Attempting to fix...")

            fix_task = runner.fix_failing_tests_task(test_code, run_task)

            crew_test_fix = Crew(
                agents=[runner.test_fixer_agent()],
                tasks=[fix_task],
                process=Process.sequential,
                verbose=True
            )
            crew_test_fix = crew_test_fix.kickoff()

            # Extract JavaScript code block using regex
            fix_code = extract_all_js_code_blocks(crew_test_fix.raw, component_name)
            Path(test_path).write_text(fix_code)

def run_for_all_components():
    src_dir = Path("src/app/components/Auth")
    test_dir = Path("src/app/components/Auth")
    test_dir.mkdir(parents=True, exist_ok=True)

    for file_path in src_dir.glob("Login.tsx"):
        if not file_path.name.endswith(".test.tsx"):
            component_code = file_path.read_text(encoding="utf-8")
            component_name = file_path.stem

            generate_test(test_dir=test_dir, component_name=component_name, component_code=component_code)
            fix_code(test_dir=test_dir, component_name=component_name, component_code=component_code)


        


if __name__ == "__main__":
    run_for_all_components()
