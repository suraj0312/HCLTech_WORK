import { useRouter, usePathname } from 'next/navigation';

jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
  usePathname: jest.fn(),
}));

const mockRouter = {
  push: jest.fn(),
  replace: jest.fn(),
  prefetch: jest.fn(),
  route: '/',
  pathname: '',
  query: {},
  asPath: '',
};

(useRouter as jest.Mock).mockReturnValue(mockRouter);
(usePathname as jest.Mock).mockReturnValue('/');