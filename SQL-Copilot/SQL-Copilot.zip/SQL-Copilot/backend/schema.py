smartChartSchema = """
    {
    "title" : "Polt for Price & Quantity of Fruits",
    "traces" : [
        {
            "x": ["apple", "mango", "banana", "strawberry", "pipeapple", "grape"],
            "y": [70, 40, 60, 30, 50, 90],
            name: "quantity",
        },
        {
            "x": ["apple", "mango", "banana", "strawberry", "pipeapple", "grape"],
            "y": [40, 60, 20, 80, 50, 30],
            "name": "price",
        },
        ]
    "xaxis_title": "Fruits"
    "yaxis_title": "Quantity or Price"
    }
"""

# barChartResultDict = """{
#     "title" : "Plot for Price & Quantity of Fruits",
#     "x" : "fruits" (name of column best suitable for "x"),
#     "y" : ["quantity", "price"] (list of name of columns suitable for "y"),
#     "name" : ["quantity", "price"](list of names suitable for trace),
#     "xaxis_title": "Fruits",
#     "yaxis_title": "Quantity or Price",
# }"""

pieChartSchema = """
    {
    "title" : "Global Emissions 1990-2011",
    "traces" : [
        {
            "values": [16, 15, 12, 6, 5, 4, 42],
            "labels": ["US", "China", "Europe", "Russia", "Brazil", "India", "Rest of World"],
            "name": "GHG Emissions",
        },
        {
            "values": [27, 11, 25, 8, 1, 3, 25],
            "labels": ["US", "China", "Europe", "Russia", "Brazil", "India", "Rest of World"],
            "name": "CO2 Emissions",
        },
        ]
    }
"""

# pieChartResultDict = """{
#     "title" : "Global Emissions 1990-2011",
#     "values" : ["GHG-Emissions", "CO2-Emissions"] (list of name of columns suitable for "values"),
#     "labels" : "country" (name of column best suitable for "labels"),
#     "name" : ["GHG Emissions", "CO2 Emissions"](list of names suitable for traces),
# }"""

# tableChartSchema = """"""
# tableChartResultDict = """"""