from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain_core.tools import tool
from model import llm
import ast
from schema import *
import pandas as pd
import json

from typing import List, Literal, Annotated
from pydantic import BaseModel, Field



db = SQLDatabase.from_uri(r"sqlite:///C:\Users\utkarsh.alpuria\Desktop\My Work\SQL Agent Langchain\Chinook_Sqlite.sqlite")

toolkit = SQLDatabaseToolkit(db=db, llm=llm)
tools = toolkit.get_tools()
tools.pop(0)


@tool
def db_query_tool(query: str) -> str:
    """
    Execute a SQL query against the database and get back the result as json only.
    If the query is not correct, an error message will be returned.
    If an error is returned, rewrite the query, check the query, and try again.
    """
    db_query_tool_result = db.run(query, include_columns=True)
    if not db_query_tool_result:
        return "Error: Query failed. Please rewrite your query and try again."
    return db_query_tool_result


class ResponseFormatter(BaseModel):
    """Always use this tool to structure your response to the user."""
    is_plot_possible: bool = Field(...,description="If plot is possible for given user_query and result")
    what_plot_is_possible:Literal['bar','pie','line','scatter','table','None']= Field(...,description='which type of graph is possible like bar,pie,line,scatter etc. If not any according to given schema then return None')
    user_request:Literal['bar','pie','line','scatter','table', 'donut', 'tree', 'any']=Field(...,description='Name of the visualisation type that user has requested if any else None')


class SmartChartSchemaFormatter(BaseModel):
    """Always use this tool to structure your response to the user."""
    title:str=Field(...,description='Suitable title for the chart')
    x: str = Field(...,description="Column name which is used to plot chart in x-axis")
    y:List[str]=Field(...,description='List of columns name used in y-axis')
    name:List[str]=Field(...,description='List of names suitable for traces')
    xaxis_title:str=Field(...,description='Suitable title for x-axis')
    yaxis_title:str=Field(...,description='Suitable title for y-axis')

class PieChartSchemaFormatter(BaseModel):
    """Always use this tool to structure your response to the user."""
    title:str=Field(...,description='Suitable title for the chart')
    labels: str = Field(...,description="Column name which is used to plot pie chart labels")
    val:List[str]=Field(...,description='List of columns names used in values')
    name:List[str]=Field(...,description='List of names suitable for traces')

class TableSchemaFormatter(BaseModel):
    """Always use this tool to structure your response to the user."""
    title:str=Field(...,description='Suitable title for the chart')
    
def summaryGenerator(dataframe):
    summary=llm.invoke(f"""
            **Role:** Manager
            **Task:** Provide an insightful summary (approx. 100 words) based on the provided data snippets.
            **Context:**
            *   **Data Structure/Sample:** Here are the first few rows to show columns and data types:
                {dataframe.head(3)}
                
            *   **Overall Statistics:** Here are key summary statistics for the complete dataset:
                {dataframe.describe()}

            **Instructions:**
            *   Focus on key takeaways, potential trends, or notable points revealed by the **statistics** (`{dataframe.describe()}`).
            *   Use the sample data (`{dataframe.head(3)}`) primarily to understand the column context.
            *   Format the response as Markdown bullet points.
            *   Keep the summary concise and impactful.
            """)
    return str(summary.content)


def smartChart(dataframe, x_axis, y_axis, title, name, graph_name, xaxis_title, yaxis_title):
    title=title
    arr=[]
    for i in range(len(y_axis)):
        arr.append({
            'x':dataframe[x_axis].tolist(),
            'y':dataframe[y_axis[i]].tolist(),
            'name':name[i]
        })

    chart={'title':title,
           'traces':arr,
           'type':graph_name,
           'xaxis_title':xaxis_title,
           'yaxis_title':yaxis_title,
           'stats': dataframe.describe().fillna(0).to_dict(),
           'summary': summaryGenerator(dataframe)
           }
   
    return chart


def pieChart(dataframe, labels, values, title, name, graph_name):
    title=title
    arr=[]
    for i in range(len(values)):
        arr.append({
            'labels':dataframe[labels].tolist(),
            'values':dataframe[values[i]].tolist(),
            'name':name[i]
        })

    chart={'title':title,
           'traces':arr,
           'type':graph_name,
           'stats': dataframe.describe().fillna(0).to_dict(),
           'summary': summaryGenerator(dataframe)
           }
   
    return chart


def tableView(dataframe, graph_name, title):
    header=dataframe.columns.to_list()
    cell=[]
    for head in header:
        cell.append(dataframe[head].to_list())

    return {
        'type':graph_name,
        'header':header,
        'cell':cell,
        'title':title,
        'stats': dataframe.describe().fillna(0).to_dict(),
        'summary': summaryGenerator(dataframe)
    }


def tableModel(user_query,dataframe):
    table_llm=llm.with_structured_output(TableSchemaFormatter)
    table_llm_response=table_llm.invoke(f'Suggest the most suitable title for a table, which have columns {dataframe.columns} and user have asked this query `{user_query}`')
    # print('TABLE RESPONSE TITLE', table_llm_response)
    return table_llm_response.title


def createChartSchema(user_query,dataframe,graph_name):
    try:
        if graph_name=='table':
            # table_llm=llm.with_structured_output(TableSchemaFormatter)
            title=tableModel(user_query, dataframe)
            # print('TABLE RESPONSE TITLE', title)
            return tableView(dataframe,graph_name,title)
        elif graph_name in ['bar','line','scatter']:
            chart_schema=smartChartSchema
            schema_llm=llm.with_structured_output(SmartChartSchemaFormatter)
        elif graph_name =='pie':
            chart_schema=pieChartSchema
            schema_llm=llm.with_structured_output(PieChartSchemaFormatter)
        
        small_df=dataframe.head(2)
        
        schema_llm_response=schema_llm.invoke(f"""
            According to the given user query: '{user_query}' and the data {small_df},
            I want to generate a visualisation with this following schema. 
            {chart_schema}
            Can you specify the columns names which is most suitable for particular keys in schema.
            Also suggest suitable titles if present in schema.     
            """)
        
        if graph_name in ['bar','line','scatter']:
            x_axis=schema_llm_response.x
            y_axis=schema_llm_response.y
            title=schema_llm_response.title
            name=schema_llm_response.name
            xaxis_title=schema_llm_response.xaxis_title
            yaxis_title=schema_llm_response.yaxis_title
            return smartChart(dataframe, x_axis, y_axis, title, name, graph_name, xaxis_title, yaxis_title)
        
        elif graph_name=='pie':
            labels=schema_llm_response.labels
            values=schema_llm_response.val
            title=schema_llm_response.title
            name=schema_llm_response.name
            return pieChart(dataframe, labels, values, title, name, graph_name)
        else:
            return{
                'chart_schema':schema_llm_response
            }
    except Exception as e:
        return{
            "result" : f"Error in CREATE_CHART_SCHEMA - {str(e)}"
        }

@tool
def predict_visualization(user_query: str, db_query_tool_result: Annotated[List[dict], "list of dicts from db_query_result tool"]):
    """
    This tool is used to create different visualizations like: [bar, line, pie, scatter, table].
    If db_query_tool is called at any point it is MANDATORY to call this tool NEXT to it.
    As we ALWAYS want to return a visualization to the user if db_query_tool is called.
    Args:
        user_query (str): The question from the user requesting a bar graph (e.g., 'Plot a bar graph for every country total spent').
        db_query_tool_result (str): typically a list of dictionaries as string.
    Returns:
        A structured object used for creating the visualization on frontend.
    """
    # try:
    #     db_query_tool_result = ast.literal_eval(db_query_tool_result)
    # except Exception as e:
    #     print(f"Issue in converting db_query_tool_result string!\nError : {str(e)}")

    # result_dataframe = ""
    # if type(db_query_tool_result) == list:  
    try:
        result_dataframe = pd.DataFrame(db_query_tool_result, index=list(range(len(db_query_tool_result))))
        # result_dataframe = result_dataframe.dropna()
        result_dataframe = result_dataframe.fillna("None")
        # result_dataframe = result_dataframe.replace([np.nan, np.inf, -np.inf], "None")
        result_dataframe[result_dataframe.select_dtypes(include='number').columns] = result_dataframe.select_dtypes(include='number').round(2)
        # elif type(db_query_tool_result) == dict:
        #     result_dataframe = pd.DataFrame(db_query_tool_result)
        # print(result_dataframe)
        
        llm_with_tools=llm.with_structured_output(ResponseFormatter)
        llm_response=llm_with_tools.invoke(f'''
            You are a data analyst having user query{user_query} and its result {result_dataframe.head(2)}. Only generate a plot or graph when it is meaningfully enhances the understanding of the data or clearly shows a pattern, trend, or comparison that would be difficult to grasp from raw numbers alone. Do not generate visualizations for small sets of standalone values or when the visual adds no analytical value. If visualization is unnecessary, provide a clear explanation instead.
            for example:\n
            user_query = show me donut chart for total number of customer in every country.
            llm_response =\n
            is_plot_possible=True
            what_plot_is_possible=Pie
            user_request=donut
        ''')

        
        print('LLM RESONSE', llm_response)
        possible_plot=llm_response.is_plot_possible
        available_plot=llm_response.what_plot_is_possible
        user_request=llm_response.user_request

        if possible_plot:
            if user_request and user_request == available_plot:
                return createChartSchema(user_query,result_dataframe,user_request)
            elif (user_request and user_request not in available_plot) or available_plot:
                return createChartSchema(user_query,result_dataframe,available_plot)
                # print('This is request cannot be completed')
        else:
            # if (user_request=='table') or (available_plot=='table'):
            #     return createChartSchema(user_query,result_dataframe,'table')
            # else:
            #     return {'result':db_query_tool_result}
            return createChartSchema(user_query,result_dataframe,'table')
        
    except Exception as e:
        # print("ERROR in PredictVisualization")
        # return {'result': "Something went wrong, please restart or try again after some time!"}
        return {'result': f"Error in PREDICT_VISUALISATION - {str(e)}"}

tools.append(db_query_tool)  
tools.append(predict_visualization)

# user="show me pie graph total number of customer in every country"
# sql=[{'Country': 'USA', 'NumberOfCustomers': 13}, {'Country': 'Canada', 'NumberOfCustomers': 8}, {'Country': 'France', 'NumberOfCustomers': 5}, {'Country': 'Brazil', 'NumberOfCustomers': 5}, {'Country': 'Germany', 'NumberOfCustomers': 4}]

# print(predictVisualization(user,sql))