import json
from model import llm
from tools_5 import tools, tableView, tableModel
# from graph2 import *
import pandas as pd
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import HumanMessage, ToolMessage,AIMessage
from langgraph.prebuilt import create_react_agent
import numpy as np
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel,Field
from typing import List, Optional
import uvicorn
from ast import literal_eval
from langchain_core.messages import RemoveMessage
from langgraph.graph.message import REMOVE_ALL_MESSAGES
# Initialize FastAPI app
app = FastAPI()

# CORS Middleware setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # You can specify your frontend URL here
    allow_credentials=True,
    allow_methods=["*"],  # Allows all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# Pydantic models to validate the incoming data

class Content(BaseModel):
    type: str
    text: str
 
class AttachmentStatus(BaseModel):
    type: str
 
class AttachmentFile(BaseModel):
    # You can customize this model to handle actual file data if needed
    pass
 
class Attachment(BaseModel):
    id: str
    type: str
    name: str
    contentType: str
    file: Optional[AttachmentFile] = None
    status: AttachmentStatus
    content: List[Content] = []
 
class Message(BaseModel):
    id: str
    createdAt: str
    role: str
    content: List[Content] = []
    attachments: List[Attachment] = []

class ChatRequest(BaseModel):
    userData: List[Message]

class ResponseFormatter(BaseModel):
    """Always use this tool to structure your response to the user."""
    summmary: str = Field(...,description="Give the summary text")
    stats:str= Field(...,description='Give all the stats and key metrics')






system_message = f"""
You are a helpful assistant that interacts with an SQL database and generates suitable charts for the data. You have access to the following tools:

- **sql_db_schema**: Use this to view the database schema.
- **sql_db_list_tables**: Use this to list all tables in a database.
- **sql_db_query_checker**: Use this to validate queries before execution.
- **db_query_tool**: Use this to execute validated queries.
- **predict_visualization**: Use this to generate and provide visualizations like bar, pie, line, scatter, table for the data.


### Restrictions:
- Do not perform any DELETE or REMOVE operations.
- Do not perform any Modify operation.
- Column name should be meaningful not like count(*) or count(customer).
- Do not ask user to specify database, you have to do it with help of available tools.
- Do not change user query for predict_visualization, the tool is capable of creating MULTIPLE graph at once just call the tool with original user query and data.
For query related to database start from sql_db_schema tool.
"""

memory = MemorySaver()

def pre_model_hook(state):
    messages = state["messages"]

    if len(messages) > 2:
        if isinstance(messages[-2], AIMessage):
            if messages[-2].response_metadata["finish_reason"] == "MALFORMED_FUNCTION_CALL":
                messages[-2].response_metadata["finish_reason"]  = 'STOP'
                messages[-2].content  = "Here is the complete table"

    all_convos = []
    current_convo = []

    full_details_convo_to_keep = 3
    condensed_convo_to_keep = 3

    for message in messages:
        if isinstance(message, HumanMessage): # if message is HumanMessage
            if current_convo: # if current_convo is not empty -> means this is a new HumanMessage and previous convo was complete
                all_convos.append(current_convo) # append the previous complete convo to all_convos
            # after prevoius convo was added to all_convo
            current_convo = [message] # current_convo is started with new HumanMessage 
        elif current_convo: # if not HumanMessage and current_convo not empty -> meaning this is AI/Tool messsage and the current_convo is stared with HumanMessage
            current_convo.append(message) # the AI/Tool message is appended in current_convo

    if current_convo: # at end of for loop current_convo is filled with the complete latest convo
        all_convos.append(current_convo) # append the latest convo in all_convos

    # print("all_convo- ", all_convos)

    processed_convos = []

    for i, convo in enumerate(all_convos):
        convo_index = len(all_convos) - 1 - i
        # print("convo_index - ", convo_index)

        if convo_index < full_details_convo_to_keep:
            processed_convos.append(convo)
            # print("keep full detail", convo_index)
        elif convo_index < full_details_convo_to_keep + condensed_convo_to_keep:
            # print("condensing convo", convo_index)

            condensed_convo = []
            final_ai_msg = None
            final_tool_msg = None
            condensed_convo.append(convo[0])
            for j in range(len(convo) - 1, 0, -1):
                if convo[j] and isinstance(convo[j], AIMessage):
                    final_ai_msg = convo[j]
                    if j > 0 and isinstance(convo[j-1], ToolMessage):
                        final_tool_msg = convo[j-1]
                    break

            if final_tool_msg:
                condensed_convo.append(final_tool_msg)
            if final_ai_msg:
                condensed_convo.append(final_ai_msg)
            if condensed_convo:
                processed_convos.append(condensed_convo)

    # print("processed_convo - ", processed_convos)

    final_messages = []
    for p_convo in processed_convos:
        final_messages.extend(p_convo)

    return {"messages": [RemoveMessage(REMOVE_ALL_MESSAGES)] + final_messages}

    

sql_agent = create_react_agent(llm, tools, checkpointer=memory, prompt=system_message, version='v2', pre_model_hook=pre_model_hook)

def output_pretty_print(response):
    print("RESPONSE - ")
    for message in response["messages"]:
        if type(message) == HumanMessage:
            print("="*40 + "[ Human Message ]" + "="*40)
            print(message.content)
            print()
        elif type(message) == AIMessage:
            print("="*40 + "[  AI Message   ]" + "="*40)
            if message.tool_calls:
                print("tool to call!")
                print("tool_name:", message.tool_calls[0]["name"])
                print("args:", message.tool_calls[0]["args"])
                print()
            else:
                print(message.content)
                print()
        elif type(message) == ToolMessage:
            print("="*40 + "[ Tool Message  ]" + "="*40)
            print(message.content)
            print()

def get_sql_agent_response(human_message):

    config = {"configurable": {"thread_id": "newconfig123"}}
    # input_message = [HumanMessage(f'If any tools avaialable for `{human_message}`, use tool call otherwise you handle the response.')]
    input_message = [HumanMessage(human_message)]
    try:
        response = sql_agent.invoke({"messages": input_message}, config=config)
    except Exception as e:
        return {"last_ai_message": {"ai_message":str(e)}}
    # print("RESPONSE- ", response)
    output_pretty_print(response)

    messages = response.get("messages", [])
    if len(messages) < 2:
        return {"tool_name": "unknown_tool", "last_ai_message": { "ai_message": messages[-1].content } if messages else ""}

    second_last = messages[-2]
    last_message = messages[-1]
    ai_answer = {"last_ai_message": {"ai_message":last_message.content}, "tool_name": "unknown_tool"}

    if not isinstance(second_last, ToolMessage):
        return ai_answer
        
    try:
        tool_output = literal_eval(second_last.content)
    except Exception as e:
        ai_answer["error"] = f"Failed to parse tool output: {e}"
        return ai_answer
    
    tool_name = getattr(second_last, "name", "unknown_tool")
    ai_answer["tool_name"] = tool_name

    if tool_name == "predict_visualization":
        if "result" in tool_output:
            ai_answer["tool_name"] = "unknown_tool"
        else:
            ai_answer["tool_response"] = tool_output

    elif tool_name == "db_query_tool":
        if isinstance(tool_output, list):
            df = pd.DataFrame(tool_output)
            df = df.fillna("None")
            df[df.select_dtypes(include='number').columns] = df.select_dtypes(include='number').round(2)
            title = tableModel(human_message, df)
            ai_answer["tool_response"] = tableView(df, "table", title)
            # ai_answer["tool_name"] = "db_"
            # print("MESSAGES\n",len(messages))
            # messages[-1] = AIMessage("Here is the complete table")
            return ai_answer

    return ai_answer


# # Route to process incoming messages and attachments
@app.post("/api/chat")
# async def chat_response(request: ChatRequest):
async def chat_response(request: ChatRequest):
    # Extract the most recent message
    messages = request.userData
    # print("MESSAGES: ", messages)
    if not messages:
        return {"error": "No messages found in the request!"}
    
    user_message = ""
    latest_message = messages[-1]
    if latest_message.content:
        # print("USER -", latest_message.content[0].text)
        user_message = latest_message.content[0].text
   
    if latest_message.attachments:
        # print("ATTACHMENTS -", latest_message.attachments)
        for attachment in latest_message.attachments:
            # print("ATTACHMENT CONTENT - ", attachment.content)
            for content in attachment.content:
                # print("CONTENT -", content)
                user_message += "ATTACHED FILE DATA :\n" + str(content.text)

    print("USER-", user_message)
    try:
        agent_response = get_sql_agent_response(user_message)
        
    except Exception as e:
        agent_response = {
            "last_ai_message" : {'ai_message':str(e)}
        }

    # print("ASSISTANT-", agent_response)        
    return agent_response


if __name__ == '__main__':
    uvicorn.run(app, host="127.0.0.1", port=8000)

# uvicorn backend_7:app --reload

# while True:
#     user=input('Ask your query')
#     print(get_sql_agent_response(user))
