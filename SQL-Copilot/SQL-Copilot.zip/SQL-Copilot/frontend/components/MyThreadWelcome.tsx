import { ThreadWelcome, type ThreadConfig, } from "@assistant-ui/react";
import { FC } from "react";
 
const MyThreadWelcomeMessage: FC = () => {
    return (
      <div className="aui-thread-welcome-message-container">
        <ThreadWelcome.Message message="Welcome to SQL Copilot"/>
      </div>
    );
  };

const MyThreadWelcomeSuggestions: FC = () => {
    return (
      <div className="aui-thread-welcome-suggestion-container">
        <ThreadWelcome.Suggestion  suggestion={{prompt : "What can you do?"}} />
        <ThreadWelcome.Suggestion suggestion={{prompt : "Brief me about database"}} />
      </div>
    );
  };



export const MyThreadWelcome: FC = () => {
  return (
    <ThreadWelcome.Root>
      <ThreadWelcome.Center>
        <ThreadWelcome.Avatar />
        <MyThreadWelcomeMessage />
      </ThreadWelcome.Center>
      <MyThreadWelcomeSuggestions />
    </ThreadWelcome.Root>
  );
};