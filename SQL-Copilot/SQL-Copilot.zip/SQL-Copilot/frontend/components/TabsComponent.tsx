import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import StatsDashboard from "./StatsDashboard";


export default function RenderTabsComponent({ tabs_data } : { tabs_data: any }) {

    const [activeTab, setActiveTab] = useState("summary");

    const summary = tabs_data.summary;
    const stats = tabs_data.stats;

    return (
        <div className="tabs-container">
            <div className="tabs-buttons">
                <button className={`tab-button ${activeTab === "summary" ? "active" : ""}`} onClick={() => setActiveTab("summary")}>
                    SUMMARY
                </button>
                <button className={`tab-button ${activeTab === "stats" ? "active" : ""}`} onClick={() => setActiveTab("stats")}>
                    STATS
                </button>
            </div>
            <div className="tab-content">
                {activeTab === "summary" ? (
                    <ReactMarkdown>{summary}</ReactMarkdown>
                ) : (
                    <StatsDashboard statsData={stats} />
                )}
                </div>
        </div>
    );
}
