import { ToolCallContentPartComponent } from "@assistant-ui/react";

// import RenderChart from "./render_bargraph";
import CreateChart from "./ChartComponent";
// const data = {
//   series: [{ data: [5, 1, 2], label: "Number of Employees" },
//             { data: [3,1,4], label: "Number of Managers" }

// ],
//   xAxis: [{ data: ["Calgary", "Edmonton", "Lethbridge"], scaleType: "band" }],
// };

export const ToolFallback: ToolCallContentPartComponent = ({
  toolName,
  argsText,
  result,
}) => {
  if ((toolName == "predict_visualization") || (toolName == "db_query_tool")) {
    return < CreateChart plot_info={result} />;
  }
};