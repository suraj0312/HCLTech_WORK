import React, { useState } from 'react';
import Plot from 'react-plotly.js';



const StatBox = ({ label, value }) => {
  // console.log(`Rendering StatBox - Label: ${label}, Value:`, value, 'Type:', typeof value);

  return (
    <div className="stat-box">
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value != null ? String(value) : '—'}</div>
    </div>
  );
};


const QuartileBar = ({ stats }) => {
  const quartileData = [
    { quartile: '25%', value: stats['25%'] },
    { quartile: '50%', value: stats['50%'] },
    { quartile: '75%', value: stats['75%'] },
  ];

  return (
    <div className="stat-box graph-box">
      <div className="stat-label">Quartiles</div>
      <Plot
        data={[
          {
            x: quartileData.map(q => q.quartile),
            y: quartileData.map(q => q.value),
            type: 'bar',
            marker:{
              color: ["#97e3c2", "#f69c9e", "#99c3ec"]
            }
          },
        ]}
        layout={{
          width: 150,
          height: 140,
          margin: { t: 10, b: 30, l: 30, r: 10 },
          yaxis: { title: '' , color: '#555555'},
          plot_bgcolor: 'transparent',
          paper_bgcolor: 'transparent',
          font: {color: '#555555'}
        }}
        config={{ 
          displayModeBar: false,
          displaylogo: false,
         }}
      />
    </div>
  );
};


const StatsCard = ({ columnName, stats }) => (
  <div className="main-card">
    <h3 className="main-card-title">{columnName}</h3>

    {/* Row 1: Count, Mean, Std */}
    <div className="row row-top">
      <StatBox label="Count" value={stats.count} />
      <StatBox label="Mean" value={stats.mean?.toFixed(2)} />
      <StatBox label="Std Dev" value={stats.std?.toFixed(2)} />
    </div>

    {/* Row 2: Min/Max on left, Quartile chart on right */}
    <div className="row row-bottom">
      <div className="column-stacked">
        <StatBox label="Min" value={stats.min} />
        <StatBox label="Max" value={stats.max} />
      </div>
      <div className="column-chart">
        <QuartileBar stats={stats} />
      </div>
    </div>
  </div>
);


export default function StatsDashboard({ statsData }) {

  if (!statsData || Object.keys(statsData).length === 0) {
    return <p>No stats available.</p>;
  }
  
  const columnNames = Object.keys(statsData);
  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
  };

  const handleNext = () => {
    if (currentIndex < columnNames.length - 1) setCurrentIndex(currentIndex + 1);
  };

  const currentColumn = columnNames[currentIndex];
  const currentStats = statsData[currentColumn];

  return (
    <div className="stats-navigator">
      <button
        onClick={handlePrev}
        disabled={currentIndex === 0}
        className="nav-arrow"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#555555" strokeWidth="2" ><path d="m15 18-6-6 6-6"/>
        </svg>
      </button>

      <div className="stats-card-wrapper">
        <StatsCard columnName={currentColumn} stats={currentStats} />
      </div>

      <button
        onClick={handleNext}
        disabled={currentIndex === columnNames.length - 1}
        className="nav-arrow"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#555555" strokeWidth="2"><path d="m9 18 6-6-6-6"/>
        </svg>
      </button>
    </div>
  );
}

