import dynamic from 'next/dynamic';
import { useState } from 'react';
import React from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

 
// Dynamically import Monaco Editor to avoid SSR issues
const MonacoEditor = dynamic(() => import('@monaco-editor/react'), { ssr: false });


export const MonacoCodeEditor = ({ initialCode, jobName }: { initialCode: string, jobName: string }) => {
    const [code, setCode] = useState(initialCode);
    console.log("jobNAME", jobName)
   
    const handleValueChange = (newValue: string) => {
      setCode(newValue); // Update the state when the code changes
      console.log("Updated value is", newValue); // Log the updated code
    };
   
    const handleSave = async() => {
      console.log(JSON.stringify({'Code': code}));
      // Example for API call (commented for now)
      const update_result = await fetch('http://127.0.0.1:8000/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({"code":code, "jobName": jobName}),
      })
   
  
      const update_data = await update_result.json()
      if(update_data.function_name == "updateJobWithXml"){
        if (update_data.result == "Success"){
          console.log("XML UPDATED")
          toast.success("Data updated successfully!");
          

        }
        else if(update_data.result == "Error"){
          console.log("XML NOT UPDATED")
          toast.error("Something went wrong!")
        }
      }
    };
  
    return ( 
      <>
        <p>You can update {jobName} job below</p>
        <MonacoEditor language="xml" theme='vs-dark' value={code} onChange={(value) => setCode(value || '')}  
        options={{minimap: { enabled: false },}} height="60vh" className='monaco-editor-class'/>
        <button onClick={handleSave} className="xml-update-btn">Update</button>
        <ToastContainer 
        position="top-center"
        autoClose={2000}
        theme="dark"/>
      </>
  
    );
  };