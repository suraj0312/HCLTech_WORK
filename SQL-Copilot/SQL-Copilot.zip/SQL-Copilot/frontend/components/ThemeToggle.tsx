// ThemeToggle.tsx
import { svgIconClasses } from "@mui/material";
import { Span } from "next/dist/trace";
import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [isDark, setIsDark] = useState(false);
  const [isHovering, setIsHovering] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem("theme");
    if (saved === "dark") {
      document.documentElement.classList.add("dark");
      setIsDark(true);
    }
  }, []);

  const toggleTheme = () => {
    const html = document.documentElement;
    if (html.classList.contains("dark")) {
      html.classList.remove("dark");
      localStorage.setItem("theme", "light");
      setIsDark(false);
    } else {
      html.classList.add("dark");
      localStorage.setItem("theme", "dark");
      setIsDark(true);
    }
  };

  const onMouseOver = () => {
    setIsHovering(true)
  }
  const onMouseOut = () => {
    setIsHovering(false)
  }
  

  return (
    <div className="theme-toggle-div">
      {isHovering && (
      <p>
        Switch to {isDark ? "Light" : "Dark"} mode
      </p>)}
      <button onClick={toggleTheme} className="theme-toggle-btn" onMouseOver={onMouseOver} onMouseOut={onMouseOut}>
        {isDark ? 
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f9f9f8" strokeWidth="1.2">
              <circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>
          </svg>
          : 
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1e1e1e" strokeWidth="1.2">
              <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>
          </svg>
        }
      </button>
    </div>

  );
}

