import { makeMarkdownText } from "@assistant-ui/react-markdown";
 
export const MarkdownText = makeMarkdownText();