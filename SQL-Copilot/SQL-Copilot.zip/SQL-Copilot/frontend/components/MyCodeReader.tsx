import dynamic from 'next/dynamic';
import { useState } from 'react';
import React from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
 
 

const MonacoEditor = dynamic(() => import('@monaco-editor/react'), { ssr: false });
 
 
export const MonacoCodeReader = ({ initialCode, jobName }: { initialCode: string, jobName: string }) => {
    const [code, setCode] = useState(initialCode)
 
 
    return (
      <>
        <p>You can see {jobName} job below</p>
        <MonacoEditor language="html" theme='vs-dark' value={code} onChange={(value) => setCode(value || '')}  
        options={{minimap: { enabled: false },readOnly:true}} height="60vh" className='monaco-editor-class'/>
       
      </>
 
       
    );
  };