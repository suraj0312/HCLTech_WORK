"use client"


import {  
	Thread,
	ThreadWelcome,
	Composer,
	type ThreadConfig,
} from "@assistant-ui/react";
import { FC } from "react";

import { MyThreadWelcome } from "./MyThreadWelcome";
import { MyComposer, MyCreidits } from "./MyComposer";

import ThemeToggle from "./ThemeToggle";

export const MyThread: FC<ThreadConfig> = (config) => {
	return (
		<Thread.Root config={config}>
		<Thread.Viewport>
			<MyThreadWelcome />
			<Thread.Messages />
			<Thread.FollowupSuggestions />
			<Thread.ViewportFooter>
			<Thread.ScrollToBottom />
			<MyComposer />
			<MyCreidits/>
			</Thread.ViewportFooter>
			<ThemeToggle />
		</Thread.Viewport>
		</Thread.Root>
	);
	};