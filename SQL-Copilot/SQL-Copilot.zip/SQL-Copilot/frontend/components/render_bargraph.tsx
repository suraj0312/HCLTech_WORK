import * as React from "react";
import { BarChart } from "@mui/x-charts/BarChart";
import { LineChart } from "@mui/x-charts/LineChart";
import { useState, useEffect } from "react";

export default function RenderChart({ data }: { data: object }) {
    const [seriesData, setSeriesData] = useState(data);
    // console.log('Data coming from backend    ',data)

    useEffect(() => {}, [data]);
    const colorPalette = ["#8c69f0", "#b9c8ff", "#3c91ff", "#c9e5ff"];
    // console.log('series data ',seriesData)

    const series = seriesData?.series || [];
    const xAxis = seriesData?.xAxis || [];
    // console.log("series comig dta",xAxis)
    // Map the series data to a format that can be passed to the BarChart component
    const mappedSeries = series.map((item: any, index: number) => ({
        data: item.data,
        label: item.label,
        color: colorPalette[index % colorPalette.length],
    }));

    const graphType = seriesData?.what_plot_is_possible || "";
    let scaleTypeVar = "";
    if (graphType == "bar graph") {
        scaleTypeVar = "band";
    }
    else if (graphType == "line graph") {
        scaleTypeVar = "point";
    }

    const mappedxaxis = xAxis.map((xitem: any) => ({
        data: xitem.data,
        scaleType: scaleTypeVar,
        sx: {
            ".MuiChartsAxis-tickLabel": { fill: "white" },
            ".MuiChartsAxis-Label": { fill: "white" }, // Change label color
            ".MuiChartsAxis-line": { stroke: "white" },
            ".MuiChartsAxis-tick": { stroke: "white" }, // Change axis line color
        },
    }));
    // console.log('MApped', mappedSeries)

    if (graphType == "bar graph") {
        return (
            <BarChart
                width={500}
                height={300}
                series={mappedSeries}
                xAxis={mappedxaxis}
                slotProps={{
                    legend: {
                        labelStyle: {
                            fontSize: 14,
                            fill: "white",
                        },
                    },
                }}
                yAxis={[
                    {
                        sx: {
                            ".MuiChartsAxis-tickLabel": { fill: "white" },
                            ".MuiChartsAxis-line": { stroke: "white" },
                            ".MuiChartsAxis-tick": { stroke: "white" },
                        },

                        // Change Y-axis line color
                    },
                ]}
            />
        );
    }
    if (graphType == "line graph") {
        return (
            <LineChart
                width={500}
                height={300}
                series={mappedSeries}
                xAxis={mappedxaxis}
                slotProps={{
                    legend: {
                        labelStyle: {
                            fontSize: 14,
                            fill: "white",
                        },
                    },
                }}
                yAxis={[
                    {
                        sx: {
                            ".MuiChartsAxis-tickLabel": { fill: "white" },
                            ".MuiChartsAxis-line": { stroke: "white" },
                            ".MuiChartsAxis-tick": { stroke: "white" },
                        },

                        // Change Y-axis line color
                    },
                ]}
            />
        );
    }
}
