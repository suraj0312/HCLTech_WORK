// CreateChart.tsx
import React, { useState } from 'react';
import Plot from 'react-plotly.js'; // Assuming you're using react-plotly.js
import * as XLSX from "xlsx";
import RenderTabsComponent from './TabsComponent';
import CustomHoverCard from './CustomHoverCard'; // Import your custom hover card


export default function CreateChart({ plot_info }: { plot_info: any}) {

    let tabs_data = {"summary" : plot_info.summary, "stats" : plot_info.stats}

    const [hoverData, setHoverData] = useState<any | null>(null);
    const [hoverPosition, setHoverPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
    const [isHovering, setIsHovering] = useState(false);

    const chartContainerRef = React.useRef<HTMLDivElement>(null); // Added this ref in plot div

    const handleHover = (event: any) => {
        // console.log("Hover event fired:", event);
        if (event.points && event.points.length > 0) {
            const point = event.points[0];
            // console.log("Hover point data:", point);
            setHoverData(point);
    
            if (event.event && chartContainerRef.current) {
                const plotDiv = chartContainerRef.current; // The div wrapping Plot and CustomHoverCard
                const rect = plotDiv.getBoundingClientRect(); // Get its position relative to viewport
    
                // Calculate position relative to the plotDiv
                const x = event.event.clientX - rect.left;
                const y = event.event.clientY - rect.top;
    
                // console.log("Mouse relative position:", { x, y });
                setHoverPosition({ x, y });
            }
            setIsHovering(true);
        } 
        else {
            console.log("Hover event fired, but no points found.");
        }
    };

    const handleUnhover = () => {
        setIsHovering(false);
        // Optionally reset hoverData if needed, though isHovering controls visibility
        // setHoverData(null);
    };


    if (plot_info.type == "table") {
            const alternate_color_list = [];
            for (let i = 0; i < plot_info.cell[0].length; i++) {
                alternate_color_list.push(i % 2 === 0 ? "#ffffff" : "#dedede");
            }

            const estimatedWidths = plot_info.header.map((header : string, colIndex : number) => {
            const values = plot_info.cell[colIndex] || [];
            const sampleValues = values.slice(0, 5); // Take a few samples
            const maxValLen = Math.max(...sampleValues.map((v: string) => (v?.toString().length || 0)), 0);
            const headerLen = header.length;
            const charPixelWidth = 8; // average pixel width per character
            return Math.max(maxValLen, headerLen) * charPixelWidth + 20; // +20 for padding
        });

            const totalWidth = estimatedWidths.reduce((sum : number, w : number) => sum + w, 0);
    
            return (
                <>
                <div className='table_content_container'>
                    <h1 className='table_title'>{plot_info.title}</h1>
                    <div className='table_plot_container'>
                        <Plot
                            data={[
                                {
                                type: "table",
                                columnwidth: estimatedWidths,
                                header: {
                                    values: plot_info.header,
                                    align: "center",
                                    line: { width: 1, color: "black" },
                                    fill: { color: ["grey"] },
                                    font: {
                                            family: "Arial",
                                            size: 12,
                                            color: "#ffffff",
                                            },
                                        },
                                cells: {
                                    values: plot_info.cell,
                                    align: "center",
                                    line: { color: "black", width: 1 },
                                    fill: { color: [alternate_color_list] },
                                    font: {
                                            family: "Arial",
                                            size: 12,
                                            color: ["black"],
                                            },
                                        },
                                    },
                                ]}
                            layout={{
                                // title: {
                                //     text: plot_info.title,
                                // },
                                width: Math.max(totalWidth, 600),
                                height: 450,
                                margin: {t:40, b:10, r:40, l:40},
                                }}
                            config={{
                                displayModeBar: true,
                                modeBarButtonsToAdd: [
                                    {
                                        name: "Download Excel",
                                        icon: {
                                            width: 857.1,
                                            height: 1000,
                                            path: "m214-7h429v214h-429v-214z m500 0h72v500q0 8-6 21t-11 20l-157 156q-5 6-19 12t-22 5v-232q0-22-15-38t-38-16h-322q-22 0-37 16t-16 38v232h-72v-714h72v232q0 22 16 38t37 16h465q22 0 38-16t15-38v-232z m-214 518v178q0 8-5 13t-13 5h-107q-7 0-13-5t-5-13v-178q0-8 5-13t13-5h107q7 0 13 5t5 13z m357-18v-518q0-22-15-38t-38-16h-750q-23 0-38 16t-16 38v750q0 22 16 38t38 16h517q23 0 50-12t42-26l156-157q16-15 27-42t11-49z",
                                            transform: "matrix(1 0 0 -1 0 850)",
                                        },
                                        click: function () {
                                            const rows = [];
                                            for (let i = 0; i < plot_info.cell[0].length; i++) {
                                                const row: any = {};
                                                for (let j = 0; j < plot_info.header.length; j++) {
                                                    row[plot_info.header[j]] = plot_info.cell[j][i];
                                                }
                                                rows.push(row);
                                            }

                                            const worksheet = XLSX.utils.json_to_sheet(rows);
                                            const workbook = XLSX.utils.book_new();
                                            XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");

                                            XLSX.writeFile(workbook, `${plot_info.title || "table"}.xlsx`);
                                        },
                                    },
                                ],
                                modeBarButtonsToRemove: ["pan2d", "select2d", "lasso2d", "resetScale2d", "zoomOut2d"],
                                displaylogo: false,
                            }}
                        />
                    </div>
                </div>
                < RenderTabsComponent tabs_data={tabs_data} />
             </>
        );
    }


    let traces_val = plot_info.traces;
    let title_val = plot_info.title;
    let type_val = plot_info.type;
    let xaxis_title = "";
    let yaxis_title = "";

    if (plot_info.hasOwnProperty("xaxis_title")) {
        xaxis_title = plot_info.xaxis_title;
    }
    if (plot_info.hasOwnProperty("yaxis_title")) {
        yaxis_title = plot_info.yaxis_title;
    }

    // It's good practice to ensure traces_val is an array and map over it
    // to create a new array rather than mutating it directly with forEach.
    traces_val.forEach((obj: any) => {
        obj.type = type_val; 
        obj.hoverinfo = "none";
        // IMPORTANT: Disable default Plotly hover info for the traces
        // You can also set hoverinfo: 'none' for each trace if you want to be very specific
        // hoverinfo: 'skip' or 'none' can be set per trace if you still want hover events but no default box
    });
    

    if (type_val == "line") {
        traces_val.forEach((obj : any) => {
            obj.type = "scatter"; // since all line aplots are of type scatter
            obj.mode = "lines";
            obj.line = { width: 2 };
        });

    // SCATTER PLOT
    } else if (type_val == "scatter") {
        traces_val.forEach((obj : any) => {
            obj.mode = "markers";
            obj.marker = { size: 10 };
        });
    }

    // PIE PLOT
    else if (type_val == "pie") {
        let total_pie_traces = traces_val.length;
        let grid_val = { rows: 1, columns: 1 };

        if (total_pie_traces > 1)
            grid_val = { rows: Math.ceil(total_pie_traces / 2), columns: 2 };

        traces_val.forEach((obj : any, index : any) => {
            obj.hole = 0.4;
            // obj.hoverinfo = "label+percent+name";
            obj.domain = { row: Math.floor(index / 2), column: index % 2 };
        });
        console.log(traces_val);
        // LAYOUT FOR PIE/DONUT PLOT
        return (
            <div ref={chartContainerRef} style={{ position: 'relative', width: 'fit-content' }}>
                <Plot
                    data={traces_val}
                    layout={{
                        title: {
                            text: title_val,
                            // font: { color: "#ffffff" },
                        },
                        grid: grid_val, // for more than 1 pie plot
                        // legend: { font: { color: "#ffffff" } },
                        showlegend: true,
                        width: 600,
                        margin: {l:30},
                        hovermode: 'closest', // 'x', 'y', 'closest', or false
                        hoverlabel: { bgcolor: 'transparent', bordercolor: 'transparent', font: {color: 'transparent'}, namelength: 0 }, // Visually hide default
                }}
                config={{
                    displayModeBar: true,
                    modeBarButtonsToRemove: ["pan2d", "select2d", "lasso2d", "resetScale2d", "zoomOut2d", "zoom2d", "zoomIn2d", "autoScale2d"],
                    displaylogo: false,
                }}
                // Add Plotly event handlers
                onHover={handleHover}
                onUnhover={handleUnhover}
                // onRelayout could also trigger unhover if the plot resizes/zooms
                onRelayout={handleUnhover}
            />
            <CustomHoverCard
                data={hoverData}
                position={hoverPosition}
                isVisible={isHovering}
            />
            {/* Assuming RenderTabsComponent is part of your UI */}
            <RenderTabsComponent tabs_data={tabs_data} />
        </div>
        );
    }

    return (
        // The parent div needs position: relative for absolute positioning of the hover card
        <div ref={chartContainerRef} style={{ position: 'relative', width: 'fit-content' }}>
            <Plot
                data={traces_val}
                layout={{
                    title: {
                        text: title_val,
                    },
                    xaxis: {
                        linecolor: "#1e1e1e",
                        tickcolor: "#1e1e1e",
                        tickfont: { color: "#1e1e1e" },
                        title: {
                            text: xaxis_title,
                        },
                    },
                    yaxis: {
                        linecolor: "#1e1e1e",
                        tickcolor: "#1e1e1e",
                        tickfont: { color: "#1e1e1e" },
                        title: {
                            text: yaxis_title,
                        },
                    },
                    showlegend: true,
                    width: 600,
                    // margin: {t:30, b:30, r:20, l:20},
                    // IMPORTANT: Disable default hover labels globally
                    // Set hovermode to 'closest' to ensure events fire for the nearest point
                    // If you set hovermode: false, hover events might not fire as expected.
                    // 'closest' ensures events fire, and you control the display.
                    hovermode: 'closest', // 'x', 'y', 'closest', or false
                    hoverlabel: { bgcolor: 'transparent', bordercolor: 'transparent', font: {color: 'transparent'}, namelength: 0 }, // Visually hide default
                }}
                config={{
                    displayModeBar: true,
                    modeBarButtonsToRemove: ["pan2d", "select2d", "lasso2d", "resetScale2d", "zoomOut2d", "zoom2d", "zoomIn2d", "autoScale2d"],
                    displaylogo: false,
                }}
                // Add Plotly event handlers
                onHover={handleHover}
                onUnhover={handleUnhover}
                // onRelayout could also trigger unhover if the plot resizes/zooms
                onRelayout={handleUnhover}
            />
            <CustomHoverCard
                data={hoverData}
                position={hoverPosition}
                isVisible={isHovering}
            />
            {/* Assuming RenderTabsComponent is part of your UI */}
            <RenderTabsComponent tabs_data={tabs_data} />
        </div>
    );
}