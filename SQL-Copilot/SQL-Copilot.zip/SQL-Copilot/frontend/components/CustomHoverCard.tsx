import React from 'react';

interface CustomHoverCardProps {
  data: any; // Data of the hovered point (e.g., x, y, customdata, text)
  position: { x: number; y: number }; // Mouse position to place the card
  isVisible: boolean;
}

const CustomHoverCard: React.FC<CustomHoverCardProps> = ({ data, position, isVisible }) => {
  if (!isVisible || !data) {
    return null;
  }
  // console.log("HOVER CARD DATA\n", data)

  // Dynamic styles that depend on props (like position) remain inline
  const dynamicStyle: React.CSSProperties = {
    top: position.y + 10,
    left: position.x + 10,
  };

  const formatNumber = (num: number | undefined, digits: number = 2, isPercent: boolean = false) => {
    if (num === undefined || num === null) return 'N/A';
    return isPercent ? (num * 100).toFixed(digits) + '%' : num.toFixed(digits);
  };

  const traceName = data.fullData?.name || data.name;
  const plotType = data.fullData?.type;

  // Data access for X and Y axis titles needs to be safer
  const x_label = data.xaxis?.title?.text || 'X'; // Fallback to 'X'
  const y_label = data.data?.name || data.yaxis?.title?.text || 'Y'; // Try trace name, then Y axis title, then 'Y'


  return (
    // Apply the base class from the CSS module and add dynamic inline styles
    <div className="plotHoverCard" style={dynamicStyle}>
      {traceName && <h3>{traceName}</h3>} {/* Use the h3 styling from CSS module */}

      {/* Cartesian Data (bar, line, scatter) */}
      {data.x !== undefined && plotType !== 'pie' && (
        <p> {/* Use the p styling from CSS module */}
         {x_label}:
         <strong> {typeof data.x === 'number' ? formatNumber(data.x) : data.x.toString()} </strong>
        </p>
      )}
      {data.y !== undefined && plotType !== 'pie' && (
        <p>
          {y_label}:
          <strong> {typeof data.y === 'number' ? formatNumber(data.y) : data.y.toString()} </strong>
        </p>
      )}

      {/* Pie Chart Data */}
      {data.label !== undefined && plotType === 'pie' && (
        <p><strong>{data.label}</strong></p>
      )}
      {data.value !== undefined && plotType === 'pie' && (
        <p>Value: 
          <strong> {formatNumber(data.value, 0)} </strong>
        </p>
      )}
      {/* {data.percent !== undefined && plotType === 'pie' && (
        <p>Percent: 
          <strong> {formatNumber(data.percent, 2, true)} </strong>
        </p>
      )} */}

      {/* Text (from hovertext or texttemplate) */}
      {data.text && typeof data.text === 'string' && data.text.trim() !== '' && (
        <p>Info: 
          <strong> {data.text} </strong>
        </p>
      )}

      {/* Custom Data */}
      {data.customdata && (
        <p>
          Details: {typeof data.customdata === 'object' ? JSON.stringify(data.customdata) : data.customdata.toString()}
        </p>
      )}
    </div>
  );
};

export default CustomHoverCard;