"use client";
 
import { useState, type ReactNode } from "react";

import { Thread } from "@assistant-ui/react"; 

import {
  AssistantRuntimeProvider,
  useLocalRuntime,
  CompositeAttachmentAdapter,
  SimpleImageAttachmentAdapter,
  SimpleTextAttachmentAdapter,
  type ChatModelAdapter,
} from "@assistant-ui/react";

import { MonacoCodeEditor } from "@/components/MyMonacoCodeEditor";

import { MonacoCodeReader } from "@/components/MyCodeReader";
 


const MyModelAdapter: ChatModelAdapter = {
  async run({ messages, abortSignal }) {

    console.log(JSON.stringify({messages,}))
    // console.log(messages)

    let userData = messages.map((_, index, array) => {
      // Only return the last element (if it's the last iteration)
      if (index === array.length - 1) {
        return array[index];  // Return the last element
      }
    }).filter(item => item !== undefined);  // Filter out the undefined values
   
    console.log(JSON.stringify({userData}));


    // const result = await fetch("http://127.0.0.1:8000/your_api_endpoint", {
    const result = await fetch("http://127.0.0.1:8000/api/chat", {
    // const result = await fetch("http://127.0.0.1:8000/api/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      // forward the messages in the chat to the API
      body: JSON.stringify({
        userData,
        // messages,
      }),
      // if the user hits the "cancel" button or escape keyboard key, cancel the request
      signal: abortSignal,
    });
 
    const data = await result.json();
    console.log("DATA",data)

    if((data.tool_name == "predict_visualization")||(data.tool_name == "db_query_tool")) {//|| (data.function_name == "viewCode")) && (data.job_name_exists == "True")){
      return{
        content: [
        
          {
          type: "tool-call",
          toolCallId: "123",
          args: {"jobName": data.tool_name},
          result : data.tool_response,
          toolName: data.tool_name,
          argsText: data.last_ai_message,
          }
        ]
      }
    }

    else{
      return {
        content: [
          {
            type: "text",
            text: data.last_ai_message.ai_message,
          },
        ],
      };
    }
  },
};



export function MyRuntimeProvider({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  const runtime = useLocalRuntime(MyModelAdapter, {adapters: {attachments: new SimpleTextAttachmentAdapter(),
}

});
 
  return (
    <AssistantRuntimeProvider runtime={runtime}>
     {children}
    </AssistantRuntimeProvider>
  );
}