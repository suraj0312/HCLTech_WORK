// "use client"

// import { MarkdownText } from "@/components/markdown-text";

// import { Thread } from "@assistant-ui/react";



// export default function AssistantUi() {
// 	return (
// 		<div className="h-full">
// 			{/* <Thread/> */}
//       		<Thread assistantMessage={{ components: { Text: MarkdownText } }}/>
// 		</div>
// 	);
// }



//====================================================


"use client"

// import { MarkdownText } from "@/components/markdown-text";

import { MyThread } from "@/components/MyThread";

import { ToolFallback } from "@/components/MyToolCall";
import { AssistantModal } from "@assistant-ui/react";

import { makeMarkdownText } from "@assistant-ui/react-markdown";

const MarkdownText = makeMarkdownText();

export default function AssistantUi() {
	return (
		<div className="h-full">
			{/* <Thread/> */}
      		<MyThread assistantMessage={{ components: { Text: MarkdownText, ToolFallback } }} assistantAvatar={{src:"/chatbot-logo.svg"}}/>
      		{/* <MyThread assistantAvatar={{src:"/JenkinsLogo.svg"}}/> */}
      		{/* <AssistantModal assistantMessage={{ components: { Text: MarkdownText } }} assistantAvatar={{src:"/JenkinsLogo.svg"}}/> */}
		</div>
	);
}